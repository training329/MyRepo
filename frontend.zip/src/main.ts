// <reference path="node_modules/angular2/typings/browser.d.ts"/>

import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {enableProdMode} from '@angular/core';

import {AppModule} from './app/app.module';

export function main(initialHmrState?: any): Promise<any> {
  return platformBrowserDynamic().bootstrapModule(AppModule)
    .catch(err => console.error(err));
}

/*
 * Hot Module Reload
 * experimental version by @gdi2290
 */
// if ( ENV === 'development' && HMR === true) {
//   // activate hot module reload
//   let ngHmr = require('angular2-hmr');
//   ngHmr.hotModuleReplacement(main, module);
// } else {
  // bootstrap when document is ready

//TODO: To switch to production mode before environment deployment
  enableProdMode();
  document.addEventListener('DOMContentLoaded', () => main());
// }


// platformBrowserDynamic().bootstrapModule(AppModule)
//     .then(success => console.log(`Bootstrap success`))
//     .catch(error => console.log(error));
