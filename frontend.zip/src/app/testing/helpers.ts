import {inject, ComponentFixture, tick} from "@angular/core/testing";
import {LoginService} from "../services/login.service";

export function login() {
  return inject([LoginService], (loginService) => {
    spyOn(loginService, 'isSignedIn').and.returnValue(true);
  });
}

export function advance(fixture: ComponentFixture<any>, millis?:number): void {
  tick(millis);
  fixture.detectChanges();
}

