import {RequestOptions, Http} from "@angular/http";
import {MockBackend} from "@angular/http/testing";
import {JsonHttp} from "../services/json-http";
import {SpinnerService} from "../services/spinner/spinner.service"


export * from './helpers';

export const APP_TEST_HTTP_PROVIDERS = [
  MockBackend,
  SpinnerService,
  {
    provide: JsonHttp,
    useFactory: (mockBackend: MockBackend, requestOptions: RequestOptions) => {
      const http = new Http(mockBackend, requestOptions);
      const spinner = new SpinnerService();
      return new JsonHttp(http, spinner);
    },
    deps: [MockBackend, RequestOptions, SpinnerService]
  }
];
