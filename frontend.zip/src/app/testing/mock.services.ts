import {
    Response,
    ResponseType
} from "@angular/http";

export class MockError extends Response implements Error {
    name:any;
    message:any;
    public static readonly error_500 = {type: ResponseType.Error, status: 500, statusText: 'Internal server occured.', body: {}};
}

export class MockRouter {
    navigate() {}
}

export class MockReferenceDataService {}

export class MockAppStateService {
    clearAppState() {};
    getModuleGlobalState(module, key) {};
    setModuleGlobalState(module, key, value) {};
}

export class MockUtilService {
	exportToExcel(url) {};
}

export class MockIdleService {
    public onTimeout:any;
}

export class MockHttpErrorHandler {
    handle(err) {
        console.log("AdminServiceMock:: MockHttpErrorHandler", err);
    }
}