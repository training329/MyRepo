beforeEach(() => {
  localStorage.clear();
});
