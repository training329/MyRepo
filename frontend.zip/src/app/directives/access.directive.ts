import { Component, HostBinding, Input, Directive, ElementRef } from '@angular/core';

import {LoginService} from "../services/login.service";

@Directive({
  selector: '[accessRoles]'
})

export class AccessDirective {
	
    //@HostBinding('hidden') hideRouterLink: boolean = true;
	removeLink: boolean = true;
    
    @Input() accessRoles;
    
    constructor(private loginService: LoginService, private _elementRef: ElementRef) {
    	console.debug('AccessDirective::constructor');
    }
    
    ngOnInit() {
    	console.debug('AccessDirective::ngOnInit');
    	let role = this.loginService.getUserRole();   	
    	if(this.accessRoles) {
            for ( let i = 0; i < this.accessRoles.length; i++ ) {
            	if (role == this.accessRoles[i]) {
            		this.removeLink = false;
            		break;
            	} 
            }
    	}    	
    	if(this.removeLink) {
    		let el: HTMLElement = this._elementRef.nativeElement;
	    	if(el.parentNode) {
	    		el.parentNode.removeChild(el);
	    	}
    	}
    }
  
}