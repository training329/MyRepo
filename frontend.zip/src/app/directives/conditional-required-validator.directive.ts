import { Directive, forwardRef, Attribute } from '@angular/core';
import {Validator, NG_VALIDATORS, AbstractControl} from '@angular/forms';


@Directive({
  selector: '[conditionalRequired][formControlName],[conditionalRequired][formControl],[conditionalRequired][ngModel]',
  providers: [{provide: NG_VALIDATORS, useExisting: forwardRef(() => ConditionalRequiredValidator), multi: true }]
})
export class ConditionalRequiredValidator implements Validator {
    control:AbstractControl;
    
    constructor( @Attribute('conditionalRequired') public conditionalRequired: boolean) {
    	console.debug('ConditionalRequiredValidator::constructor');
    }
  
    ngOnChanges() {
    	console.debug('ConditionalRequiredValidator::ngOnChanges ', this.conditionalRequired);
    	if (this.control) {
    		this.control.updateValueAndValidity();
    	}
    }
  
    validate(control: AbstractControl): { [key: string]: any } {
    	console.debug('ConditionalRequiredValidator::validate ', control, this.conditionalRequired);
    	this.control = control;
    	return this.conditionalRequired && !control.value
      		? { conditionalRequired: true }
      		: null;
  	}
}