import { Directive, Input, HostListener } from '@angular/core';

import {Location} from '@angular/common';
import * as toastr from 'toastr';

@Directive({
	selector: '[allowBackNavigation]'
})

export class BackNavigationDirective {

	@Input() allowBackNavigation;

	constructor(private _location: Location) {
		console.debug('BackNavigationDirective::constructor');
	}
	
	@HostListener('click', ['$event'])
	onClick() {
		console.debug('BackNavigationDirective::onClick');
		if(this.allowBackNavigation) {
			this._location.back();
		} else {
			this.confirmDialog("You have unsaved changes on this page. Do you want to leave this page?", "Navigating Away", ['No', 'Yes']);
		}
	}
	
	confirmDialog(message, title, buttonLabels) {
		console.debug('BackNavigationDirective::confirmDialog ', message, title, buttonLabels);
    	toastr.clear();
    	toastr.info(  '<br /><div><p>' + message + '</p></div>'+
	           '<button type="button" (click)="back(false)" class="btn clear">'+buttonLabels[0]+'</button>    ' +
	           '<button id="okButton" (click)="back(true)" class="btn btn-warning">'+buttonLabels[1]+'</button>', 
	           title, {
    			closeButton: true,
    			preventDuplicates: true,
    			onclick: ()  => {
    				if((event.target as any).innerText == buttonLabels[1]) {
    					this._location.back();
    				}
    				(event.currentTarget as any).hidden = true;
    			},
                timeOut: 10000, 
                extendedTimeOut: 10000,
                progressBar: true,
    			allowHtml: true
    		}
    	);
	}

}