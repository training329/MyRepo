import { NumberFormatPipe } from './../pipes/number-formatting-pipe';
import { Component, HostBinding, Input, Directive, ElementRef, HostListener, OnInit } from '@angular/core';

import {LoginService} from "../services/login.service";

@Directive({selector: '[numberFormat]'})
export class NumberFormatDirective implements OnInit {
   
    private el:HTMLInputElement;
   
    constructor(private _elementRef: ElementRef,private _numberFormatPipe:NumberFormatPipe) {
    	console.debug('NumberFormatDirective::constructor');
		this.el=_elementRef.nativeElement;
    }
    
    ngOnInit() {
		console.debug('NumberFormatDirective::ngOnInit');
		this.el.value=this._numberFormatPipe.transform(this.el.value,true);
    }
	@HostListener("focus", ["$event.target.value"])
	onFocus(value) {
		console.debug('NumberFormatDirective::onFocus');
		this.el.value = this._numberFormatPipe.parse(value,false); // opossite of transform
	}
	@HostListener("oninput", ["$event.target.value"])
	onInput(value) {
		console.debug('NumberFormatDirective::onFocus');
		this.el.value = this._numberFormatPipe.parse(value,false); // opossite of transform
	}

	@HostListener("blur", ["$event.target.value"])
	onBlur(value) {
		console.debug('NumberFormatDirective::onBlur');
		this.el.value = this._numberFormatPipe.transform(value,true);
	}
}