import {inject, TestBed} from "@angular/core/testing";
import {ResponseOptions, Response, RequestMethod, HttpModule} from "@angular/http";
import {MockBackend} from "@angular/http/testing";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../testing";
import {MockError, MockRouter, MockReferenceDataService, MockAppStateService, MockIdleService, MockHttpErrorHandler} from '../testing/mock.services';
import {JsonHttp} from "../services/json-http";

import {AppStateService} from  "../services/app-state.service";
import {UtilService} from "./util.service";
import {HttpErrorHandler} from "../services/http-error-handler";

//Service End Point URI
const exportToExcelURI = '/api/exceptionsummary/export/2';

describe('UtilService', () => {

    let utilService				: UtilService;
    let backend					: MockBackend;
	let appStateService			: AppStateService;

	/*let blobMockResponse = new Blob([""], { type: 'application/vnd.ms-excel' });
	blobMockResponse["name"] = "Alerts.xls";*/

	beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                APP_TEST_HTTP_PROVIDERS,
                UtilService,
            ],
        });
    });

    beforeEach(inject([UtilService, AppStateService, MockBackend], (..._) => {
        [utilService, appStateService, backend] = _;
    }));
    
    /*describe('.getFileData', () => {
        let subscription;
        
        describe('When file data is available', () => {
        	it('File data should be available', () => {
        		backend.connections.subscribe(conn => {
        			conn.mockRespond(new Response(new ResponseOptions({
        				body: JSON.stringify([blobMockResponse])
        			})));
        			expect(conn.request.method).toEqual(RequestMethod.Post);
        			expect(conn.request.url).toEqual(exportToExcelURI);
        		});

        		utilService.getFileData(exportToExcelURI, null).subscribe(resp => {
        			let blobRes = new Blob([resp._body], {type: "application/vnd.ms-excel"};
        			blobRes["name"] = "Alerts.xls";
        			expect(blobRes).toBeTruthy();
        		});
        	});
        }); 
         
        describe('When file data is not available', () => {
            it('File data should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                    	body: JSON.stringify(["{}"])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(exportToExcelURI);
                });
                
                utilService.getFileData(exportToExcelURI, null).subscribe(resp => {
                	let blobRes = new Blob([resp._body], {type: "application/vnd.ms-excel"};
                	blobRes["name"] = "Alerts.xls";
                	expect(blobRes).toBeTruthy();
                });
            });
    	}); 
         
    });*/    
   
    describe('.exportToExcel', () => {
    	describe('when all alerts export is requested', () => {
    		it('export should open new window to download file', () => {
    			spyOn(window, 'open').and.callFake(function() {
    	            return true;
    	        });
    			
    			utilService.exportToExcel(exportToExcelURI);
        		expect(window.open).toHaveBeenCalled();
                expect(window.open).toHaveBeenCalledWith(exportToExcelURI);
    		});
    	});
    });
});