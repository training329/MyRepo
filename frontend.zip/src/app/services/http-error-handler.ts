import {Injectable} from "@angular/core";
import {Router} from "@angular/router";
import {LoginService} from "../services/login.service";
import * as toastr from 'toastr';

toastr.options.preventDuplicates = true;

@Injectable()
export class HttpErrorHandler {

    constructor(private router:Router,
                private loginService:LoginService) {
    	console.debug("HttpErrorHandler::constructor");
    }

    handle(error:any) {
        console.error("HttpErrorHandler::handle ", error);
        if (error.status === 401) {
            this.loginService.logout();
            toastr.error('Please Sign In');
            this.router.navigate(['login']);
        }
    }

}