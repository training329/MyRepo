import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Rx";
import {Injectable} from "@angular/core";
import {Response} from "@angular/http";

import "../common/rxjs-operators";
import {JsonHttp} from "../services/json-http";
import {UserParams, EnvironmentVersion} from "../shared/dto";
import {MyStorage} from "../services/storage-wrapper";

import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application models
import { SelectItem, FilterCriteria } from "../common/api";
import { MasterData } from '../models/master-data';

//Service End Point URI
const getMasterDataListServiceEndPoint = '/api/clientoverview/getMasterDataList';
const getEnvironmentVersionEndPoint = '/api/getEnviromentDetails';

@Injectable()
export class ReferenceDataService {

    masterData: Observable<Object>;
    masterDataList: Array<MasterData> = [];
    clientList: SelectItem[] = [];
    fundList: SelectItem[] = [];
    entityList: SelectItem[] = [];
    regionList: SelectItem[] = [];
   
    
    selectedClientId: string = '999999';
    selectedFundId: string = '9999999999';
    selectedEntityId: string = '26';
    selectedRegionId: string = '1';
    
    selectedClient: string = 'ALL';
    selectedFund: string  = 'ALL';
    selectedEntity: string = 'ALL';
    selectedRegion: string = 'GLOBAL';
    
    env: EnvironmentVersion;
    private envDetails: Subject<EnvironmentVersion> = new Subject<EnvironmentVersion>();
    
    constructor(private http:JsonHttp) {
    	console.debug("ReferenceDataService::constructor");
    	this.getEnvDetails().subscribe(
            response => {
                if (response && response.envName && response.envName != "" && response.envName.indexOf("prod") == -1) {
                	this.env = response;
                	this.envDetails.next(this.env);
                }                
            }, e => {
    			toastr.error('Error while getting environment details. Please try again or contact AQUA RACE support', 'Error');
    			this.handleError(e);
    		});
    }
    
    getMasterDataList(): Observable<Object> {
    	console.debug("ReferenceDataService::getMasterDataList");
        if (!this.masterData) {
        	this.masterData = this.http.get(getMasterDataListServiceEndPoint)
                .map( res => {
                    this.masterDataList = res.json();
                    return this.masterDataList;
                })
                 .publishReplay(1)
                 .refCount();
        }
        return this.masterData;
    }
    
    getClientList(): SelectItem[] {
    	console.debug("ReferenceDataService::getClientList");
        var data = this.transfterToSelectList(this.getUniqListByField(this.masterDataList, 'client'), 'client_id', 'client');
        return data;
    }
    
    getFundList(clientId): SelectItem[] {
    	console.debug("ReferenceDataService::getFundList ", clientId);
        var filterResult = this.filterListOnCriteria(this.masterDataList, {'client_id' : clientId});
        var data = this.transfterToSelectList(this.getUniqListByField(filterResult, 'fund'), 'fund_id', 'fund');
        return data;
    }
    
    getLegalEntityList(clientId, fundId): SelectItem[] {
    		console.debug("ReferenceDataService::getLegalEntityList ", clientId, fundId);
        var filterResult = this.filterListOnCriteria(this.masterDataList, {'client_id' : clientId, 'fund_id': fundId});
        var data = this.transfterToSelectList(this.getUniqListByField(filterResult, 'entity'), 'entity_id', 'entity');
        return data;
    }
    
    getRegionList(clientId, fundId, entityId): SelectItem[] {
    	console.debug("ReferenceDataService::getRegionList ", clientId, fundId, entityId);
        var filterResult = this.filterListOnCriteria(this.masterDataList, {'client_id' : clientId, 'fund_id': fundId, 'entity_id': entityId});
        var data = this.transfterToSelectList(this.getUniqListByField(filterResult, 'region'), 'region_id', 'region');
        return data;
    }
        
    filterListOnCriteria(list:MasterData[], criterias:FilterCriteria): MasterData[] {
    	console.debug("ReferenceDataService::filterListOnCriteria ", list, criterias);
        var filterResult = _.filter(list, function (item) {
            var matchFound = true;
            
            for ( let criteria in criterias ) {   
                if(item[criteria] != criterias[criteria]){
                     matchFound = false;
                     break;
                }
            }
            return matchFound;
        });
        return filterResult;
    }
    
     getUniqListByField(list:MasterData[], field:string) : MasterData[] {
    	console.debug("ReferenceDataService::getUniqListByField ", list, field);
        // softing on filedl
        var sortedResult = _.sortBy(list, function (item) {
            return (item as any)[field];
        });

        // unique  
        var uniqResult = _.unique(sortedResult, true, function (item) {
            return (item as any)[field];
        });
        
        return uniqResult;
    }
    
    transfterToSelectList(list:MasterData[], value, label) : SelectItem[] {
    	console.debug("ReferenceDataService::transfterToSelectList ", list, value, label);
        var data = _.map(list, function(item) { 
            return {                    
                "value": (item as any)[value],
                "label": (item as any)[label]
            };
        });
        return data;
    }
    
    getEnvDetails() : Observable<EnvironmentVersion> {
    	console.debug("ReferenceDataService::getEnvDetails");
    	return this.http.get(getEnvironmentVersionEndPoint)
           	.map((res:Response) => res.json());
    }

    handleError(error: any) {
    	console.error("ReferenceDataService::handleError", error);
    	let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        return Observable.throw(errMsg);
    }
    
    public subscribeToEnvDetails(): Observable<EnvironmentVersion> {
        console.debug("ReferenceDataService::subscribeToEnvDetails");
        return this.envDetails.asObservable();
    }
}

