import {inject, TestBed} from "@angular/core/testing";
import {ResponseOptions, Response, RequestMethod, HttpModule} from "@angular/http";
import {MockBackend} from "@angular/http/testing";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../testing";
import {MockError, MockRouter, MockReferenceDataService, MockAppStateService, MockIdleService, MockHttpErrorHandler} from '../testing/mock.services';
import {JsonHttp} from "../services/json-http";

import {AppStateService} from  "../services/app-state.service";
import {ReferenceDataService} from "./reference-data.service";
import {HttpErrorHandler} from "../services/http-error-handler";

//Service End Point URI
const getMasterDataListServiceEndPoint = '/api/clientoverview/getMasterDataList';
const getEnvironmentVersionEndPoint = '/api/getEnviromentDetails';


describe('ReferenceDataService', () => {

    let referenceDataService	: ReferenceDataService;
    let backend					: MockBackend;
	let appStateService			: AppStateService;

	let masterData 		: any = [{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"}];
	let masterDataList 	: any = [{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL ABSOLUTE RETURN FUND","fund_id":"1020817506","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL ABSOLUTE RETURN FUND","fund_id":"1020817506","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL ABSOLUTE RETURN FUND","fund_id":"1020817506","entity":"CBNA","entity_id":"23","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL ABSOLUTE RETURN FUND","fund_id":"1020817506","entity":"CBNA","entity_id":"23","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL PARTNERS MASTER FUND LP","fund_id":"1005180097","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL PARTNERS MASTER FUND LP","fund_id":"1005180097","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL PARTNERS MASTER FUND LP","fund_id":"1005180097","entity":"CBNA","entity_id":"23","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL PARTNERS MASTER FUND LP","fund_id":"1005180097","entity":"CBNA","entity_id":"23","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL PARTNERS MASTER FUND LP","fund_id":"1005180097","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"ADVENT GLOBAL PARTNERS MASTER FUND LP","fund_id":"1005180097","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"ALL","fund_id":"9999999999","entity":"ALL","entity_id":"26","region":"EMEA","region_id":"4"},{"client":"ADVENT","client_id":"115367","fund":"ALL","fund_id":"9999999999","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"ALL","fund_id":"9999999999","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"ALL","fund_id":"9999999999","entity":"CBNA","entity_id":"23","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"ALL","fund_id":"9999999999","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"ALL","fund_id":"9999999999","entity":"CGML      ","entity_id":"11","region":"EMEA","region_id":"4"},{"client":"ADVENT","client_id":"115367","fund":"AMUNDI ABSOLUTE RETURN ADVENT HEDGED CONVERTIBLE MST FD","fund_id":"1016313226","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"AMUNDI ABSOLUTE RETURN ADVENT HEDGED CONVERTIBLE MST FD","fund_id":"1016313226","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"AMUNDI ABSOLUTE RETURN ADVENT HEDGED CONVERTIBLE MST FD","fund_id":"1016313226","entity":"CBNA","entity_id":"23","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"AMUNDI ABSOLUTE RETURN ADVENT HEDGED CONVERTIBLE MST FD","fund_id":"1016313226","entity":"CBNA","entity_id":"23","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"AMUNDI ABSOLUTE RETURN ADVENT HEDGED CONVERTIBLE MST FD","fund_id":"1016313226","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"AMUNDI ABSOLUTE RETURN ADVENT HEDGED CONVERTIBLE MST FD","fund_id":"1016313226","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"HFR CA OPPORTUNITY MASTER TRUST","fund_id":"1005402162","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"HFR CA OPPORTUNITY MASTER TRUST","fund_id":"1005402162","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"HFR CA OPPORTUNITY MASTER TRUST","fund_id":"1005402162","entity":"CGMI      ","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"HFR CA OPPORTUNITY MASTER TRUST","fund_id":"1005402162","entity":"CGMI      ","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"HFR RVA ADVENT GLOBAL OPPORTUNITY MASTER TRUST","fund_id":"1005402146","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"HFR RVA ADVENT GLOBAL OPPORTUNITY MASTER TRUST","fund_id":"1005402146","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"HFR RVA ADVENT GLOBAL OPPORTUNITY MASTER TRUST","fund_id":"1005402146","entity":"CBNA","entity_id":"23","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"HFR RVA ADVENT GLOBAL OPPORTUNITY MASTER TRUST","fund_id":"1005402146","entity":"CBNA","entity_id":"23","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"HFR RVA ADVENT GLOBAL OPPORTUNITY MASTER TRUST","fund_id":"1005402146","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"HFR RVA ADVENT GLOBAL OPPORTUNITY MASTER TRUST","fund_id":"1005402146","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"HFREU RVA ADVENT GLOBAL OPPORTUNITY PLUS FUND","fund_id":"1018614053","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"HFREU RVA ADVENT GLOBAL OPPORTUNITY PLUS FUND","fund_id":"1018614053","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"HFREU RVA ADVENT GLOBAL OPPORTUNITY PLUS FUND","fund_id":"1018614053","entity":"CBNA","entity_id":"23","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"HFREU RVA ADVENT GLOBAL OPPORTUNITY PLUS FUND","fund_id":"1018614053","entity":"CBNA","entity_id":"23","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"HFREU RVA ADVENT GLOBAL OPPORTUNITY PLUS FUND","fund_id":"1018614053","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"HFREU RVA ADVENT GLOBAL OPPORTUNITY PLUS FUND","fund_id":"1018614053","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"INSTITUTIONAL BENCHMARKS SRS (MSTR FDR) LTD ADVENT CONV ARBT","fund_id":"1008688059","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"INSTITUTIONAL BENCHMARKS SRS (MSTR FDR) LTD ADVENT CONV ARBT","fund_id":"1008688059","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"INSTITUTIONAL BENCHMARKS SRS (MSTR FDR) LTD ADVENT CONV ARBT","fund_id":"1008688059","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"INSTITUTIONAL BENCHMARKS SRS (MSTR FDR) LTD ADVENT CONV ARBT","fund_id":"1008688059","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"SCIENS GROUP ALTERNATIVE STRATEGIES PCC LTD GOLD ZETA CELL","fund_id":"1008691424","entity":"ALL","entity_id":"26","region":"EMEA","region_id":"4"},{"client":"ADVENT","client_id":"115367","fund":"SCIENS GROUP ALTERNATIVE STRATEGIES PCC LTD GOLD ZETA CELL","fund_id":"1008691424","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"SCIENS GROUP ALTERNATIVE STRATEGIES PCC LTD GOLD ZETA CELL","fund_id":"1008691424","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"SCIENS GROUP ALTERNATIVE STRATEGIES PCC LTD GOLD ZETA CELL","fund_id":"1008691424","entity":"CBNA","entity_id":"23","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"SCIENS GROUP ALTERNATIVE STRATEGIES PCC LTD GOLD ZETA CELL","fund_id":"1008691424","entity":"CBNA","entity_id":"23","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"SCIENS GROUP ALTERNATIVE STRATEGIES PCC LTD GOLD ZETA CELL","fund_id":"1008691424","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"SCIENS GROUP ALTERNATIVE STRATEGIES PCC LTD GOLD ZETA CELL","fund_id":"1008691424","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"SCIENS GROUP ALTERNATIVE STRATEGIES PCC LTD GOLD ZETA CELL","fund_id":"1008691424","entity":"CGML      ","entity_id":"11","region":"EMEA","region_id":"4"},{"client":"ADVENT","client_id":"115367","fund":"SCIENS GROUP ALTERNATIVE STRATEGIES PCC LTD GOLD ZETA CELL","fund_id":"1008691424","entity":"CGML      ","entity_id":"11","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"THE ADVENT GLOBAL OPPORTUNITY MASTER FUND","fund_id":"1007526721","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"THE ADVENT GLOBAL OPPORTUNITY MASTER FUND","fund_id":"1007526721","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"THE ADVENT GLOBAL OPPORTUNITY MASTER FUND","fund_id":"1007526721","entity":"CBNA","entity_id":"23","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"THE ADVENT GLOBAL OPPORTUNITY MASTER FUND","fund_id":"1007526721","entity":"CBNA","entity_id":"23","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"THE ADVENT GLOBAL OPPORTUNITY MASTER FUND","fund_id":"1007526721","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"THE ADVENT GLOBAL OPPORTUNITY MASTER FUND","fund_id":"1007526721","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"TRANSAMERICA EVENT DRIVEN FUND","fund_id":"1020822925","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"TRANSAMERICA EVENT DRIVEN FUND","fund_id":"1020822925","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"TRANSAMERICA EVENT DRIVEN FUND","fund_id":"1020822925","entity":"CBNA","entity_id":"23","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"TRANSAMERICA EVENT DRIVEN FUND","fund_id":"1020822925","entity":"CBNA","entity_id":"23","region":"NAM","region_id":"2"},{"client":"ADVENT","client_id":"115367","fund":"TRANSAMERICA EVENT DRIVEN FUND","fund_id":"1020822925","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ADVENT","client_id":"115367","fund":"TRANSAMERICA EVENT DRIVEN FUND","fund_id":"1020822925","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"BNMX","entity_id":"25","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CBCA","entity_id":"24","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CBNA      ","entity_id":"23","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CEI","entity_id":"22","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CEIC","entity_id":"21","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CFPI      ","entity_id":"20","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGCS","entity_id":"19","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMA","entity_id":"18","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMAL","entity_id":"17","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMD","entity_id":"16","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMHK","entity_id":"15","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMIPL","entity_id":"13","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMJ","entity_id":"12","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGML","entity_id":"11","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMM","entity_id":"10","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMMPL","entity_id":"9","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMRC","entity_id":"8","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMSS","entity_id":"7","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGMUKE    ","entity_id":"6","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGPL","entity_id":"5","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CGSA","entity_id":"4","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CIBS","entity_id":"3","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CIPLC","entity_id":"2","region":"GLOBAL","region_id":"1"},{"client":"ALL","client_id":"999999","fund":"ALL","fund_id":"9999999999","entity":"CSSI","entity_id":"1","region":"GLOBAL","region_id":"1"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"ALL","fund_id":"9999999999","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"ALL","fund_id":"9999999999","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"ALL","fund_id":"9999999999","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"NSH INVESTMENTS LLC","fund_id":"1005245598","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"NSH INVESTMENTS LLC","fund_id":"1005245598","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"NSH INVESTMENTS LLC","fund_id":"1005245598","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"NSH INVESTMENTS LLC","fund_id":"1005245598","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"PECONIC PARTNERS INTERNATIONAL FUND LTD","fund_id":"1004820564","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"PECONIC PARTNERS INTERNATIONAL FUND LTD","fund_id":"1004820564","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"PECONIC PARTNERS INTERNATIONAL FUND LTD","fund_id":"1004820564","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"PECONIC PARTNERS INTERNATIONAL FUND LTD","fund_id":"1004820564","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"PERMAL BASIC INDUSTRIES LTD.","fund_id":"1005136705","entity":"ALL","entity_id":"26","region":"GLOBAL","region_id":"1"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"PERMAL BASIC INDUSTRIES LTD.","fund_id":"1005136705","entity":"ALL","entity_id":"26","region":"NAM","region_id":"2"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"PERMAL BASIC INDUSTRIES LTD.","fund_id":"1005136705","entity":"CGMI","entity_id":"14","region":"GLOBAL","region_id":"1"},{"client":"PECONIC PARTNERS","client_id":"116029","fund":"PERMAL BASIC INDUSTRIES LTD.","fund_id":"1005136705","entity":"CGMI","entity_id":"14","region":"NAM","region_id":"2"}];
	let env				: any = [{"envName":"windev"}];

	class MockHttpErrorHandler {
		handle(err) {
			console.log("ReferenceDataService:: MockHttpErrorHandler", err);
		}
	}

	class MockAppStateService {
        clearAppState() {};
        getModuleGlobalState(module, key) {};
        setModuleGlobalState(module, key, value) {};
    }

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                APP_TEST_HTTP_PROVIDERS,
                ReferenceDataService,
            ],
        });
    });

    beforeEach(inject([ReferenceDataService, AppStateService, MockBackend], (..._) => {
        [referenceDataService, appStateService, backend] = _;
    }));
    
    describe('.getMasterDataList', () => {
        let subscription;
        
        describe('When master data list is available', () => {
            it('Master data list should be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                    	body: JSON.stringify([masterDataList])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getMasterDataListServiceEndPoint);
                });
                
                referenceDataService.getMasterDataList().subscribe(isReady => {
                    expect(isReady).toBeTruthy();
                });
            });
         });
         
     	describe('When master data list is not available', () => {
    		it('Master data list should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getMasterDataListServiceEndPoint);
                });
                
                referenceDataService.getMasterDataList().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });    
    
    describe('.getEnvDetails', () => {
        let subscription;
        
        describe('When environment details available', () => {
                it('Environment details should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([env])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Get);
                        expect(conn.request.url).toEqual(getEnvironmentVersionEndPoint);
                    });
                    
                    referenceDataService.getEnvDetails().subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
     	describe('When environment details not available', () => {
    		it('Environment details should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getEnvironmentVersionEndPoint);
                });
                
                referenceDataService.getEnvDetails().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });    
    
   
});