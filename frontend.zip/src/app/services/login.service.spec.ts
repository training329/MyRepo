import {inject, TestBed} from "@angular/core/testing";
import {Router} from "@angular/router";
import {
    ResponseOptions,
    Response,
    RequestMethod,
    HttpModule
} from "@angular/http";
import {MockBackend} from "@angular/http/testing";
import {LoginService} from "./login.service";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../testing";

import {UserParams, EnvironmentVersion} from "../shared/dto";
import {MyStorage} from "../services/storage-wrapper";
import {JsonHttp} from "../services/json-http";
import {APIResponse} from '../models/api-response';
import {IdleService} from "../services/idle.service";
import {AppStateService} from "../services/app-state.service";
import {ReferenceDataService} from "../services/reference-data.service";


describe('LoginService', () => {

    let loginService: LoginService;
    let backend: MockBackend;

    let router: Router;
    let refService: ReferenceDataService;
    let appState: AppStateService;
    let idle: IdleService;

    class MockRouter {
        navigate() {
        }
    }

    class MockReferenceDataService {
        //
    }

    class MockAppStateService {
        clearAppState() {}
    }

    /**
     * We need to mock all the calls of expected to be used services,
     * also, need to ensure all the internal structures are
     *
     *     this.idleService.watch();
     *     this.idleService.idle.onTimeout.subscribe(()
     *
     */
    class subscibable {
        subscribe ( f:any ) {
            // you can do some custom testing here if required
        }
    }
    class idle {
        public onTimeout:subscibable = new subscibable();
    }
    class MockIdleService {
        public onTimeout:any;
        public idle:idle = new idle();
        watch() {}
    }


    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: Router,
                    useClass: MockRouter,
                },
                {
                    provide: ReferenceDataService,
                    useClass: MockReferenceDataService,
                },
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: IdleService,
                    useClass: MockIdleService,
                },

                APP_TEST_HTTP_PROVIDERS,
                LoginService,
            ],
        });
    });


    /**
     *
     *     constructor(
     private router:Router,
     private http:JsonHttp,
     private refDataService: ReferenceDataService,
     private appStateService:AppStateService,
     private idleService:IdleService)
     */

    beforeEach(inject([LoginService, MockBackend], (..._) => {
        [loginService, backend] = _;
    }));

    describe('.login', () => {
        it('can login', (done) => {
            backend.connections.subscribe(conn => {
                conn.mockRespond(new Response(new ResponseOptions({
                    body: JSON.stringify({
                        token: 'my jwt',
                        email: 'test@test.com',
                        password:'secret',
                        name:'test',
                        soeid:'test@test.com',
                        userRole:{race_role:true},
                        isCBAAccessible:true,
                        isAuthenticated:true,
                        ssoSessionID: 'my jwt',
                        statusCode:'EWS_200'
            }),
                })));
                expect(conn.request.method).toEqual(RequestMethod.Post);
                expect(conn.request.url).toEqual('/api/sso/authenticate');
                expect(conn.request.json()).toEqual({
                    soeid: 'test@test.com',
                    password: 'secret',
                });
            });
            // Check Loggin function
            loginService.login('test@test.com', 'secret').subscribe(() => {
                // Step 1 Check that all required data is stored after login
                expect(localStorage.getItem('jwt')).toEqual('my jwt');
                expect(localStorage.getItem('userParams_name')).toEqual('test');
                expect(localStorage.getItem('userParams_email')).toEqual('test@test.com');
                expect(localStorage.getItem('userParams_soeid')).toEqual('test@test.com');
                expect(localStorage.getItem('userParams_role')).toEqual('true');
                expect(localStorage.getItem('userParams_cbaAccess')).toEqual('true');
                // Step 2 check that getUserParams returns all the required params
                expect(
                    (loginService.getUserParams() as any).name
                ).toEqual('test');
                expect(
                    (loginService.getUserParams() as any).email
                ).toEqual('test@test.com');
                expect(
                    (loginService.getUserParams() as any).soeid
                ).toEqual('test@test.com');
                expect(
                    (loginService.getUserParams() as any).role
                ).toEqual(true);

                done();
            });

        });
    }); // .login

    describe('.logout', () => {
        it('can logout', () => {
            localStorage.setItem('jwt', 'my jwt');
            loginService.logout();
            expect(localStorage.getItem('jwt')).toBeFalsy();
        });
    }); // .logout

    describe('.isSignedIn', () => {
        describe('when not signed in', () => {
            it('should be false', () => {
                expect(loginService.isSignedIn()).toBeFalsy();
            });
        });

        describe('when signed in', () => {
            beforeEach(() => localStorage.setItem('jwt', 'dummy'));
            it('should be true', () => {
                expect(loginService.isSignedIn()).toBeTruthy();
            });
        });
    }); // .isSignedIn

    //TODO: Create the rest of test cases for all the methods of LoginService

});

