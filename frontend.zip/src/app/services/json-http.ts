import {Observable} from "rxjs/Observable";
import {Injectable} from "@angular/core";

import "rxjs/add/operator/catch";
import "rxjs/add/observable/throw";
import "rxjs/add/observable/empty";
import { SpinnerService } from "./spinner/spinner.service";

import {
    Http,
    RequestOptionsArgs,
    RequestOptions,
    Response,
    Headers,
    URLSearchParams
} from "@angular/http";

const mergeAuthToken = ( options: RequestOptionsArgs ) => {
    let newOptions = new RequestOptions( {}).merge( options );
    let newHeaders = new Headers( newOptions.headers );
    newHeaders.set( 'x-auth-token', localStorage.getItem( 'jwt' ) );
    newHeaders.set( 'Cache-Control', 'no-cache, no-store, max-age=0, must-revalidate' );
    newHeaders.set( 'Expires', '0');
    newHeaders.set( 'Pragma', 'no-cache');
    newOptions.headers = newHeaders;
    return newOptions;
};

@Injectable()
export class JsonHttp {

    // TODO: Clean up unused code
    // promiseList: Array<Promise<any> | Subscription> = [];

    // TODO: Please add Error condition processing from server here - like 404 unauthorized, timeout, closed socket etc.


    constructor( private http: Http, private spinner: SpinnerService ) {
    	console.debug("JsonHttp::constructor");

        // default state:
        this.spinner.forceHide();
    }

    get( url: string, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::get ", url, options);
        this.spinner.show();
        let request: Observable<Response> = this.http.get( url, mergeAuthToken( options ) )
            .finally(() => {
                this.spinner.hide();
            });
        return request;
    }

    post( url: string, body: any, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::post ", url, options);
        this.spinner.show();
        let request: Observable<Response> = this.http.post( url, body, mergeAuthToken( options ) )
            .finally(() => {
                this.spinner.hide();
            });
        return request;
    }

    put( url: string, body: any, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::put ", url, options);
    	this.spinner.show();
        let request: Observable<Response> = this.http.put( url, body, mergeAuthToken( options ) )
            .finally(() => {
                this.spinner.hide();
            });
        return request;
    }

    delete( url: string, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::delete ", url, options);
    	this.spinner.show();
        let request: Observable<Response> = this.http.delete( url, mergeAuthToken( options ) )
            .finally(() => {
                this.spinner.hide();
            });
        return request;
    }

    patch( url: string, body: any, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::patch ", url, options);
    	this.spinner.show();
        let request: Observable<Response> = this.http.patch( url, body, mergeAuthToken( options ) )
            .finally(() => {
                this.spinner.hide();
            });
        return request;
    }

    head( url: string, options?: RequestOptionsArgs ): Observable<Response> {
    	console.debug("JsonHttp::head ", url, options);
    	this.spinner.show();
        let request: Observable<Response> = this.http.head( url, mergeAuthToken( options ) )
            .finally(() => {
                this.spinner.hide();
            });
        return request;
    }
    buildUlrParamFromObject(object:any):URLSearchParams{
        let params = new URLSearchParams();
        for (let key in object) {
            if (object.hasOwnProperty(key)) {
                params.set(key, object[key])
            }
        }
        return params;
    }
}
