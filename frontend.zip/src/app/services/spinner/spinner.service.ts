import { Injectable, Optional, SkipSelf } from '@angular/core';
import { Subject } from 'rxjs/Subject';

export interface SpinnerState {
  show: boolean;
}

@Injectable()
export class SpinnerService {
  private spinnerSubject = new Subject<SpinnerState>();
  private spinnerCounter:number = 0
  spinnerState = this.spinnerSubject.asObservable();

  constructor(@Optional() @SkipSelf() prior: SpinnerService) {
    console.debug('SpinnerService::constructor ');
    if (prior) { return prior; }
  }

  show() {
    
    this.spinnerSubject.next(<SpinnerState>{ show: true });
    this.spinnerCounter++;
    console.debug('SpinnerService::show '+this.spinnerCounter);
  }

  hide() {
    this.spinnerCounter = (this.spinnerCounter > 0) ? this.spinnerCounter - 1 : 0; 
    if(this.spinnerCounter == 0){
        this.spinnerSubject.next(<SpinnerState>{ show: false });
    }
    console.debug('SpinnerService::hide '+this.spinnerCounter);
  }
  
  
  forceHide(){
      console.debug('SpinnerService::forceHide '+this.spinnerCounter);
      this.spinnerCounter = 0;
      this.hide();
  }
}
