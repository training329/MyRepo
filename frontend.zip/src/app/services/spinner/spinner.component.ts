import { Component, OnDestroy, OnInit, trigger, state, style, transition, animate } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { SpinnerState, SpinnerService } from './spinner.service';


const inactiveStyle = style({
    opacity: 0,
    transform: 'translateY(-40px)'
});
const timing = '.3s ease';

@Component({
  selector: 'cba-spinner',
  styleUrls: ['./spinner.component.scss'],
  templateUrl: './spinner.component.html',
  animations: [
      trigger('flyInOut', [
          transition('void => *', [
              inactiveStyle,
              animate(timing)
          ]),
          transition('* => void', [
              animate(timing, inactiveStyle)
          ])
      ])
  ]
})
export class SpinnerComponent implements OnDestroy, OnInit {
	visible = false;

	state = {message: 'Loading ...'};
  
	private spinnerStateChanged: Subscription;

	constructor(private spinnerService: SpinnerService) { 
		console.debug("SpinnerComponent::constructor");
	}

	ngOnInit() {
		console.debug("SpinnerComponent::ngOnInit");
		//componentHandler.upgradeDom();
		this.spinnerStateChanged = this.spinnerService.spinnerState
			.subscribe((state: SpinnerState) => this.visible = state.show);
	}

	ngOnDestroy() {
		console.debug("SpinnerComponent::ngOnDestroy");
		this.spinnerStateChanged.unsubscribe();
	}
}
