import {Injectable} from "@angular/core";

import {
    CanActivate,
    Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from "@angular/router";
import {LoginService} from "./login.service";

@Injectable()
export class PrivatePageGuard implements CanActivate {

    constructor(private router:Router, private loginService:LoginService) {
    	console.debug("PrivatePageGuard::constructor");
    }

    canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot) {
    	console.debug("PrivatePageGuard::canActivate " , route, state);
        var result = this.loginService.isSignedIn();
        if (!result) {
            this.router.navigate(['/login']);
            console.debug("PrivatePageGuard::canActivate::is Not SignedIn!")
        } else {
            console.debug("PrivatePageGuard::canActivate::user is SignedId!")
        }
        return result;
    }

}