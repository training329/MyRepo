import {Observable} from 'rxjs/Observable';
import {Subject} from "rxjs/Rx";

export class EventBusService
{
    private bus:Subject<CustomEvent> = new Subject<CustomEvent>();

    constructor() {
        console.debug('EventBusService::constructor');
    }
    
    dispatch(data:CustomEvent){
        console.debug('EventBusService::dispatch');
        this.bus.next(data);
    }

    listen(type:string):Observable<CustomEvent> {
        console.debug('EventBusService::listen: type', type);
        return this.bus.filter(event => event.type === type);
    }
}