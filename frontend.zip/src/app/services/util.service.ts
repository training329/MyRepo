import {Injectable} from '@angular/core';
//import {Observable} from 'rxjs/Observable';
//import {Response, RequestOptionsArgs, ResponseContentType} from '@angular/http';
//import "../common/rxjs-operators";

import * as toastr from 'toastr';

// Application
import {JsonHttp} from "../services/json-http";
import {HttpErrorHandler} from "./http-error-handler";

@Injectable()
export class UtilService {
	
	static readonly noRecordsFoundMessage : string = "No records found.";

	constructor(private http:JsonHttp,
				private errorHandler:HttpErrorHandler) {
        console.debug("UtilService::constructor");
    }
	
	/*exportToExcel(url, body, fileName) {
        console.debug('UtilService::exportToExcel', url, body);
        this.getFileData(url, body).subscribe(resp => {
    		this.saveFile(new Blob([resp._body], {type: "application/vnd.ms-excel"}), fileName);
        }, e => {
        	toastr.error('Error while generating excel report. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    };
    
    getFileData(url, body) : Observable<any> {
        console.debug('UtilService::getFileData', url, body);
        var options : RequestOptionsArgs = { responseType: ResponseContentType.ArrayBuffer };
        return this.http.post(url, body, options).map((res:Response) => res);
    };

	saveFile (blob, fileName) {
		console.debug('UtilService::saveFile', blob, fileName);
		if (window.navigator.msSaveOrOpenBlob) { // for IE
	        navigator.msSaveOrOpenBlob(blob, fileName);
	    } else {
	        var link = document.createElement('a');
	        link.href = window.URL.createObjectURL(blob);
	        link.download = fileName;
	        link.click();
	        window.URL.revokeObjectURL(link.href);
	    }
	}*/
	
	showNoRecordMessage(dataTableRef: any, size: number) {
		console.debug('UtilService::showNoRecordMessage', dataTableRef, size);
		if (size == 0) {
			dataTableRef.emptyMessage = UtilService.noRecordsFoundMessage;
		} else {
			dataTableRef.emptyMessage = "";
		}
	}
	
	exportToExcel(url) {
		console.debug('UtilService::exportToExcel ', url);
		window.open(url);
    };
	
}