// Framework
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'underscore';

//Application Models
import { ChartFilter } from '../models/chart-filter';

//Application Services
import {HttpErrorHandler} from "../services/http-error-handler";
import { ClientOverviewService } from './client-overview.service';

@Component({
	selector:'client-overview',
	templateUrl:'client-overview.component.html',
	styleUrls:['client-overview.component.scss'],
	providers: [HttpErrorHandler],
	host: {
        '(window:resize)': 'onResize($event)'
    }
})

export class ClientOverviewComponent implements OnInit {
	
	private chartFilter: ChartFilter; 
    private showGMVChart:boolean;

	constructor(private router: Router,
				private errorHandler: HttpErrorHandler,
				private clientOverviewService: ClientOverviewService) {
		console.debug('ClientOverviewComponent::constructor');
	}

	ngOnInit(): void {
		console.debug('ClientOverviewComponent::ngOnInit');
	}
	
	onFilterChanges(event): void {
		console.debug('ClientOverviewComponent::onFilterChanges ', event);
		this.chartFilter = event.chartFilterObj;
	}
	
	
	onTabOpen(event): void {
		console.debug('ClientOverviewComponent::onTabOpen ', event);
	    if(event.index == 1){
	        this.showGMVChart = true;
	    }
	}
	
	onTabClose(event): void{
		console.debug('ClientOverviewComponent::onTabClose ', event);
        if(event.index == 1){
            this.showGMVChart = false;
        }
    }
	
	onResize(event) {
        console.debug("ClientOverviewComponent::onResize width: " + event.target.innerWidth + " height: " + event.target.innerHeight);
    }
}
