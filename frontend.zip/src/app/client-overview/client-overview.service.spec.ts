import {inject, TestBed} from "@angular/core/testing";
import {ResponseOptions, Response, RequestMethod, HttpModule} from "@angular/http";
import {MockBackend} from "@angular/http/testing";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../testing";
import {MockError, MockRouter, MockReferenceDataService, MockAppStateService, MockIdleService, MockHttpErrorHandler} from '../testing/mock.services';
import {JsonHttp} from "../services/json-http";

import {AppStateService} from  "../services/app-state.service";
import {ClientOverviewService} from "./client-overview.service";
import {HttpErrorHandler} from "../services/http-error-handler";

//Application model
import {ChartFilter} from '../models/chart-filter';

//Service End Point URI
const getClientsServiceEndPoint = '/api/clientoverview/getClientList';
const getFundsServiceEndPoint = '/api/clientoverview/getFundList/';
const getRegionsServiceEndPoint = '/api/clientoverview/getRegionList/';
const getCOBDatesServiceEndPoint = '/api/clientoverview/getCOBDateList';
const getCOBDatesMonthlyServiceEndPoint = '/api/clientoverview/getMonthlyCOBDateList';

const getFinancingBalanceServiceEndPoint = '/api/clientoverview/getFinancingBalanceDetails/';
const getEquityBalanceServiceEndPoint = '/api/clientoverview/getEquityBalanceDetails/';
const getBalanceSheetROAServiceEndPoint = '/api/clientoverview/getBalanceSheetROA/';
const getRevenueServiceEndPoint = '/api/clientoverview/getRevenue/';
const getSecurityCountryRiskServiceEndPoint = '/api/clientoverview/getSecurityCountryRisk/';
const getSecurityProductServiceEndPoint = '/api/clientoverview/getSecurityProduct/';
const getSecuritySectorServiceEndPoint = '/api/clientoverview/getSecuritySector/';
const getSecurityMarketCapServiceEndPoint = '/api/clientoverview/getSecurityMarketCap/';

describe('ClientOverviewService', () => {

    let clientOverviewService	: ClientOverviewService;
    let backend					: MockBackend;
	let appStateService			: AppStateService;

	let selectedClient	: string = 'ALL';
	let selectedFund	: string  = 'ALL';
	let selectedRegion	: string = 'GLOBAL';
	let selectedCOBDate	: number = 20170206;
	let type			: string = 'D';
	
	let chartFilter		: ChartFilter = new ChartFilter();
	chartFilter.type 	= type;
	chartFilter.cob_date= selectedCOBDate;
	chartFilter.client 	= selectedClient;
	chartFilter.fund 	= selectedFund;
	chartFilter.region 	= selectedRegion;

	let clients : any = [{"value":"155058","text":"ZAZOVE"},{"value":"178173","text":"LNG"},{"value":"115834","text":"JP MORGAN INVESTMENT MGMT"},{"value":"259263","text":"FOLGER HILL"},{"value":"201286","text":"SINOPAC AM"},{"value":"173713","text":"SMITH"},{"value":"309850","text":"CITIGROUP GLOBAL MARKETS (PTY) LTD  - SOUTH AFRICA"},{"value":"181113","text":"STONE TOWER"},{"value":"155045","text":"AXA ROSENBERG INVESTMENT"},{"value":"115828","text":"JMB CAPITAL"},{"value":"155049","text":"FIRST PRUDENTIAL MARKETS PTY LTD"},{"value":"213274","text":"DEUTSCHE ASSET MGMT"},{"value":"115821","text":"JB INVESTMENTS MANAGEMENT LLC"},{"value":"262425","text":"PRO-ALPHA INVESTMENTS LTD"},{"value":"172859","text":"GLENEAGLE SECURITIES (AUST) PTY LTD"},{"value":"115824","text":"JD CAPITAL"},{"value":"253964","text":"INVESTEC BANK LTD"},{"value":"172610","text":"GOSHEN"},{"value":"155051","text":"JOHOCAP"},{"value":"194663","text":"MIO"},{"value":"192000","text":"VISIUM"},{"value":"321971","text":"GPI CAPITAL"},{"value":"258392","text":"AZIMUT SGR SPA"},{"value":"115816","text":"JABRE CAPITAL PARTNERS"},{"value":"238342","text":"SYMPHONY ASSET MANAGEMENT LLC"},{"value":"179283","text":"SURSUM CAPITAL"},{"value":"115811","text":"IREALITY INVESTMENTS LIMITED"},{"value":"169486","text":"FLOWERING TREE INVESTMENT MANAGEMENT"},{"value":"115815","text":"IVORY CAPITAL"},{"value":"190032","text":"GULFMENA"},{"value":"203487","text":"TRINITUS ASSET"},{"value":"202399","text":"ALTANA"},{"value":"225279","text":"BUTLER"},{"value":"239429","text":"FRONT STREET"},{"value":"115805","text":"INFINITY CAPITAL LLC"},{"value":"156157","text":"LINDEN ADVISORS"},{"value":"115807","text":"ING ALTERNATIVE ASSET MGMT LLC"},{"value":"168380","text":"LANTERNE"},{"value":"169230","text":"HULL"},{"value":"115801","text":"III OFFSHORE ADVISORS (CR)"},{"value":"115802","text":"IMPALA"},{"value":"115804","text":"INDUS CAPITAL "},{"value":"205434","text":"BARBICAN CAPITAL"},{"value":"193798","text":"COATUE"},{"value":"317218","text":"PRIVATEER"},{"value":"204101","text":"SANKATY"},{"value":"172874","text":"PIVOTAL INVESTMENTS"},{"value":"204581","text":"NEWTYN"},{"value":"190047","text":"ROUNDKEEP"},{"value":"180696","text":"CITIBANK OVERSEAS INVESTMENT CORPORATION"},{"value":"115874","text":"UNITED GULF BANK"},{"value":"115875","text":"KYNIKOS"},{"value":"115877","text":"LANSDOWNE PARTNERS"},{"value":"115879","text":"LAZARD"},{"value":"167475","text":"LODESTAR CAPITAL PARTNERS"},{"value":"169656","text":"SYMPHONY FINANCIAL"},{"value":"191581","text":"TGW CAP"},{"value":"252666","text":"ELEMENT"},{"value":"191104","text":"MONECOR (LONDON) LIMITED"},{"value":"181313","text":"TANTALLON CAPITAL"},{"value":"238593","text":"HUTCHIN"},{"value":"364030","text":"MEITAV DS PROVIDENT FUNDS & PENSION LTD"},{"value":"216101","text":"DROMEUS"},{"value":"115863","text":"KINGSFORD "},{"value":"115865","text":"KKR"},{"value":"204119","text":"BALYASNY"},{"value":"115867","text":"KLS ASSET MGT"},{"value":"167473","text":"AMP CAPITAL INVESTORS"},{"value":"220820","text":"EVEREST"},{"value":"202189","text":"LONESTAR"},{"value":"167464","text":"TRIBRIDGE INVST PARTNERS LTD"},{"value":"169400","text":"FIREFLY"},{"value":"167466","text":"DYMON ASIA CAPITAL"},{"value":"167469","text":"HARMONY CAPTL PARTNERS"},{"value":"115872","text":"KSE ADVISORS"},{"value":"115873","text":"KAMUNTING"},{"value":"172810","text":"PENSO"},{"value":"190026","text":"VIRTU"},{"value":"115618","text":"FAIRFIELD GREENWICH ADVISORS"},{"value":"213089","text":"SIGMA"},{"value":"179242","text":"DELAVENNE"},{"value":"115611","text":"EMERGING SOVEREIGN GROUP"},{"value":"115853","text":"K CAPITAL"},{"value":"115612","text":"ETON PARK "},{"value":"115613","text":"EVOLUTION CAPITAL MANAGEMENT"},{"value":"115614","text":"EXANE STRUCTURED ASSET MGMT"},{"value":"229427","text":"BELVEDERE"},{"value":"173938","text":"KAIOG"},{"value":"115858","text":"KEVIAN CAPITAL MANAGEMENT LLC"},{"value":"221940","text":"PILOT VIEW"},{"value":"115859","text":"KEYCORP (CR)"},{"value":"210804","text":"BROOKSIDE"},{"value":"195921","text":"VARNA"},{"value":"204134","text":"URWICK"},{"value":"370729","text":"ICB CHINA"},{"value":"115862","text":"KINGDON"},{"value":"115607","text":"EPIC ASSET MGMT"},{"value":"178142","text":"AXIA"},{"value":"195937","text":"683"},{"value":"115600","text":"EMPYREAN PARTNERS"},{"value":"115601","text":"EMSO ASSET MANAGEMENT"},{"value":"115843","text":"KAIROS"},{"value":"167493","text":"CAVENAGH CAPITAL"},{"value":"180680","text":"SENRIGAN"},{"value":"168100","text":"BATTLEBRIDGE INVESTMENT"},{"value":"115605","text":"ENERGYO SOLUTIONS RUSSIA"},{"value":"115606","text":"BBT - BASS BROTHERS"},{"value":"168576","text":"TYRUS"},{"value":"115850","text":"KAZIMIR PARTNERS LTD"},{"value":"203051","text":"AUSCAP ASSET MGMT"},{"value":"230887","text":"EFFISSIMO CAP"},{"value":"169060","text":"OPVS GROUP"},{"value":"115434","text":"BLACKROCK"},{"value":"115435","text":"BAREP ASSET MGMT"},{"value":"115677","text":"FISHER INVESTMENT"},{"value":"115436","text":"BRIDGE PARTNERS INV MGMT LTD"},{"value":"115437","text":"BASSO"},{"value":"115438","text":"BAYERISCHE LANDESBANK"},{"value":"115439","text":"BAYSIDE"},{"value":"250292","text":"SCOUT"},{"value":"115680","text":"FLATIRON CAPITAL MGMT"},{"value":"315208","text":"KONTIKI CAPITAL"},{"value":"225097","text":"COVENANT CAP"},{"value":"115442","text":"BBT CAPITAL MGMT"},{"value":"115685","text":"FLORIN INVESTMENT MANAGEMENT"},{"value":"175730","text":"PHOENIXINVEST GROUP"},{"value":"192071","text":"TENOR"},{"value":"115424","text":"ATOM CAPITAL MGMT PTE LTD"},{"value":"115425","text":"ATP"},{"value":"115426","text":"ATTUNGA CAPITAL PTY LTD"},{"value":"115427","text":"GAM INTERNATIONAL"},{"value":"115429","text":"AUTONOMY CAPITAL RESEARCH"},{"value":"243526","text":"ERBF"},{"value":"196205","text":"ORACLE CAPITAL"},{"value":"115670","text":"FINTECH"},{"value":"251147","text":"HAYMAN"},{"value":"115671","text":"FINISTERRE CAPITAL"},{"value":"115430","text":"AVENUE CAPITAL GROUP"},{"value":"115431","text":"AWAL BANK BSC"},{"value":"115673","text":"FIR TREE"},{"value":"172456","text":"RIDLEY PARK CAPITAL LLP"},{"value":"172218","text":"CAHIR"},{"value":"115674","text":"FIRST QUADRANT CORP"},{"value":"174878","text":"PENDRAGON CAP"},{"value":"377374","text":"OPERA TRADING CAPITAL SA"},{"value":"170276","text":"OCP ASIA"},{"value":"240465","text":"VISTA"},{"value":"367594","text":"SWISS RE"},{"value":"115412","text":"ASCEND"},{"value":"115654","text":"FEDERATED"},{"value":"115413","text":"ASEAN INVESTMENT ADV PTE LTD"},{"value":"115897","text":"LIONSTONE CAPITAL"},{"value":"221980","text":"WHITEHAVEN"},{"value":"115899","text":"LOCCGT"},{"value":"115418","text":"ASUKA ASSET MANAGEMENT"},{"value":"205023","text":"LIBERTYSHIP"},{"value":"115422","text":"ATLANTIC TRUST "},{"value":"172480","text":"PARTNER FUND MANAGEMENT"},{"value":"115409","text":"ARSAGO"},{"value":"346167","text":"PICTET"},{"value":"115403","text":"ARGYLE"},{"value":"115404","text":"ARH LIMITED SA"},{"value":"115405","text":"ARISTEIA CAPITAL"},{"value":"115889","text":"LA FRANCAISE DES PLACEMENTS"},{"value":"115406","text":"ARJAVA CAPITAL"},{"value":"115407","text":"ARONSON JOHNSON ORTIZ "},{"value":"115408","text":"ARROWGRASS"},{"value":"238171","text":"IMMA CAPITAL"},{"value":"232867","text":"LUXOR"},{"value":"251124","text":"TEKNE"},{"value":"115890","text":"SUPERANNUATION SVS CO PTY LTD"},{"value":"115891","text":"LIBERTY"},{"value":"115892","text":"LIF PTY LIMITED"},{"value":"115410","text":"ARTHA CAPITAL MGMT"},{"value":"115894","text":"LINK CAPITAL ADVISORS"},{"value":"175981","text":"ICAHN"},{"value":"116326","text":"TREMBLANT CAPITAL MGMT LLC"},{"value":"116325","text":"TRAVELERS ALTERNATIVE INV"},{"value":"116328","text":"CITI CAPITAL ADVISORS"},{"value":"207465","text":"QUANTEDGE CAP"},{"value":"221525","text":"GRAYS CREEK"},{"value":"170003","text":"BLUEMOUNTAIN CAPITAL MANAGEMENT"},{"value":"116331","text":"TURNER PARTNERS"},{"value":"174849","text":"TOPNI "},{"value":"116330","text":"TUDOR"},{"value":"115485","text":"CALYPSO CAPITAL LIMITED"},{"value":"116332","text":"TWIN CAPITAL MANAGEMENT "},{"value":"116335","text":"ANALYTIC INVESTORS"},{"value":"115487","text":"CAMBRIDGE PLACE"},{"value":"115488","text":"CAMDEN"},{"value":"116334","text":"TYNAN "},{"value":"179298","text":"BLACK ANT"},{"value":"219696","text":"NANTAHALA CAPITAL MGMT"},{"value":"115467","text":"BREVAN HOWARD ASSET MGMT LLP"},{"value":"221993","text":"CITI PRIME FINANCE - FUTURES & OTC CLEARING (FIRM)"},{"value":"116315","text":"TORREY PINES CAPITAL MGMT"},{"value":"115468","text":"BRIDGE CAPITAL INVESTMENTS"},{"value":"115469","text":"BRIDGEWATER ASSET MGMT"},{"value":"116316","text":"TPG-AXON CAPITAL MGT LLC"},{"value":"220423","text":"CAPSTONE"},{"value":"115471","text":"BROADMARK"},{"value":"115472","text":"BROAD PEAK INVESTMENT ADVISERS"},{"value":"115473","text":"BLACKROCK NY"},{"value":"115474","text":"BROOKVILLE CAPITAL MGMT"},{"value":"116322","text":"TRAFALGAR"},{"value":"115475","text":"ROBERT BRUCE MGMT CO INC"},{"value":"115476","text":"BSG CAPITAL MARKETS PCC LTD"},{"value":"358672","text":"HOUND PARTNERS"},{"value":"116323","text":"TRAFELET"},{"value":"171563","text":"PRUDENT ASIA"},{"value":"181126","text":"CORRE"},{"value":"168191","text":"FINANCIAL TRANSACTION HOUSE"},{"value":"168193","text":"GLS CAPITAL"},{"value":"217284","text":"PETERS CAP GROUP"},{"value":"116304","text":"TENSOR OPPORTUNITY LTD"},{"value":"239071","text":"INFINITY Q"},{"value":"168195","text":"BSN CAPITAL PARTNERS"},{"value":"116306","text":"THIRD WAVE "},{"value":"169042","text":"D AND P"},{"value":"116305","text":"TEQUESTA CAPTL ADVISORS [SCS]"},{"value":"168197","text":"OBLIGEST MANAGEMENT"},{"value":"223724","text":"TACONIC CAPITAL"},{"value":"116308","text":"THREADNEEDLE ASSET MGMT LONDON"},{"value":"116307","text":"THIRD POINT PARTNERS"},{"value":"223967","text":"ZIMMER PARTNERS"},{"value":"168199","text":"OTUS CAPITAL MGMT"},{"value":"115461","text":"BOXER CAPITAL"},{"value":"173539","text":"YORK"},{"value":"115462","text":"BOYER ALLAN INVESTMENT MGMT"},{"value":"191162","text":"WEDGE"},{"value":"115463","text":"BRIGHTPOINT"},{"value":"116311","text":"TIGER"},{"value":"115464","text":"BRACEBRIDGE"},{"value":"172687","text":"CENTAUR"},{"value":"115465","text":"BRAHMA "},{"value":"116313","text":"TISBURY CAPITAL"},{"value":"229273","text":"PHINEUS PARTNERS"},{"value":"173530","text":"METROPOLITAN CAPITAL"},{"value":"229271","text":"ARMORY FUNDS"},{"value":"191167","text":"GLENROCK"},{"value":"181135","text":"STONE BEACH"},{"value":"999999","text":"ALL"},{"value":"115445","text":"VALLEA/BELLE VUE CONSEILS"},{"value":"208102","text":"WOODBINE"},{"value":"115447","text":"BERKLEY CAPITAL MANAGEMENT LTD"},{"value":"168189","text":"DE BORTOLI"},{"value":"115690","text":"FOREST"},{"value":"115691","text":"FORTIS INVESTMENTS FRANCE"},{"value":"173527","text":"LUXOR CAPITAL"},{"value":"229269","text":"WEATHERBIE CAP"},{"value":"115450","text":"BLACK RIVER"},{"value":"115692","text":"FORUM EUROPEAN REALTY INCOME"},{"value":"115452","text":"BLACKSTONE"},{"value":"116300","text":"TECHARI "},{"value":"115453","text":"BLACKHORSE ASSET MANAGEMENT PL"},{"value":"115454","text":"BLUEBAY"},{"value":"116302","text":"TENFIELD CAPITAL MGMT LTD"},{"value":"229267","text":"KELLNER PRIVATE"},{"value":"172436","text":"OCCAM ASSET MANAGEMENT LLP"},{"value":"116301","text":"TECHINVEST"},{"value":"229264","text":"CONTEXT CAPITAL"},{"value":"240283","text":"NEUBERGER BERMAN"},{"value":"191706","text":"AL DHABI"},{"value":"176790","text":"CYGNUS"},{"value":"406502","text":"PENNANT CAPITAL"},{"value":"224832","text":"CREDIT SUISSE HEDGING-GRIFFO"},{"value":"116006","text":"OSS"},{"value":"186116","text":"CANDRIAM"},{"value":"186358","text":"METAGE"},{"value":"208119","text":"LOCUST"},{"value":"116010","text":"OCH-ZIFF"},{"value":"116254","text":"STANDARD PACIFIC"},{"value":"116011","text":"PACIFIC HARBOR HOLDINGS"},{"value":"116253","text":"SSI INVESTMENT MANAGEMENT"},{"value":"116256","text":"STANDARD BANK JERSEY"},{"value":"116016","text":"PANTERA CAPITAL MGMT LP"},{"value":"180814","text":"TALPION"},{"value":"176300","text":"EDOMA"},{"value":"239089","text":"OMERS"},{"value":"116238","text":"SPUTNIK GROUP LTD"},{"value":"175209","text":"HARBINGER"},{"value":"115396","text":"AQR"},{"value":"115398","text":"ARAVALI PARTNERS LLC"},{"value":"116002","text":"ORION CAPITAL"},{"value":"115399","text":"ARBIC MANAGEMENT"},{"value":"116004","text":"ORN CAPITAL"},{"value":"172174","text":"GDX"},{"value":"270962","text":"LESTE"},{"value":"115392","text":"SAIERS"},{"value":"175480","text":"CMB INTERNATIONAL"},{"value":"189844","text":"CONATUS"},{"value":"116228","text":"SOUTHPOINT CAPITAL"},{"value":"115382","text":"ALLEGRO INVESTMENT CORP SA"},{"value":"115383","text":"ALLIANCE "},{"value":"115385","text":"ALTIMA PARTNERS"},{"value":"115386","text":"AM INVESTMENT"},{"value":"167613","text":"MARATHON RESOURCE INVESTMENTS"},{"value":"115389","text":"STEADFAST"},{"value":"176323","text":"FORTEN"},{"value":"168949","text":"ARDON"},{"value":"179832","text":"FIREBRICK CAP MGMT"},{"value":"178500","text":"ALCHEMY PARTNERS"},{"value":"325762","text":"GAM SWISS"},{"value":"175230","text":"HORIZON"},{"value":"196134","text":"TRAXIS"},{"value":"211777","text":"APQ"},{"value":"115381","text":"ODYSSEY "},{"value":"207296","text":"MSK CAPITAL"},{"value":"211790","text":"BANCO ITAU"},{"value":"115368","text":"AEW "},{"value":"115369","text":"AGAMAS CAPITAL MANAGEMENT LP (R)"},{"value":"218186","text":"ROBECO"},{"value":"219032","text":"BALCONY PARTNERS"},{"value":"115371","text":"AIG"},{"value":"115373","text":"ADVANCED INVESTMENT TECHNIQUES"},{"value":"116221","text":"SOLENT"},{"value":"115375","text":"AKANTHOS CAPITAL MGMT"},{"value":"116223","text":"SOROS"},{"value":"115377","text":"ALADDIN CAPITAL MGMT"},{"value":"174376","text":"FORTRESS INVEST GROUP LLC"},{"value":"175461","text":"INSTINCT ASSET MANAGEMENT"},{"value":"115370","text":"AMERICAN HOME MTG"},{"value":"154967","text":"TAM"},{"value":"155818","text":"TEGEAN"},{"value":"116296","text":"TANDEM "},{"value":"116053","text":"PLATINUM INVESTMENT MANAGEMENT"},{"value":"116298","text":"CHILDRENS INVESTMENT FUND MGMT"},{"value":"116056","text":"SPARX ASIA INVESTMENT ADVISORS LTD"},{"value":"116055","text":"PMA CAPITAL MGMT LTD"},{"value":"116297","text":"TANG"},{"value":"177836","text":"ALPINE"},{"value":"116058","text":"POLLUX CAP ADMIN DE RECURSOS"},{"value":"116057","text":"POGAN INVEST CORP"},{"value":"116059","text":"POLYGON"},{"value":"116290","text":"CITI ALTERNATIVE INVESTMENTS"},{"value":"116050","text":"P&K CAPITAL SA"},{"value":"116294","text":"SYSTEIA CAPITAL MGMT"},{"value":"116051","text":"PLAINFIELD ASSET MGMT LLC"},{"value":"237704","text":"STARK OFF"},{"value":"116293","text":"SYCOMORE ASSET MGMT"},{"value":"346661","text":"TRAFALGAR HONG KONG"},{"value":"254064","text":"ICBC INTL"},{"value":"116039","text":"PERRY PARTNERS"},{"value":"202860","text":"BLUECREST CAPITAL"},{"value":"116043","text":"PHARO"},{"value":"116044","text":"PHAROS INVESTMENTS LTD"},{"value":"264090","text":"LABMEX"},{"value":"116046","text":"PINE RIVER"},{"value":"116049","text":"PI "},{"value":"212417","text":"CUBE"},{"value":"172133","text":"RENTA4 SOCIEDAD DE VALORES SA"},{"value":"116283","text":"SUTTONBROOK CAPITAL"},{"value":"116282","text":"SUSQUEHANNA INV"},{"value":"183026","text":"ARBAT"},{"value":"156920","text":"ROUND TABLE"},{"value":"219068","text":"PERELLA WEINBERG PARTNERS"},{"value":"116029","text":"PECONIC PARTNERS"},{"value":"166961","text":"ABSOLUTE INVESTMENT"},{"value":"203711","text":"SALIENT"},{"value":"249913","text":"YGD ASSET MANAGEMENT (HK) LTD"},{"value":"116032","text":"PENDRAGON"},{"value":"116031","text":"PELOTON PARTNERS LLP"},{"value":"116273","text":"STRATEGIC VALUE "},{"value":"116034","text":"PENTALPHA CAPITAL"},{"value":"258866","text":"GATES"},{"value":"116035","text":"PENTWATER"},{"value":"116038","text":"PETRUS"},{"value":"116037","text":"PERENNIAL INVESTORS LLC"},{"value":"152313","text":"ARCHVIEW"},{"value":"194392","text":"BOLTON"},{"value":"173010","text":"NATIONAL BANK OF CANADA"},{"value":"116030","text":"PEDDER STREET"},{"value":"183035","text":"TENG YUE"},{"value":"221379","text":"DEIMOS"},{"value":"116020","text":"PARADISE CAPITAL MANAGEMNT LTD"},{"value":"116262","text":"STATE STREET GLOBAL ADVISORS"},{"value":"116265","text":"STG"},{"value":"116264","text":"GRACE INVESTMENTS -"},{"value":"116022","text":"PARKCENTRAL CAPITAL"},{"value":"116025","text":"PAULSON & CO"},{"value":"201790","text":"CDP GLOBAL"},{"value":"175669","text":"SILVERBACK"},{"value":"173484","text":"KBC ALTERNATIVE INVESTMENTS"},{"value":"116260","text":"STARK INVESTMENTS"},{"value":"166348","text":"CAMBRIDGE STRATEGY"},{"value":"167683","text":"RIGHT INVESTMENT"},{"value":"116098","text":"PRE PRODUCTION TEST CLIENT"},{"value":"390912","text":"OPTIMAS CAPITAL"},{"value":"116097","text":"RENAISSANCE/MEDALLION CAP"},{"value":"116099","text":"RESTORATION "},{"value":"240928","text":"ALDER"},{"value":"116090","text":"RAMIUS CAP"},{"value":"210029","text":"STONE TORO"},{"value":"116096","text":"RENAISSANCE"},{"value":"176387","text":"CELLO"},{"value":"154359","text":"APUS INVESTMENTS"},{"value":"203989","text":"ARMOUR"},{"value":"261859","text":"AZ FUND MANAGEMENT SA"},{"value":"116087","text":"RAB CAPITAL"},{"value":"203752","text":"INDABA"},{"value":"167663","text":"NORTHWEST"},{"value":"116089","text":"RAM CAPITAL SA"},{"value":"201331","text":"ORCHID CHINA"},{"value":"116088","text":"RAINBOW ADVISORY"},{"value":"178558","text":"NDC INV PTE"},{"value":"212219","text":"DARHOLD"},{"value":"116082","text":"SINGAPORE QINHAN ADVISORS"},{"value":"179883","text":"E FUND MANAGEMENT"},{"value":"116084","text":"QUANTATIVE EQUITY STRATEGIES"},{"value":"214651","text":"COBALT"},{"value":"214653","text":"HARVEY"},{"value":"180876","text":"S GOLDMAN"},{"value":"167462","text":"MATCHPOINT INV MGMT ASIA LTD"},{"value":"116076","text":"P&S CAPITAL MGMT"},{"value":"168543","text":"CMS ASSET MANAGEMENT (HK) CO., LTD"},{"value":"116078","text":"Q INVESTMENTS"},{"value":"167456","text":"GINGER INVESTMENT MGMT LTD"},{"value":"116077","text":"P&S CREDIT MANAGEMENT"},{"value":"167458","text":"GINSENG CAPITAL ADVISORS "},{"value":"240905","text":"HITE"},{"value":"116079","text":"QATAR INVESTMENT AUTHORITY (QIA)"},{"value":"323966","text":"GOLDENTREE"},{"value":"116072","text":"PROSPECT ASSET MGMT"},{"value":"179676","text":"ICGMI STOCK BORROW LOAN"},{"value":"116071","text":"PROPHET CAP MGMT"},{"value":"217913","text":"SPROTT"},{"value":"179434","text":"SSARIS"},{"value":"210049","text":"PSAGOT"},{"value":"215752","text":"NWI"},{"value":"175071","text":"SILVERCREEK"},{"value":"167450","text":"ASIA DEBT MANAGEMENT HK LTD"},{"value":"180880","text":"MARCATO CAPITAL MGMT"},{"value":"202440","text":"TURIYA ADVISORS"},{"value":"167445","text":"KIMCO INTERNATIONAL"},{"value":"189220","text":"POINTSTATE"},{"value":"116068","text":"PRINCIPAL GLOBAL INVESTORS"},{"value":"199497","text":"BRYAN GARNIER"},{"value":"190443","text":"OP INVESTMENT MGMT LTD"},{"value":"116060","text":"PORTLAND HOUSE"},{"value":"237516","text":"DE SHAW FOR PRIME LOCATE ONLY"},{"value":"116062","text":"PRAMERICA"},{"value":"258491","text":"MACQUARIE ASSET MGMT"},{"value":"212497","text":"CHERRY HILL"},{"value":"177438","text":"BARCLAYS CAPITAL LUXEMBOURG SA"},{"value":"180857","text":"EMS CAP LP"},{"value":"178768","text":"BARKER INV MGMT PTE LTD"},{"value":"237788","text":"KSM SAL"},{"value":"179610","text":"BOSTON & ALEXANDER"},{"value":"199469","text":"CS MGMT"},{"value":"212488","text":"NINEMASTS"},{"value":"212247","text":"GAZPROMBANK"},{"value":"180621","text":"TRIVEST ADV"},{"value":"237542","text":"SCGE"},{"value":"262987","text":"HUNTER PEAK INVESTMENTS LP"},{"value":"262505","text":"ASIA RESEARCH AND CAPITAL"},{"value":"263837","text":"BRASLYN LTD"},{"value":"190424","text":"PASSPORT"},{"value":"168719","text":"CASTLE CREEK"},{"value":"179600","text":"JANA PARTNERS"},{"value":"178753","text":"ZENIT"},{"value":"174397","text":"ALCHEMY INVESTMENT"},{"value":"178551","text":"ALPINE FOR PRIME LOCATE"},{"value":"269369","text":"OMEGA ADVISORS INC"},{"value":"167410","text":"ARROWHAWK"},{"value":"321987","text":"VERNO CAPITAL UK LLP"},{"value":"238897","text":"PINYON"},{"value":"301911","text":"LIGHT STREET"},{"value":"237564","text":"SEGANTII"},{"value":"186386","text":"SPECTRUM PARTNERS"},{"value":"204662","text":"PARTNERS"},{"value":"168975","text":"CERBERUS"},{"value":"115959","text":"MSD CAPITAL"},{"value":"183406","text":"DISCERENE"},{"value":"115951","text":"MONSOON CAPITAL"},{"value":"115953","text":"MONTANI "},{"value":"115954","text":"MONTPELIER"},{"value":"115955","text":"MOON CAPITAL"},{"value":"115956","text":"MOORE"},{"value":"115715","text":"FURSA ALTERNATIVE STRATEGIES L"},{"value":"115957","text":"MORGAN STANLEY INV MGMT"},{"value":"170324","text":"VALUE PARTNERS"},{"value":"173836","text":"CHINA UNIVERSAL ASSET MANAGEMENT"},{"value":"242709","text":"KAYNE"},{"value":"115961","text":"MSR"},{"value":"190179","text":"OASIS MANAGEMENT CO LIMITED"},{"value":"115949","text":"MOHICAN"},{"value":"213156","text":"BANES CAPITAL"},{"value":"217750","text":"THIEL"},{"value":"115941","text":"MILLENNIUM CAPITAL MANAGEMENT (SINGAPORE) PTE LTD"},{"value":"242716","text":"JANCHOR"},{"value":"115943","text":"MILLENNIUM"},{"value":"115944","text":"MILLER ANDERSON/M S HEDGE"},{"value":"115945","text":"MILLESIME CAMPAGNIE FINANCIERE"},{"value":"353456","text":"TIDE POINT"},{"value":"115704","text":"FRONTPOINT PARTNERS"},{"value":"180142","text":"VULPES INVESTMENT MANAGEMENT"},{"value":"388773","text":"ANTIPODES PARTNERS LTD"},{"value":"115950","text":"MOLAVE CAPITAL PTE LIMITED"},{"value":"218837","text":"HIGH VISTA"},{"value":"115939","text":"MIDSUMMER"},{"value":"168270","text":"CADENCE"},{"value":"115930","text":"MELLON CAPITAL MGMT"},{"value":"229508","text":"OLD MUTUAL"},{"value":"115931","text":"MENA CAPITAL LLP"},{"value":"225149","text":"WATERSTONE CAP"},{"value":"115933","text":"MERCURIUS CAPITAL MANAGEMENT"},{"value":"115935","text":"MERRILL"},{"value":"307535","text":"NEDBANK LIMITED"},{"value":"170100","text":"FIRST STATE"},{"value":"157126","text":"BELLMAN WALTER CAPITAL"},{"value":"115927","text":"MDT "},{"value":"115929","text":"MELDRUM"},{"value":"220923","text":"ROBUR"},{"value":"235188","text":"BLACKGOLD"},{"value":"178061","text":"PARVUS"},{"value":"263614","text":"CAXTON ASSOCIATES LP"},{"value":"362195","text":"SCOPIA"},{"value":"115922","text":"MASON CAPITAL"},{"value":"184960","text":"KARYA"},{"value":"115924","text":"MAVERICK"},{"value":"174935","text":"SOLARIS ASSET MANAGEMENT"},{"value":"191252","text":"GROW PARTNERS"},{"value":"191491","text":"ALPHA BETA CAP"},{"value":"250316","text":"SEIX"},{"value":"248481","text":"HARVEST"},{"value":"115519","text":"CITATION"},{"value":"115511","text":"CEPHEI CAP MGMT"},{"value":"115995","text":"ONE EAST PARTNERS CAPITAL ADVISORS"},{"value":"115512","text":"COLONIAL FIRST STATE AUSTRALIA"},{"value":"115996","text":"ONTARIO TEACHERS PENSION PLAN"},{"value":"115755","text":"GEORGE WEISS ASSOCIATES"},{"value":"115514","text":"CHEYNE CAPITAL MGMT"},{"value":"115756","text":"H/2 CAPITAL PARTNERS"},{"value":"115515","text":"CHINA VALUE INVESTMENT LTD"},{"value":"115999","text":"OPPENHEIMER "},{"value":"115758","text":"HALCYON INVESTORS"},{"value":"115517","text":"CIM INVESTMENT MANAGEMENT LTD"},{"value":"172707","text":"EJF"},{"value":"115759","text":"HALCYON ADVISORS INC"},{"value":"115518","text":"CITADEL"},{"value":"115760","text":"HALL FINANCIAL "},{"value":"168448","text":"FALCON"},{"value":"115761","text":"HARBERT"},{"value":"115521","text":"CITIGROUP"},{"value":"178489","text":"SPREADEX"},{"value":"190374","text":"TURICUM ASSET"},{"value":"115742","text":"EAGLE"},{"value":"115501","text":"CARROUSEL CAPITAL LTD"},{"value":"115502","text":"CREDIT AGRICOLE STRUCTURED AM"},{"value":"115744","text":"GREENOCK CAPITAL"},{"value":"115986","text":"OAKTREE CAPITAL"},{"value":"115745","text":"GLOBAL SECURITES ADVISORS LLC"},{"value":"115505","text":"CASTLERI INVESTMENTS"},{"value":"265615","text":"KEY SQUARE"},{"value":"115506","text":"CAVALRY"},{"value":"167585","text":"KYLIN "},{"value":"205333","text":"ARDSLEY PARTNERS"},{"value":"115990","text":"OCEANWOOD CAPITAL MGT LLP"},{"value":"115991","text":"OLDLANE"},{"value":"115994","text":"OMNIA ASSET MANAGEMENT"},{"value":"180108","text":"JUGGERNAUT CAPITAL"},{"value":"191477","text":"NAN FUNG INV"},{"value":"115739","text":"GRAMERCY"},{"value":"182971","text":"RAM ACTIVE"},{"value":"180556","text":"MIURA"},{"value":"115973","text":"NEXSTAR"},{"value":"115974","text":"NEXUM"},{"value":"115975","text":"NOMURA"},{"value":"262579","text":"COPPER STREET CAPITAL LLP"},{"value":"115735","text":"GOLDMAN SACHS ASSET MGMT"},{"value":"115977","text":"NORDEA"},{"value":"115736","text":"GOV INV CORP OF SINGAPORE"},{"value":"115978","text":"NORDIC"},{"value":"229309","text":"HAREL"},{"value":"249364","text":"ADAGE"},{"value":"169314","text":"HILLHOUSE CAPITAL MANAGEMENT"},{"value":"250587","text":"SOROBAN"},{"value":"172963","text":"SAMENA CAP MGMT"},{"value":"115983","text":"NOVATOR"},{"value":"277825","text":"GLENVIEW"},{"value":"190356","text":"NORBEST"},{"value":"115729","text":"GLG PARTNERS"},{"value":"219756","text":"JUPITER"},{"value":"176081","text":"WARWICK CAPITAL"},{"value":"191219","text":"SPARTUS"},{"value":"115721","text":"GALLEON PARTNERS"},{"value":"115722","text":"GALTERE INTERNATIONAL LTD"},{"value":"115724","text":"GEOSPHERE"},{"value":"115966","text":"MARSHALL WACE"},{"value":"167365","text":"PHIBRO ENERGY"},{"value":"209704","text":"ADAMAS"},{"value":"167367","text":"SPM PRODUCTS"},{"value":"115970","text":"NIS - NEW INVESTMENT SOLUTIONS"},{"value":"115971","text":"NEWSMITH CAPITAL PARTNERS"},{"value":"115972","text":"NEW STAR INSTITUTIONAL MANAGER"},{"value":"229780","text":"MELCO CAP"},{"value":"185427","text":"LIBRA"},{"value":"184578","text":"DOUBLE HAVEN CAPITAL"},{"value":"265662","text":"SILVER RIDGE"},{"value":"168094","text":"ARC ASSET MANAGEMENT"},{"value":"115555","text":"DAVIDSON KEMPNER"},{"value":"115797","text":"INVESTMENT CORP OF DUBAI"},{"value":"115799","text":"INTL FINANCIAL ADVISORS KSCC"},{"value":"183481","text":"ALTERA"},{"value":"115558","text":"DBTRUST"},{"value":"252350","text":"THE STANDARD BANK OF SOUTH AFRICA LIMITED"},{"value":"115560","text":"DB ZWIRN & CO LP"},{"value":"171498","text":"GEN2 KS"},{"value":"115544","text":"DOWNSVIEW"},{"value":"379666","text":"AROSA"},{"value":"115545","text":"CRESTLINE PARTNERS LP"},{"value":"115547","text":"CRAMER ROSENTHAL MCGLYNN"},{"value":"115789","text":"HORIZON ASSET MANAGEMENT INC"},{"value":"220984","text":"SIR"},{"value":"115549","text":"CSO"},{"value":"115790","text":"HSBC"},{"value":"115550","text":"CTI CAPITAL SECURITIES INC"},{"value":"115792","text":"HERMITAGE ASSETS LTD"},{"value":"115552","text":"CYNTHION "},{"value":"115794","text":"HYDRA CAPITAL MGMT"},{"value":"115554","text":"DALTON"},{"value":"173661","text":"IVALDI"},{"value":"115533","text":"CONSTELLATION "},{"value":"115775","text":"HELIOS CAPITAL MANAGEMENT PTE LIMITED"},{"value":"115534","text":"CONTRAVISORY RESEARCH & MGMT"},{"value":"115776","text":"HENDERSON GLOBAL INVESTORS"},{"value":"115537","text":"PACIFICOR"},{"value":"183222","text":"SUB-SAHARA"},{"value":"115539","text":"COUDREE CAPITAL MANAGEMENT"},{"value":"181044","text":"SPHEREINVEST"},{"value":"230334","text":"JAT CAPITAL MANAGEMENT"},{"value":"196535","text":"NUVEST CAP"},{"value":"115540","text":"COUGAR CAPITAL"},{"value":"115782","text":"HIGHBRIDGE CAP MGT"},{"value":"115541","text":"COUGAR ASSET MGMT"},{"value":"115542","text":"CPMG"},{"value":"115784","text":"HIGHSIDE CAPITAL"},{"value":"173458","text":"JACOBS"},{"value":"115543","text":"CQS"},{"value":"176720","text":"EAST PARK INV MGMT"},{"value":"234930","text":"ARES"},{"value":"115522","text":"CLAREVILLE CAPITAL"},{"value":"115523","text":"CLARIUM CAPITAL MGT"},{"value":"115765","text":"HARVARD MANAGEMENT"},{"value":"115524","text":"CLIFTON GROUP"},{"value":"115525","text":"CLINTON GROUP"},{"value":"115767","text":"HAWKEYE"},{"value":"115768","text":"HUDSON BAY"},{"value":"115769","text":"HBK CAPITAL MANAGEMENT"},{"value":"115528","text":"COMPANIA FINANCIARIA"},{"value":"170179","text":"GS INVESTMENT STRATEGIES"},{"value":"172115","text":"ROCKVIEW"},{"value":"231659","text":"TILDEN"},{"value":"172114","text":"CROWN "},{"value":"115530","text":"CONCORDIA ADVISORS"},{"value":"115772","text":"HEADSTART ADVISERS LIMITED"},{"value":"115532","text":"CONNECTIVE CAPITAL"},{"value":"174771","text":"NORTHWESTERN"},{"value":"186712","text":"ADELANTE"},{"value":"179187","text":"TDAM"},{"value":"241254","text":"POST STREET"},{"value":"216296","text":"DLD"},{"value":"310080","text":"THINK INV LP"},{"value":"230361","text":"WHITEBOX"},{"value":"115358","text":"ACADIAN ASSET MANAGEMENT AUST"},{"value":"115361","text":"ACROPOLE"},{"value":"115363","text":"ACUITY CAPITAL MANAGEMENT"},{"value":"115364","text":"ADAR"},{"value":"253473","text":"SYMMETRY"},{"value":"115366","text":"ADMIRAL CAPITAL MANAGEMENT LLC"},{"value":"171459","text":"DUET ASSET MANAGEMENT LTD"},{"value":"115367","text":"ADVENT"},{"value":"305737","text":"NPJ ASSET MANAGEMENT LLP"},{"value":"115347","text":"398"},{"value":"115589","text":"STATS INVESTMENT MANAGEMENT COMPANY LTD"},{"value":"115348","text":"LOMBARD ODIER"},{"value":"115591","text":"EBF"},{"value":"115350","text":"3L INVESTMENTS LLP"},{"value":"115592","text":"ECOFIN LIMITED"},{"value":"115351","text":"SEARS"},{"value":"115594","text":"ELGIN CAPITAL [SCS]"},{"value":"115353","text":"ABC SQUARE ASSET MGMT LLP"},{"value":"115354","text":"ABNAMRO"},{"value":"115596","text":"ELLIOTT"},{"value":"115597","text":"ELM RIDGE"},{"value":"115598","text":"EMERGENT ASSET MANAGEMENT"},{"value":"181004","text":"1741"},{"value":"115577","text":"DISCOVERY"},{"value":"115578","text":"DKR CAPITAL INC"},{"value":"115579","text":"D L BABSON"},{"value":"379262","text":"ASSENAGON"},{"value":"258902","text":"BOCAGE CAPITAL LLC"},{"value":"115582","text":"DORSET"},{"value":"173418","text":"LQ ASSET MANAGEMENT"},{"value":"198916","text":"CHINAROCK"},{"value":"379024","text":"ICHIGO AM INTL"},{"value":"115587","text":"DRAKE"},{"value":"170144","text":"NAOS ASSET MGMT"},{"value":"158036","text":"SANCUS "},{"value":"181016","text":"MARKETFIELD"},{"value":"217177","text":"CANOSA"},{"value":"180162","text":"GRAND CATHAY CAPITAL"},{"value":"173889","text":"BASIC ASSET MANAGEMENT"},{"value":"115574","text":"DE SHAW"},{"value":"230363","text":"CUSHING"},{"value":"115575","text":"DIAMONDBACK CAPITAL"},{"value":"252376","text":"CYRUS"},{"value":"115576","text":"DILLON READ CAPITAL MGMT LLC"},{"value":"253222","text":"NEW YORK LIFE INVESTMENT MANAGEMENT"},{"value":"172550","text":"ALGEBRIS INVESTMENTS"},{"value":"174730","text":"ALPSTAR"},{"value":"194320","text":"QUOTIDIAN"},{"value":"157175","text":"RIVERWEST ADVISORS LIMITED"},{"value":"190739","text":"BAUPOST"},{"value":"165537","text":"BTG"},{"value":"116127","text":"SANTANDER ASSET MANAGEMENT"},{"value":"154409","text":"PUREHEART CAPITAL ASIA LTD"},{"value":"116133","text":"SAWTOOTH CAP MGMT (SCS)"},{"value":"175333","text":"SLOANE ROBINSON"},{"value":"180935","text":"CGML STOCK BORROW LOAN"},{"value":"174240","text":"AAM"},{"value":"346585","text":"CASTLETON"},{"value":"190747","text":"BURREN CAPITAL ADVISORS LIMITED"},{"value":"209331","text":"SABA"},{"value":"224700","text":"TOSCA"},{"value":"116359","text":"WINNINGTON CAPITAL LTD"},{"value":"116116","text":"POINT72 ASSET MANAGEMENT LP"},{"value":"116118","text":"MKM LONGBOAT CAPITAL ADVISORS"},{"value":"116363","text":"WR HUFF"},{"value":"116124","text":"SANDELMAN PARTNERS"},{"value":"116366","text":"ZIMMER LUCAS"},{"value":"116123","text":"SANDELL ASSET MGMT"},{"value":"116365","text":"ZIFF BROTHERS"},{"value":"379399","text":"TWIN TREE MANAGEMENT LP"},{"value":"116367","text":"ZWEIG-DIMENNA"},{"value":"180706","text":"QUAD CAPITAL"},{"value":"116360","text":"WINTERGREEN ADVISERS"},{"value":"241277","text":"SWISS ASIA"},{"value":"189728","text":"FORT SHERIDAN"},{"value":"116348","text":"IROQUOIS"},{"value":"116106","text":"ROHATYN"},{"value":"116105","text":"ROCKMORE "},{"value":"154428","text":"HAMON ASSET MGMT. LTD"},{"value":"220135","text":"LAKEWOOD CAPITAL MGMT LP"},{"value":"116351","text":"WATERSHED ASSET MANAGEMENT"},{"value":"116350","text":"WATER STREET CAPITAL"},{"value":"383433","text":"ONE TUSK"},{"value":"116110","text":"ROVIDA"},{"value":"116355","text":"WEISS ASSET MANAGEMENT"},{"value":"116354","text":"WEINTRAUB CAPITAL"},{"value":"257852","text":"HIGHFIELDS"},{"value":"178868","text":"OPPY FOR PRIME LOCATE"},{"value":"116357","text":"WESTERN INVESTMENT LLC"},{"value":"116114","text":"SAAD INVESTMENT CO."},{"value":"116356","text":"WELLINGTON"},{"value":"155503","text":"WELLCHAMP"},{"value":"116337","text":"UBS"},{"value":"154418","text":"SERICA PARTNERS"},{"value":"223634","text":"TACHLIT"},{"value":"115493","text":"CAPITAL GROWTH MANAGEMENT LP"},{"value":"115494","text":"CAPITAL SOURCE"},{"value":"116100","text":"MARCUS SCHLOSS "},{"value":"116341","text":"UNICOM CAPITAL"},{"value":"115496","text":"CARLSON CAPITAL"},{"value":"186470","text":"HYPOSWISS"},{"value":"176437","text":"INCOME PARTNERS AM"},{"value":"116101","text":"RADCLIFFE"},{"value":"116104","text":"ROCKHAMPTON MANAGEMENT"},{"value":"220131","text":"TREE CAPITAL"},{"value":"116345","text":"10V"},{"value":"115499","text":"CARNEGIE INVESTMENT BANK"},{"value":"177769","text":"PERCEPTUM"},{"value":"198684","text":"CTC"},{"value":"115490","text":"CANYON PARTNERS"},{"value":"186438","text":"MYRIAD ASSET MGMT LTD"},{"value":"406669","text":"SYLEBRA HK"},{"value":"116175","text":"SIGNET CAPITAL MGMT"},{"value":"116174","text":"SIEGLER, COLLERY & CO"},{"value":"116179","text":"SIMARGL"},{"value":"116178","text":"SIMON MURRAY & CO"},{"value":"243042","text":"NEXUS"},{"value":"198412","text":"QVT"},{"value":"209371","text":"KGI INTERNATIONAL"},{"value":"209373","text":"GORDIAN"},{"value":"209375","text":"AVIVA"},{"value":"189716","text":"SIBILLA"},{"value":"169095","text":"CITIBANK NA"},{"value":"220147","text":"GMT CAPITAL"},{"value":"190709","text":"CORNELLVEST"},{"value":"116168","text":"SHELL NETHERLANDS PENSION FUND"},{"value":"173348","text":"RAFFERTY"},{"value":"116169","text":"SHELL COVE CAPITAL MANAGEMENT"},{"value":"174433","text":"CASEY"},{"value":"180902","text":"AMUNDI AM"},{"value":"116160","text":"SG HISCOCK & CO"},{"value":"186657","text":"CAPEVIEW"},{"value":"116152","text":"SDS CAPITAL PARTNERS"},{"value":"174466","text":"VR ADVISORS"},{"value":"216903","text":"SPX"},{"value":"172044","text":"EVERGREEN"},{"value":"221256","text":"MOUNT CAPITAL LIMITED"},{"value":"369184","text":"ADDITIVE ADVISORY"},{"value":"116146","text":"SCHRODER INVEST MGMT [SCS]"},{"value":"174695","text":"MILLENNIUM INTERNATIONAL MANAGEMENT LP"},{"value":"175787","text":"LCH CLEARNET"},{"value":"196225","text":"APERIMUS"},{"value":"195133","text":"WOLVERINE"},{"value":"195378","text":"SNOW LAKE CAPITAL"},{"value":"156666","text":"MUZINICH EXTRA YIELD EUR LOAN FUND"},{"value":"180536","text":"NEZU ASIA CAP"},{"value":"204947","text":"CAVALIER CAPITAL"},{"value":"167795","text":"T ROWE PRICE"},{"value":"213419","text":"ALPHALEO"},{"value":"387850","text":"GSA CAPITAL PARTNERS LLP"},{"value":"223473","text":"PRIME CAP"},{"value":"156670","text":"ONE WILLIAM STREET CAPITAL"},{"value":"178680","text":"CHILLEE"},{"value":"156656","text":"HAIDAR CAPITAL"},{"value":"156658","text":"HARDING ADVISORY"},{"value":"383490","text":"CASTLE HOOK"},{"value":"166211","text":"SOTHIC CAPITAL MANAGEMENT"},{"value":"204962","text":"MS INVESTMENTS"},{"value":"251945","text":"JHL"},{"value":"210157","text":"BIMINI"},{"value":"346732","text":"AUSPICIOUS CAPITAL"},{"value":"179762","text":"CLOVERIE"},{"value":"178473","text":"LEUTHOLD"},{"value":"176054","text":"JL CAPITAL"},{"value":"202308","text":"PORTMAN"},{"value":"166247","text":"UBS PACTUAL BANKING LIMITED"},{"value":"167581","text":"KOOR INDUSTRIES"},{"value":"221075","text":"SENATOR"},{"value":"116193","text":"STOCK LOAN DESK"},{"value":"179797","text":"AAA CAPITAL"},{"value":"190310","text":"MILLENNIUM GLOBAL"},{"value":"179555","text":"PIMCO"},{"value":"179553","text":"KINGSTREET"},{"value":"156676","text":"PICTET AND CIE"},{"value":"175195","text":"MOUNT KELLETT"},{"value":"156678","text":"PRINCETON"},{"value":"201473","text":"TOLIS"},{"value":"170972","text":"KELUSA CAPITAL"},{"value":"170970","text":"DABROES MANAGEMENT"},{"value":"116180","text":"SIMPLEX ASSET MANAGEMENT"},{"value":"180528","text":"TAHAN CAPITAL"},{"value":"191412","text":"WILKS"},{"value":"115916","text":"M&B CAPITAL ADVISORS"},{"value":"115917","text":"MANDRAKE"},{"value":"196081","text":"MANGROVE"},{"value":"115918","text":"MARATHON ASSET MANAGEMENT"},{"value":"115910","text":"FORUM ASSET "},{"value":"115914","text":"MAGNETAR "},{"value":"221095","text":"AAG AVIATION"},{"value":"189550","text":"VULCAN"},{"value":"240609","text":"ALTIMEO"},{"value":"253914","text":"TFS"},{"value":"115904","text":"LSV "},{"value":"115905","text":"LU"},{"value":"115907","text":"LUMEN ADVISORS LLC"},{"value":"176460","text":"NEVSKY"},{"value":"115908","text":"LUMINUS MGT"},{"value":"215891","text":"INFINEON"},{"value":"115900","text":"LOCDRMS"},{"value":"115901","text":"LOCEQMO"},{"value":"115902","text":"LOCEQPR"},{"value":"115903","text":"LOCPORT"},{"value":"167500","text":"SGC CAPITAL MANAGEMENT"},{"value":"309307","text":"SAND GROVE CAPITAL MANAGEMENT LLP"},{"value":"199355","text":"DCTDEXIA CITI LCH TEST ACCOUNT"},{"value":"215887","text":"DELIVERY"},{"value":"191871","text":"FOUNDATION"},{"value":"235272","text":"COASTLAND"},{"value":"176250","text":"EATON VANCE"},{"value":"178430","text":"AZENTUS CAPITAL MGMT"},{"value":"156640","text":"EXCEL WEALTH MGMT"},{"value":"156643","text":"FIBONACCI CAPITAL"},{"value":"235273","text":"POLO ADVISORY"},{"value":"204529","text":"WAYPOINT"},{"value":"191601","text":"BALESTRA"},{"value":"174069","text":"EME PARTNERS"},{"value":"190753","text":"TRADELINK"},{"value":"156630","text":"AXA INVESTMENT MANAGERS"},{"value":"156632","text":"BELVEDERE TRUST"},{"value":"156634","text":"CEDRUS CAPITAL"},{"value":"156638","text":"ENDEAVOUR CAPITAL"},{"value":"155548","text":"WEXFORD"},{"value":"317386","text":"PUBLIC EQUITY"},{"value":"189540","text":"SIP CAPITAL"},{"value":"170932","text":"CABEZON"},{"value":"202360","text":"CARVE"},{"value":"329593","text":"UHI PTE"},{"value":"180969","text":"ENIGMA"},{"value":"155550","text":"F AND C"}];
	let funds 	: any = [{"value":"9999999999","text":"ALL"}];
	let regions : any = [{"value":"1","text":"GLOBAL"},{"value":"2","text":"NAM"},{"value":"3","text":"APAC"},{"value":"4","text":"EMEA"}];
	
	let COBDates 		: any = [20170206,20170203,20170202,20170201,20170131,20170130,20170127,20170126,20170125,20170124,20170123,20170120,20170119,20170118,20170117,20170116,20170113,20170112,20170111,20170110,20170109,20170106,20170105,20170104,20170103,20170102,20161230,20161229,20161228,20161227];
	let COBDatesMonthly : any = [20170206,20170131,20161230,20161130,20161031,20160930,20160831,20160729,20160630,20160531,20160429,20160331,20160229];

	let financingBalance	: any = [{"cob_date":"20170206","client":null,"fund":null,"region":null,"credit":9418641885,"debit":50378528632,"shorts":66117819507,"others":1478820556,"index_level":1798,"gfcid_fund":null},{"cob_date":"20170203","client":null,"fund":null,"region":null,"credit":9921043493,"debit":49607463936,"shorts":65750617843,"others":1484665481,"index_level":1805,"gfcid_fund":null},{"cob_date":"20170202","client":null,"fund":null,"region":null,"credit":9545885049,"debit":49306024185,"shorts":65217424535,"others":1484224805,"index_level":1795,"gfcid_fund":null},{"cob_date":"20170201","client":null,"fund":null,"region":null,"credit":9292045377,"debit":49288416927,"shorts":65233849428,"others":1482864463,"index_level":1793,"gfcid_fund":null},{"cob_date":"20170131","client":null,"fund":null,"region":null,"credit":9267574324,"debit":49682017456,"shorts":65185112053,"others":1483640332,"index_level":1792,"gfcid_fund":null}];
	let equityBalance   	: any = [{"cob_date":"20170206","client":null,"fund":null,"region":null,"cash":22439049590,"lmv":109308481831,"smv":68103128532,"netequity":63644402889,"totalequity":199850659953,"index_level":1798,"gfcid_fund":null},{"cob_date":"20170203","client":null,"fund":null,"region":null,"cash":23425768325,"lmv":109273816505,"smv":68815458208,"netequity":63884126622,"totalequity":201515043038,"index_level":1805,"gfcid_fund":null},{"cob_date":"20170202","client":null,"fund":null,"region":null,"cash":22861968568,"lmv":108228621593,"smv":68195078815,"netequity":62895511346,"totalequity":199285668977,"index_level":1795,"gfcid_fund":null},{"cob_date":"20170201","client":null,"fund":null,"region":null,"cash":22454167723,"lmv":108512374936,"smv":67661388923,"netequity":63305153737,"totalequity":198627931584,"index_level":1793,"gfcid_fund":null},{"cob_date":"20170131","client":null,"fund":null,"region":null,"cash":22489316788,"lmv":107608706111,"smv":67133943022,"netequity":62964079876,"totalequity":197231965922,"index_level":1792,"gfcid_fund":null}]; 
	let balanceSheetROA 	: any = [{"cob_date":"20170206","balance_sheet":50852910710,"without_seclending_balsheet":50124522132,"pnl":983274,"roa":71.6},{"cob_date":"20170203","balance_sheet":50227172682,"without_seclending_balsheet":49518581532,"pnl":485406,"roa":35.77},{"cob_date":"20170202","balance_sheet":49177659846,"without_seclending_balsheet":48491705606,"pnl":962007,"roa":72.41},{"cob_date":"20170201","balance_sheet":49059646356,"without_seclending_balsheet":48317798456,"pnl":1087253,"roa":82.13},{"cob_date":"20170131","balance_sheet":48935807807,"without_seclending_balsheet":48226579355,"pnl":652482,"roa":49.38}]; 
	let revenue  			: any = [{"cob_date":"20170206","pnl":983274,"cash":285467,"shorts":533310,"fee":164496},{"cob_date":"20170203","pnl":485406,"cash":284949,"shorts":48350,"fee":152106},{"cob_date":"20170202","pnl":962007,"cash":259455,"shorts":577035,"fee":125515},{"cob_date":"20170201","pnl":1087253,"cash":189035,"shorts":611428,"fee":286789},{"cob_date":"20170131","pnl":652482,"cash":250221,"shorts":134495,"fee":267765}]; 
	let securityCountryRisk : any = [{"cob_date":"20170206","other":3832338332,"apac_Emerging_Markets_Lev1":121902713,"apac_Emerging_Markets_Lev2":2706481718,"apac_Emerging_Markets_Lev3":432227726,"developed_Markets":168615238129,"emea_Emerging_Markets_Lev1B":416189074,"emea_Emerging_Markets_Lev2":719796761,"latam_Emerging_Markets_Lev2":567435906},{"cob_date":"20170203","other":3661152567,"apac_Emerging_Markets_Lev1":120534726,"apac_Emerging_Markets_Lev2":2683730968,"apac_Emerging_Markets_Lev3":432487323,"developed_Markets":169527920346,"emea_Emerging_Markets_Lev1B":411102050,"emea_Emerging_Markets_Lev2":681323448,"latam_Emerging_Markets_Lev2":571023281},{"cob_date":"20170202","other":176423700409,"apac_Emerging_Markets_Lev1":0,"apac_Emerging_Markets_Lev2":0,"apac_Emerging_Markets_Lev3":0,"developed_Markets":0,"emea_Emerging_Markets_Lev1B":0,"emea_Emerging_Markets_Lev2":0,"latam_Emerging_Markets_Lev2":0},{"cob_date":"20170201","other":176173763860,"apac_Emerging_Markets_Lev1":0,"apac_Emerging_Markets_Lev2":0,"apac_Emerging_Markets_Lev3":0,"developed_Markets":0,"emea_Emerging_Markets_Lev1B":0,"emea_Emerging_Markets_Lev2":0,"latam_Emerging_Markets_Lev2":0},{"cob_date":"20170131","other":174742649133,"apac_Emerging_Markets_Lev1":0,"apac_Emerging_Markets_Lev2":0,"apac_Emerging_Markets_Lev3":0,"developed_Markets":0,"emea_Emerging_Markets_Lev1B":0,"emea_Emerging_Markets_Lev2":0,"latam_Emerging_Markets_Lev2":0}]; 
	let securityProduct  	: any = [{"cob_date":"20170206","other":2237716469,"convertibles":8942501178,"corporates":10902509064,"equities":152086921658,"preferreds":138273520,"sovereigns":2796724879,"warrants":306963592},{"cob_date":"20170203","other":2287170110,"convertibles":53452038,"corporates":18284915032,"equities":152613819486,"preferreds":1491347636,"sovereigns":3054508504,"warrants":304061904},{"cob_date":"20170202","other":176423700409,"convertibles":0,"corporates":0,"equities":0,"preferreds":0,"sovereigns":0,"warrants":0},{"cob_date":"20170201","other":176173763860,"convertibles":0,"corporates":0,"equities":0,"preferreds":0,"sovereigns":0,"warrants":0},{"cob_date":"20170131","other":174742649133,"convertibles":0,"corporates":0,"equities":0,"preferreds":0,"sovereigns":0,"warrants":0}]; 
	let securitySector  	: any = [{"cob_date":"20170206","consumer_discretionary":24944390336,"consumer_staples":8418671874,"energy":14361509530,"financials":18499503778,"health_care":18791187544,"industrials":16160875379,"information_technology":26646483391,"materials":9332131759,"telecommunications":3401060986,"utilities":4871153115,"other":31984642666},{"cob_date":"20170203","consumer_discretionary":0,"consumer_staples":0,"energy":0,"financials":0,"health_care":0,"industrials":0,"information_technology":0,"materials":0,"telecommunications":0,"utilities":0,"other":178089274713},{"cob_date":"20170202","consumer_discretionary":0,"consumer_staples":0,"energy":0,"financials":0,"health_care":0,"industrials":0,"information_technology":0,"materials":0,"telecommunications":0,"utilities":0,"other":176423700409},{"cob_date":"20170201","consumer_discretionary":0,"consumer_staples":0,"energy":0,"financials":0,"health_care":0,"industrials":0,"information_technology":0,"materials":0,"telecommunications":0,"utilities":0,"other":176173763860},{"cob_date":"20170131","consumer_discretionary":0,"consumer_staples":0,"energy":0,"financials":0,"health_care":0,"industrials":0,"information_technology":0,"materials":0,"telecommunications":0,"utilities":0,"other":174742649133}]; 
	let securityMarketCap  	: any = [{"cob_date":"20170206","other":27299055725,"nano":978766733,"mega":59938398665,"bigLarge":23407720602,"mid":47037115734,"small":16540833001,"micro":2209719899},{"cob_date":"20170203","other":27551116188,"nano":992023148,"mega":60198863018,"bigLarge":23040184649,"mid":47409773860,"small":16674650620,"micro":2222663227},{"cob_date":"20170202","other":176423700409,"nano":0,"mega":0,"bigLarge":0,"mid":0,"small":0,"micro":0},{"cob_date":"20170201","other":176173763860,"nano":0,"mega":0,"bigLarge":0,"mid":0,"small":0,"micro":0},{"cob_date":"20170131","other":174742649133,"nano":0,"mega":0,"bigLarge":0,"mid":0,"small":0,"micro":0}]; 
	
	class MockHttpErrorHandler {
		handle(err){
			console.log("ClientOverviewService:: MockHttpErrorHandler", err);
		}
	}

	class MockAppStateService {
        clearAppState() {};
        getModuleGlobalState(module, key) {};
        setModuleGlobalState(module, key, value) {};
    }

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                APP_TEST_HTTP_PROVIDERS,
                ClientOverviewService,
            ],
        });
    });

    beforeEach(inject([ClientOverviewService, AppStateService, MockBackend], (..._) => {
        [clientOverviewService, appStateService, backend] = _;
    }));
    
    describe('.getClients', () => {
        let subscription;
        
        describe('When clients list is available', () => {
                it('Clients list should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([clients])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Get);
                        expect(conn.request.url).toEqual(getClientsServiceEndPoint);
                    });
                    
                    clientOverviewService.getClients().subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
     	describe('When clients list is not available', () => {
    		it('Clients list should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getClientsServiceEndPoint);
                });
                
                clientOverviewService.getClients().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });
    
    describe('.getFunds', () => {
        let subscription;
        
        describe('When funds list is available', () => {
                it('Funds list should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([funds])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Get);
                        expect(conn.request.url).toEqual(getFundsServiceEndPoint + 'ALL');
                    });
                    
                    clientOverviewService.getAllFunds().subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
     	describe('When funds list is not available', () => {
    		it('Funds list should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getFundsServiceEndPoint + 'ALL');
                });
                
                clientOverviewService.getAllFunds().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    }); 

    describe('.getRegions', () => {
        let subscription;
        
        describe('When regions list is available', () => {
                it('Regions list should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([regions])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Get);
                        expect(conn.request.url).toEqual(getRegionsServiceEndPoint + 'ALL');
                    });
                    
                    clientOverviewService.getAllRegions().subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
     	describe('When regions list is not available', () => {
    		it('Regions list should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getRegionsServiceEndPoint + 'ALL');
                });
                
                clientOverviewService.getAllRegions().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });
    
    describe('.getCOBDates', () => {
        let subscription;
        
        describe('When COB dates list is available', () => {
                it('COB dates list should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([COBDates])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Get);
                        expect(conn.request.url).toEqual(getCOBDatesServiceEndPoint);
                    });
                    
                    clientOverviewService.getCOBDates().subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
     	describe('When COB dates list is not available', () => {
    		it('COB dates list should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getCOBDatesServiceEndPoint);
                });
                
                clientOverviewService.getCOBDates().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });
    
    describe('.getCOBDatesMonthly', () => {
        let subscription;
        
        describe('When monthly COB dates list is available', () => {
                it('Monthly COB dates list should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([COBDatesMonthly])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Get);
                        expect(conn.request.url).toEqual(getCOBDatesMonthlyServiceEndPoint);
                    });
                    
                    clientOverviewService.getCOBDatesMonthly().subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
     	describe('When monthly COB dates list is not available', () => {
    		it('Monthly COB dates list should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getCOBDatesMonthlyServiceEndPoint);
                });
                
                clientOverviewService.getCOBDatesMonthly().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });
    
    describe('.getFinancingBalance', () => {
        let subscription;
        
        describe('When financing balance is available', () => {
                it('Financing balance should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([financingBalance])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Post);
                        expect(conn.request.url).toEqual(getFinancingBalanceServiceEndPoint);
                    });
                    
                    clientOverviewService.getFinancingBalance(chartFilter).subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
        describe('When financing balance is not available', () => {
            it('Financing balance should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(getFinancingBalanceServiceEndPoint);
                });
                
                clientOverviewService.getFinancingBalance(chartFilter).subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });

    describe('.getEquityBalance', () => {
        let subscription;
        
        describe('When equity balance is available', () => {
                it('Equity balance should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([equityBalance])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Post);
                        expect(conn.request.url).toEqual(getEquityBalanceServiceEndPoint);
                    });
                    
                    clientOverviewService.getEquityBalance(chartFilter).subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
        describe('When equity balance is not available', () => {
            it('Equity balance should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(getEquityBalanceServiceEndPoint);
                });
                
                clientOverviewService.getEquityBalance(chartFilter).subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });    

    describe('.getBalanceSheetROA', () => {
        let subscription;
        
        describe('When balance sheet ROA is available', () => {
                it('Balance sheet ROA should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([balanceSheetROA])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Post);
                        expect(conn.request.url).toEqual(getBalanceSheetROAServiceEndPoint);
                    });
                    
                    clientOverviewService.getBalanceSheetROA(chartFilter).subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
        describe('When balance sheet ROA is not available', () => {
            it('Balance sheet ROA balance should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(getBalanceSheetROAServiceEndPoint);
                });
                
                clientOverviewService.getBalanceSheetROA(chartFilter).subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });

    describe('.getRevenue', () => {
        let subscription;
        
        describe('When revenue is available', () => {
                it('Revenue should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([revenue])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Post);
                        expect(conn.request.url).toEqual(getRevenueServiceEndPoint);
                    });
                    
                    clientOverviewService.getRevenue(chartFilter).subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
        describe('When revenue is not available', () => {
            it('Revenue should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(getRevenueServiceEndPoint);
                });
                
                clientOverviewService.getRevenue(chartFilter).subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    });    
    
   describe('.getSecurityCountryRisk', () => {
        let subscription;
        
        describe('When security country risk data is available', () => {
            it('Security country risk data should be available', () => {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({
                        	body: JSON.stringify([securityCountryRisk])
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Post);
                        expect(conn.request.url).toEqual(getSecurityCountryRiskServiceEndPoint);
                    });
                    
                    clientOverviewService.getSecurityCountryRisk(chartFilter).subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
         });
         
        describe('When security country risk data is not available', () => {
            it('Security country risk data should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(getSecurityCountryRiskServiceEndPoint);
                });
                
                clientOverviewService.getSecurityCountryRisk(chartFilter).subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                });
            });
    	}); 
         
    }); 
   
   describe('.getSecurityProduct', () => {
       let subscription;
       
       describe('When security product data is available', () => {
           it('Security product data should be available', () => {
                   backend.connections.subscribe(conn => {
                       conn.mockRespond(new Response(new ResponseOptions({
                       	body: JSON.stringify([securityProduct])
                       })));
                       expect(conn.request.method).toEqual(RequestMethod.Post);
                       expect(conn.request.url).toEqual(getSecurityProductServiceEndPoint);
                   });
                   
                   clientOverviewService.getSecurityProduct(chartFilter).subscribe(isReady => {
                       expect(isReady).toBeTruthy();
                   });
               });
        });
        
       describe('When security product data is not available', () => {
           it('Security product data should not be available', () => {
               backend.connections.subscribe(conn => {
                   conn.mockRespond(new Response(new ResponseOptions({
                       body: JSON.stringify([])
                   })));
                   expect(conn.request.method).toEqual(RequestMethod.Post);
                   expect(conn.request.url).toEqual(getSecurityProductServiceEndPoint);
               });
               
               clientOverviewService.getSecurityProduct(chartFilter).subscribe(isReady => {
               	expect(isReady).toBeTruthy();
               });
           });
   		}); 
        
   }); 

   describe('.getSecuritySector', () => {
       let subscription;
       
       describe('When security sector data is available', () => {
           it('Security product sector data should be available', () => {
                   backend.connections.subscribe(conn => {
                       conn.mockRespond(new Response(new ResponseOptions({
                       	body: JSON.stringify([securitySector])
                       })));
                       expect(conn.request.method).toEqual(RequestMethod.Post);
                       expect(conn.request.url).toEqual(getSecuritySectorServiceEndPoint);
                   });
                   
                   clientOverviewService.getSecuritySector(chartFilter).subscribe(isReady => {
                       expect(isReady).toBeTruthy();
                   });
               });
        });
        
       describe('When security sector data is not available', () => {
           it('Security sector data should not be available', () => {
               backend.connections.subscribe(conn => {
                   conn.mockRespond(new Response(new ResponseOptions({
                       body: JSON.stringify([])
                   })));
                   expect(conn.request.method).toEqual(RequestMethod.Post);
                   expect(conn.request.url).toEqual(getSecuritySectorServiceEndPoint);
               });
               
               clientOverviewService.getSecuritySector(chartFilter).subscribe(isReady => {
               	expect(isReady).toBeTruthy();
               });
           });
   		}); 
        
   });    

   describe('.getSecurityMarketCap', () => {
       let subscription;
       
       describe('When security market cap data is available', () => {
           it('Security product market cap data should be available', () => {
                   backend.connections.subscribe(conn => {
                       conn.mockRespond(new Response(new ResponseOptions({
                       	body: JSON.stringify([securityMarketCap])
                       })));
                       expect(conn.request.method).toEqual(RequestMethod.Post);
                       expect(conn.request.url).toEqual(getSecurityMarketCapServiceEndPoint);
                   });
                   
                   clientOverviewService.getSecurityMarketCap(chartFilter).subscribe(isReady => {
                       expect(isReady).toBeTruthy();
                   });
               });
        });
        
       describe('When security market cap data is not available', () => {
           it('Security market cap data should not be available', () => {
               backend.connections.subscribe(conn => {
                   conn.mockRespond(new Response(new ResponseOptions({
                       body: JSON.stringify([])
                   })));
                   expect(conn.request.method).toEqual(RequestMethod.Post);
                   expect(conn.request.url).toEqual(getSecurityMarketCapServiceEndPoint);
               });
               
               clientOverviewService.getSecurityMarketCap(chartFilter).subscribe(isReady => {
               	expect(isReady).toBeTruthy();
               });
           });
   		}); 
        
   });
   
});