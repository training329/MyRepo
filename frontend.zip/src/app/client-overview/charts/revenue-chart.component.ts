// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import { ChartModule } from 'angular2-highcharts'; 
import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import { Revenue } from '../../models/revenue';
import { ChartFilter } from '../../models/chart-filter';

//Application Services
import { ClientOverviewChartService } from './client-overview-chart.service';
import { ClientOverviewService } from '../client-overview.service';
import { HttpErrorHandler } from "../../services/http-error-handler";

@Component({
	selector: 'revenue-chart',
	styleUrls: ['./client-overview-chart.component.scss'],
	templateUrl: './revenue-chart.component.html'
})

export class RevenueChartComponent  {
	
	revenue: Array<Revenue>;
	@Input() chartFilter: ChartFilter;
	revenueChart: Object;
	
	constructor(private clientOverviewChartService: ClientOverviewChartService,
			private errorHandler: HttpErrorHandler,
			private clientOverviewService: ClientOverviewService) {
		console.debug('RevenueChartComponent::constructor');
		this.calculateRevenueChartData(this.revenue, this.chartFilter);
	}

	ngOnChanges(changes: SimpleChange) {
		console.debug('RevenueChartComponent::ngOnChanges', changes);
		if(this.chartFilter) {
			this.getRevenue();
		}
	}
	
	getRevenue(): void {
		console.debug('RevenueChartComponent::getRevenue', this.chartFilter);
		this.clientOverviewService.getRevenue(this.chartFilter) .subscribe(res => {
			this.revenue = res;
			this.calculateRevenueChartData(this.revenue, this.chartFilter);
		}, e => {
			toastr.error('Error while getting revenue data. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	calculateRevenueChartData(data, chartFilter) {
		console.debug('RevenueChartComponent::calculateRevenueChartData', data, chartFilter);
		var chartCatagories = [];
		var chartSeries = [];
		var out = [];
		
		if(data && data.length > 0) {
			out = data.reverse();
		}
		
		if(chartFilter) {
			chartCatagories = this.clientOverviewChartService.getChartCategories(out, chartFilter.type);
		}
		
		chartSeries.push({name:'FEE',data:_.map(_.pluck(out, 'fee'),function(value,key,items){return Math.round(value/100)/10}),color : '#4E728F'});
		chartSeries.push({name:'CASH',data:_.map(_.pluck(out, 'cash'),function(value,key,items){return Math.round(value/100)/10}),color : '#969696'});
		chartSeries.push({name:'SHORTS',data:_.map(_.pluck(out, 'shorts'),function(value,key,items){return Math.round(value/100)/10}),color : '#90CCEF'});
				
		this.revenueChart = this.clientOverviewChartService.plotChart('PB Revenue', chartCatagories, '($ 000s)', chartSeries);
	}

}

