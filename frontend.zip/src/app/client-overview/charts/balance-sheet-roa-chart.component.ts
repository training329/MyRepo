// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import { ChartModule } from 'angular2-highcharts'; 
import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import { BalanceSheetROA } from '../../models/balance-sheet-roa';
import { ChartFilter } from '../../models/chart-filter';

//Application Services
import { ClientOverviewChartService } from './client-overview-chart.service';
import { ClientOverviewService } from '../client-overview.service';
import { HttpErrorHandler } from "../../services/http-error-handler";

@Component({
	selector: 'balance-sheet-roa-chart',
	styleUrls: ['./client-overview-chart.component.scss'],
	templateUrl: './balance-sheet-roa-chart.component.html',
	providers: [HttpErrorHandler]
})

export class BalanceSheetROAChartComponent  {
	
	balanceSheetROA: Array<BalanceSheetROA>;
	@Input() chartFilter: ChartFilter;
	balanceSheetROAChart: Object;
	
	constructor(private clientOverviewChartService: ClientOverviewChartService,
			private errorHandler: HttpErrorHandler,
			private clientOverviewService: ClientOverviewService) {
		console.debug('BalanceSheetROAChartComponent::constructor');
		this.calculateBalanceSheetROAChartData(this.balanceSheetROA, this.chartFilter);
	}

	ngOnChanges(changes: SimpleChange) {
		console.debug('BalanceSheetROAChartComponent::ngOnChanges', changes);
		if(this.chartFilter) {
			this.getBalanceSheetROA();
		}
	}
	
	getBalanceSheetROA(): void {
		console.debug('BalanceSheetROAChartComponent::getBalanceSheetROA', this.chartFilter);
		this.clientOverviewService.getBalanceSheetROA(this.chartFilter) .subscribe(res => {
			this.balanceSheetROA = res;
			this.calculateBalanceSheetROAChartData(this.balanceSheetROA, this.chartFilter);
		}, e => {
			toastr.error('Error while getting Balance Sheet ROA data. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	calculateBalanceSheetROAChartData(data, chartFilter) {
		console.debug('BalanceSheetROAChartComponent::calculateBalanceSheetROAChartData', data, chartFilter);
		var chartCatagories = [];
		var chartSeries = [];
		var out = [];

		if(data && data.length > 0) {
			out = data.reverse();
		}
		
		if(chartFilter) {
			chartCatagories = this.clientOverviewChartService.getChartCategories(out, chartFilter.type);
		}	
		
		chartSeries.push({name:'Balance Sheet',data:_.map(_.pluck(out, 'without_seclending_balsheet'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
		chartSeries.push({name:'ROA',type: 'spline',  yAxis: 1,data:_.map(_.pluck(out, 'roa'),function(value,key,items){return value}),color : '#00bfff'});	
		
		this.balanceSheetROAChart = this.clientOverviewChartService.plotMixedChart('Balance Sheet and ROA', chartCatagories, '($ Billions)', 'Gross ROA (bps)', chartSeries);
	}

}

