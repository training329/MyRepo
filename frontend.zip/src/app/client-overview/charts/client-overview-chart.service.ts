import { Injectable } from '@angular/core';
import { ChartModule, Highcharts } from 'angular2-highcharts'; 
require('highcharts/modules/exporting')(Highcharts);
import * as _ from 'underscore';


@Injectable()
export class ClientOverviewChartService {
	
	timeperiod: string = " (Daily)";	
	constructor(){}
	
	getChartCategories(out, type) {
		console.debug('ClientOverviewChartService::getChartCategories ', out, type);
		var monthNames: any[] = ["Months","Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];
		if(type === "D") {
			this.timeperiod = " (Daily)";
		} else {
			this.timeperiod= " (Monthly)";
		}
		
		var cats= _.map(_.pluck(out, 'cob_date'), function(date) {
			 var dateString  = date;
		     var year        = dateString.substring(2,4);
		     var month       = dateString.substring(4,6);
		     var day         = dateString.substring(6,8);	
		     var dateobject  = new Date(year, month, day);
		   
			if(type == "D") {
				return day + ' ' + monthNames[parseInt(month)];
			} else {
				return monthNames[parseInt(month)] + ' ' + year;
			}
		});
		return cats;
	}
	
	plotChart(chartTitleText, chartCatagories, chartYAxisText, chartSeries) {
		console.debug('ClientOverviewChartService::plotChart ', chartTitleText, this.timeperiod, chartCatagories, chartYAxisText, chartSeries);
		chartTitleText = chartTitleText + this.timeperiod;
		return {  
			exporting: {
			 	enabled: true ,
		        chartOptions: { // specific options for the exported image
	                plotOptions: {
	                    series: {
	                        dataLabels: {
	                            enabled: true
	                        }
	                    }
	                }
	            },
	            scale: 3,
	            fallbackToExportServer: false
			},
			chart : {
				type : 'column',
				zoomType: 'xy',
				height: 300
				/*height: 335,
		        width: 720,
				borderColor: '#A6A6A6',
				borderWidth:1,
				backgroundColor:'#F3F3F3'*/
			},
			title : {
				text : chartTitleText,
			},
			subtitle : {
				text : '',
				x : -20
			},
			credits : {
				enabled : false
			},
			xAxis : {
				categories : chartCatagories,
				labels : {}
			},
			yAxis : {
				title : {
					text : chartYAxisText
				},
				stackLabels: {
	                enabled: true,
	                style: {
	                    fontWeight: 'bold',
	                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
	                },
					formatter : function() {
						var sum = 0;
						var series = this.axis.series;	
						for ( var i in series) {
							if (series[i].visible && series[i].options.stacking == 'normal')
								sum += series[i].yData[this.x];
						}
						if (this.total > 0) {
							return Highcharts.numberFormat(sum, 1);
						} else {
							return '';
						}
					}
	            },
				enabled : true,
				style : {
					fontWeight : 'bold',
					color : (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
				}
	
			},
			tooltip : {
				headerFormat : '<span style="font-size:9px;"><b>{point.key}</b></span><table>',
				pointFormat : '<tr><td style="color:{series.color};padding:0;font-size:9px;">{series.name}: </td>'
						+ '<td style="padding:0;font-size:9px;"><b>{point.y}</b></td></tr>',
				footerFormat : '</table>',
				shared : true,
				useHTML : true
			},
			legend : {
				align : 'center',
				verticalAlign : 'bottom',
				floating : false,
				shadow : false,
				itemStyle:{
					fontSize:'10px'
				}
			},
			plotOptions : {
				column : {
					stacking : 'normal',
					dataLabels : {
						enabled : true,
						color : (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
						style : {
							textShadow : '0 0 3px gray',
						    fontSize:'9px'
						},
						formatter : function() {
							if (this.y != 0)
								return this.y;
						}	
					}
				}
			},
			series :chartSeries,
		};
	}
	
	plotMixedChart(chartTitleText, chartCatagories, chartYAxisText, chartYAxisText1, chartSeries) {
		console.debug('ClientOverviewChartService::plotMixedChart ', chartTitleText, this.timeperiod, chartCatagories, chartYAxisText, chartYAxisText1, chartSeries);
		chartTitleText = chartTitleText + this.timeperiod;
		return {
			exporting: { enabled: true }, 
			chart : {
				type : 'column',
				zoomType: 'xy',
				height: 300
				/*height: 335,
		        width: 720,
				borderColor: '#A6A6A6',
				borderWidth: 1,
				backgroundColor:'#F3F3F3'*/
			},
			title : {
				text : chartTitleText,
				//align: 'left'
			},
			subtitle : {
				text : '',
				x : -20
			},
			credits : {
				enabled : false
			},
			xAxis : {
				categories : chartCatagories,
				labels : {}
			},
			yAxis :[ {
				title : {
					text : chartYAxisText
				},
				//min : 0,
				stackLabels: {
	                enabled: true,
	                style: {
	                    fontWeight: 'bold',
	                    color: 'gray'
	                }, 
	                formatter : function() {
						var sum = 0;
						var series = this.axis.series;
						for ( var i in series) {
							if (series[i].visible && series[i].options.stacking == 'normal')
								sum += series[i].yData[this.x];
						}
						if (this.total > 0) {
							return Highcharts.numberFormat(sum, 1);
						} else {
							return '';
						}
					}
	            },
				enabled : true,
				style : {
					fontWeight : 'bold',
					color : (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
				}

			}, {
				title : {
					text : chartYAxisText1
				},
				min : 0,
				enabled : true,
				style : {
					fontWeight : 'bold',
					color : (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
				},
				opposite: true
			}],
			tooltip : {
				headerFormat : '<span style="font-size:9px;"><b>{point.key}</b></span><table>',
				pointFormat : '<tr><td style="color:{series.color};padding:0;font-size:9px;">{series.name}: </td>'
						+ '<td style="padding:0;font-size:9px;"><b>{point.y}</b></td></tr>',
				footerFormat : '</table>',
				shared : true,
				useHTML : true
			},
			legend : {
				align : 'center',
				verticalAlign : 'bottom',
				floating : false,
				shadow : false,
				itemStyle:{
					fontSize:'10px'
				}
			},
			plotOptions : {
				column : {
					stacking : 'normal',
					dataLabels : {
						enabled : true,
						color : (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
						style : {
							textShadow : '0 0 3px gray',
							fontSize:'9px'
						},
						formatter : function() {
							if (this.y != 0)
								return this.y;
						}
					}
				}
			},
			series :chartSeries,
		};
	}
	
	getIndexLevel(region) : string {
		console.debug('ClientOverviewChartService::getIndexLevel ', region);
		var indexLevels = {
			'GLOBAL': 'MSCI Global',
		    'NAM': 'S&P 500',
		    'APAC': 'Asia Apex 50',
		    'EMEA': 'MSCI Euro',
		    'default': 'MSCI Global'
		};
		return (indexLevels[region] || indexLevels['default']);
	}
	
}