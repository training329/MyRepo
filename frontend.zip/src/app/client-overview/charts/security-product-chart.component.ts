// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import { ChartModule } from 'angular2-highcharts'; 
import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import { SecurityProduct } from '../../models/security-product';
import { ChartFilter } from '../../models/chart-filter';

//Application Services
import { ClientOverviewChartService } from './client-overview-chart.service';
import { ClientOverviewService } from '../client-overview.service';
import { HttpErrorHandler } from "../../services/http-error-handler";

@Component({
	selector: 'security-product-chart',
	styleUrls: ['./client-overview-chart.component.scss'],
	templateUrl: './security-product-chart.component.html'
})

export class SecurityProductChartComponent  {
	
	securityProduct: Array<SecurityProduct> = [];
	@Input() chartFilter: ChartFilter;
	securityProductChart: Object;
	
	constructor(private clientOverviewChartService: ClientOverviewChartService,
			private errorHandler: HttpErrorHandler,
			private clientOverviewService: ClientOverviewService) {
		console.debug('SecurityProductChartComponent::constructor');
		this.calculateSecurityProductChartData(this.securityProduct, this.chartFilter);
	}

	ngOnChanges(changes: SimpleChange) {
		console.debug('SecurityProductChartComponent::ngOnChanges', changes);
		if(this.chartFilter) {
			this.getSecurityProduct();
		}
	}
	
	getSecurityProduct(): void {
		console.debug('SecurityProductChartComponent::getSecurityProduct', this.chartFilter);
		this.clientOverviewService.getSecurityProduct(this.chartFilter) .subscribe(res => {
			this.securityProduct = res;
			this.calculateSecurityProductChartData(this.securityProduct, this.chartFilter);
		}, e => {
			toastr.error('Error while getting Security Product data. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	calculateSecurityProductChartData(data, chartFilter) {
		console.debug('SecurityProductChartComponent::calculateSecurityProductChartData', data, chartFilter);
		var chartCatagories = [];
		var chartSeries = [];
		var out = [];
		
		if(data && data.length > 0) {
			out = data.reverse();
		}
		
		if(chartFilter) {
			chartCatagories = this.clientOverviewChartService.getChartCategories(out, chartFilter.type);
		}	
		
		chartSeries.push({name:'Preferreds',data:_.map(_.pluck(out, 'preferreds'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
		chartSeries.push({name:'Warrants',data:_.map(_.pluck(out, 'warrants'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#191970'});
		chartSeries.push({name:'Others',data:_.map(_.pluck(out, 'other'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#2f4f4f'});
		chartSeries.push({name:'Sovereigns',data:_.map(_.pluck(out, 'sovereigns'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#bc8f8f'});
		chartSeries.push({name:'Convertibles',data:_.map(_.pluck(out, 'convertibles'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#AEB2EF'});	
		chartSeries.push({name:'Corporates',data:_.map(_.pluck(out, 'corporates'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});
		chartSeries.push({name:'Equities',data:_.map(_.pluck(out, 'equities'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
				
		this.securityProductChart = this.clientOverviewChartService.plotChart('GMV By Product', chartCatagories, '($ Billions)', chartSeries);
	}

}

