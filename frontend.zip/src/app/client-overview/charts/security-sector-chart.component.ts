// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import { ChartModule } from 'angular2-highcharts'; 
import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import { SecuritySector } from '../../models/security-sector';
import { ChartFilter } from '../../models/chart-filter';

//Application Services
import { ClientOverviewChartService } from './client-overview-chart.service';
import { ClientOverviewService } from '../client-overview.service';
import { HttpErrorHandler } from "../../services/http-error-handler";

@Component({
	selector: 'security-sector-chart',
	styleUrls: ['./client-overview-chart.component.scss'],
	templateUrl: './security-sector-chart.component.html'
})

export class SecuritySectorChartComponent  {
	
	securitySector: Array<SecuritySector>;
	@Input() chartFilter: ChartFilter;
	securitySectorChart: Object;
	
	constructor(private clientOverviewChartService: ClientOverviewChartService,
			private errorHandler: HttpErrorHandler,
			private clientOverviewService: ClientOverviewService) {
		console.debug('SecuritySectorChartComponent::constructor');
		this.calculateSecuritySectorChartData(this.securitySector, this.chartFilter);
	}

	ngOnChanges(changes: SimpleChange) {
		console.debug('SecuritySectorChartComponent::ngOnChanges', changes);
		if(this.chartFilter) {
			this.getSecuritySector();
		}
	}
	
	getSecuritySector(): void {
		console.debug('SecuritySectorChartComponent::getSecuritySector', this.chartFilter);
		this.clientOverviewService.getSecuritySector(this.chartFilter) .subscribe(res => {
			this.securitySector = res;
			this.calculateSecuritySectorChartData(this.securitySector, this.chartFilter);
		}, e => {
			toastr.error('Error while getting Security Sector data. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	calculateSecuritySectorChartData(data, chartFilter) {
		console.debug('SecuritySectorChartComponent::calculateSecuritySectorChartData', data, chartFilter);
		var chartCatagories = [];
		var chartSeries = [];
		var out = [];
		
		if(data && data.length > 0) {
			out = data.reverse();
		}
		
		if(chartFilter) {
			chartCatagories = this.clientOverviewChartService.getChartCategories(out, chartFilter.type);
		}
		
		chartSeries.push({name:'Telecom',data:_.map(_.pluck(out, 'telecommunications'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#ffdab9'});
		chartSeries.push({name:'Utils',data:_.map(_.pluck(out, 'utilities'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#a52a2a'});
		chartSeries.push({name:'Consumer staples',data:_.map(_.pluck(out, 'consumer_staples'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});
		chartSeries.push({name:'Materials',data:_.map(_.pluck(out, 'materials'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#2f4f4f'});				
		chartSeries.push({name:'Energy',data:_.map(_.pluck(out, 'energy'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
		chartSeries.push({name:'Industrials',data:_.map(_.pluck(out, 'industrials'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#bc8f8f'});
		chartSeries.push({name:'Health care',data:_.map(_.pluck(out, 'health_care'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
		chartSeries.push({name:'Financials',data:_.map(_.pluck(out, 'financials'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#EAB2EF'});
		chartSeries.push({name:'IT',data:_.map(_.pluck(out, 'information_technology'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#191970'});
		chartSeries.push({name:'Consumer discretionary',data:_.map(_.pluck(out, 'consumer_discretionary'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#AEB2EF'});
		chartSeries.push({name:'Others',data:_.map(_.pluck(out, 'other'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#ff8c00'});
				
		this.securitySectorChart = this.clientOverviewChartService.plotChart('GMV By Sector', chartCatagories, '($ Billions)', chartSeries);
	}

}

