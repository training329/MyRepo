// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import { ChartModule } from 'angular2-highcharts'; 
import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import { FinancingBalance } from '../../models/financing-balance';
import { ChartFilter } from '../../models/chart-filter';

//Application Services
import { ClientOverviewChartService } from './client-overview-chart.service';
import { ClientOverviewService } from '../client-overview.service';
import { HttpErrorHandler } from "../../services/http-error-handler";

@Component({
	selector: 'financing-balance-chart',
	styleUrls: ['./client-overview-chart.component.scss'],
	templateUrl: './financing-balance-chart.component.html'
})

export class FinancingBalanceChartComponent  {
	
	financingBalance: Array<FinancingBalance>;
	@Input() chartFilter: ChartFilter;
	financingBalanceChart: Object;
	
	constructor(private clientOverviewChartService: ClientOverviewChartService,
			private errorHandler: HttpErrorHandler,
			private clientOverviewService: ClientOverviewService) {
		console.debug('FinancingBalanceChartComponent::constructor');
		this.calculateFinancingBalanceChartData(this.financingBalance, this.chartFilter);
	}

	ngOnChanges(changes: SimpleChange) {
		console.debug('FinancingBalanceChartComponent::ngOnChanges', changes);
		if(this.chartFilter) {
			this.getFinancingBalance();
		}
	}
	
	getFinancingBalance(): void {
		console.debug('FinancingBalanceChartComponent::getFinancingBalance', this.chartFilter);
		this.clientOverviewService.getFinancingBalance(this.chartFilter) .subscribe(res => {
			this.financingBalance = res;
			this.calculateFinancingBalanceChartData(this.financingBalance, this.chartFilter);
		}, e => {
			toastr.error('Error while getting Financing Balance data. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	calculateFinancingBalanceChartData(data, chartFilter) {
		console.debug('FinancingBalanceChartComponent::calculateFinancingBalanceChartData', data, chartFilter);
		var chartCatagories = [];
		var chartSeries = [];
		var indexLevel = "MSCI Global";
		var out = [];
		
		if(data && data.length > 0) {
			out = data.reverse();
		}
		
		if(chartFilter) {
			chartCatagories = this.clientOverviewChartService.getChartCategories(out, chartFilter.type);
			indexLevel = this.clientOverviewChartService.getIndexLevel(chartFilter.region);
		}	
		
		chartSeries.push({name:'Others', data:_.map(_.pluck(out, 'others'), function(value,key,items){ return Math.round(value/100000000)/10}),color : '#191970'});	
		chartSeries.push({name:'Credit', data:_.map(_.pluck(out, 'credit'), function(value,key,items){ return Math.round(value/100000000)/10}),color : '#969696'});
		chartSeries.push({name:'Debit', data:_.map(_.pluck(out, 'debit'), function(value,key,items){ return Math.round(value/100000000)/10}),color : '#4E728F'});
		chartSeries.push({name:'Shorts', data:_.map(_.pluck(out, 'shorts'), function(value,key,items){ return Math.round(value/100000000)/10}),color : '#90CCEF'});		
		chartSeries.push({name:indexLevel, type: 'spline', yAxis: 1, data:_.map(_.pluck(out, 'index_level'), function(value,key,items){ return Math.round(value)}),color : '#FFCC00'});
		
		this.financingBalanceChart = this.clientOverviewChartService.plotMixedChart('Financing Balance', chartCatagories, '($ Billions)', '', chartSeries);
	}

}

