// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import { ChartModule } from 'angular2-highcharts'; 
import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import { EquityBalance } from '../../models/equity-balance';
import { ChartFilter } from '../../models/chart-filter';

//Application Services
import { ClientOverviewChartService } from './client-overview-chart.service';
import { ClientOverviewService } from '../client-overview.service';
import { HttpErrorHandler } from "../../services/http-error-handler";

@Component({
	selector: 'equity-balance-chart',
	styleUrls: ['./client-overview-chart.component.scss'],
	templateUrl: './equity-balance-chart.component.html'
})

export class EquityBalanceChartComponent  {
	
	equityBalance: Array<EquityBalance>;
	@Input() chartFilter: ChartFilter;
	equityBalanceChart: Object;
	
	constructor(private clientOverviewChartService: ClientOverviewChartService,
			private errorHandler: HttpErrorHandler,
			private clientOverviewService: ClientOverviewService) {
		console.debug('EquityBalanceChartComponent::constructor');
		this.calculateEquityBalanceChartData(this.equityBalance, this.chartFilter);
	}

	ngOnChanges(changes: SimpleChange) {
		console.debug('EquityBalanceChartComponent::ngOnChanges ', changes);
		if(this.chartFilter) {
			this.getEquityBalance();
		}
	}
	
	getEquityBalance(): void {
		console.debug('EquityBalanceChartComponent::getEquityBalance ', this.chartFilter);
		this.clientOverviewService.getEquityBalance(this.chartFilter) .subscribe(res => {
			this.equityBalance = res;
			this.calculateEquityBalanceChartData(this.equityBalance, this.chartFilter);
		}, e => {
			toastr.error('Error while getting Equity Balance data. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	calculateEquityBalanceChartData(data, chartFilter) {
		console.debug('EquityBalanceChartComponent::calculateEquityBalanceChartData', data, chartFilter);
		var chartCatagories = [];
		var chartSeries = [];
		var indexLevel = "MSCI Global";
		var out = [];
		
		if(data && data.length > 0) {
			out = data.reverse();
		}
		
		if(chartFilter) {
			chartCatagories = this.clientOverviewChartService.getChartCategories(out, chartFilter.type);
			indexLevel = this.clientOverviewChartService.getIndexLevel(chartFilter.region);
		}
		
		chartSeries.push({name:'Cash',data:_.map(_.pluck(out, 'cash'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});	
		chartSeries.push({name:'SMV',data:_.map(_.pluck(out, 'smv'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
		chartSeries.push({name:'LMV',data:_.map(_.pluck(out, 'lmv'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
		chartSeries.push({name:'Net Equity', type: 'spline', yAxis: 0,data:_.map(_.pluck(out, 'netequity'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#00bfff'});
		chartSeries.push({name:indexLevel, type: 'spline', yAxis: 1,data:_.map(_.pluck(out, 'index_level'),function(value,key,items){return Math.round(value)}),color : '#FFCC00'});
		
		this.equityBalanceChart = this.clientOverviewChartService.plotMixedChart('Equity Balance', chartCatagories, '($ Billions)', '', chartSeries);
	}

}

