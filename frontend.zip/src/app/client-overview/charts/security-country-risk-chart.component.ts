// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import { ChartModule } from 'angular2-highcharts'; 
import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import { SecurityCountryRisk } from '../../models/security-country-risk';
import { ChartFilter } from '../../models/chart-filter';

//Application Services
import { ClientOverviewChartService } from './client-overview-chart.service';
import { ClientOverviewService } from '../client-overview.service';
import { HttpErrorHandler } from "../../services/http-error-handler";

@Component({
	selector: 'security-country-risk-chart',
	styleUrls: ['./client-overview-chart.component.scss'],
	templateUrl: './security-country-risk-chart.component.html'
})

export class SecurityCountryRiskChartComponent  {
	
	securityCountryRisk: Array<SecurityCountryRisk> = [];
	@Input() chartFilter: ChartFilter;
	securityCountryRiskChart: Object;
	
	constructor(private clientOverviewChartService: ClientOverviewChartService,
			private errorHandler: HttpErrorHandler,
			private clientOverviewService: ClientOverviewService) {
		console.debug('SecurityCountryRiskChartComponent::constructor');
		this.calculateSecurityCountryRiskChartData(this.securityCountryRisk, this.chartFilter);
	}

	ngOnChanges(changes: SimpleChange) {
		console.debug('SecurityCountryRiskChartComponent::ngOnChanges', changes);
		if(this.chartFilter) {
			this.getSecurityCountryRisk();
		}
	}
	
	getSecurityCountryRisk(): void {
		console.debug('SecurityCountryRiskChartComponent::getSecurityCountryRisk', this.chartFilter);
		this.clientOverviewService.getSecurityCountryRisk(this.chartFilter) .subscribe(res => {
			this.securityCountryRisk = res;
			this.calculateSecurityCountryRiskChartData(this.securityCountryRisk, this.chartFilter);
		}, e => {
			toastr.error('Error while getting Security Countr yRisk data. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	calculateSecurityCountryRiskChartData(data, chartFilter) {
		console.debug('SecurityCountryRiskChartComponent::calculateSecurityCountryRiskChartData', data, chartFilter);
		var chartCatagories = [];
		var chartSeries = [];
		var out = [];
		
		if(data && data.length > 0) {
			out = data.reverse();
		}
		
		if(chartFilter) {
			chartCatagories = this.clientOverviewChartService.getChartCategories(out, chartFilter.type);
		}	
		
		chartSeries.push({name:'APAC EM L1',data:_.map(_.pluck(out, 'apac_Emerging_Markets_Lev1'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#AEB2EF'});	
		chartSeries.push({name:'APAC EM L2',data:_.map(_.pluck(out, 'apac_Emerging_Markets_Lev2'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});
		chartSeries.push({name:'APAC EM L3',data:_.map(_.pluck(out, 'apac_Emerging_Markets_Lev3'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
		chartSeries.push({name:'Developed',data:_.map(_.pluck(out, 'developed_Markets'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
		chartSeries.push({name:'EMEA EM L1B',data:_.map(_.pluck(out, 'emea_Emerging_Markets_Lev1B'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#bc8f8f'});
		chartSeries.push({name:'EMEA EM L2',data:_.map(_.pluck(out, 'emea_Emerging_Markets_Lev2'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#191970'});
		chartSeries.push({name:'LATAM EM L2',data:_.map(_.pluck(out, 'latam_Emerging_Markets_Lev2'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#2f4f4f'});
		chartSeries.push({name:'Others',data:_.map(_.pluck(out, 'other'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#ffdab9'});
				
		this.securityCountryRiskChart = this.clientOverviewChartService.plotChart('GMV By Country of Risk', chartCatagories, '($ Billions)', chartSeries);
	}

}

