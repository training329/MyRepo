// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import { ChartModule } from 'angular2-highcharts'; 
import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import { SecurityMarketCap } from '../../models/security-market-cap';
import { ChartFilter } from '../../models/chart-filter';

//Application Services
import { ClientOverviewChartService } from './client-overview-chart.service';
import { ClientOverviewService } from '../client-overview.service';
import { HttpErrorHandler } from "../../services/http-error-handler";

@Component({
	selector: 'security-market-cap-chart',
	styleUrls: ['./client-overview-chart.component.scss'],
	templateUrl: './security-market-cap-chart.component.html'
})

export class SecurityMarketCapChartComponent  {
	
	securityMarketCap: Array<SecurityMarketCap>;
	@Input() chartFilter: ChartFilter;
	securityMarketCapChart: Object;
	
	constructor(private clientOverviewChartService: ClientOverviewChartService,
			private errorHandler: HttpErrorHandler,
			private clientOverviewService: ClientOverviewService) {
		console.debug('SecurityMarketCapChartComponent::constructor');
		this.calculateSecurityMarketCapChartData(this.securityMarketCap, this.chartFilter);
	}

	ngOnChanges(changes: SimpleChange) {
		console.debug('SecurityMarketCapChartComponent::ngOnChanges', changes);
		if(this.chartFilter) {
			this.getSecurityMarketCap();
		}
	}
	
	getSecurityMarketCap(): void {
		console.debug('SecurityMarketCapChartComponent::getSecurityMarketCap', this.chartFilter);
		this.clientOverviewService.getSecurityMarketCap(this.chartFilter) .subscribe(res => {
			this.securityMarketCap = res;
			this.calculateSecurityMarketCapChartData(this.securityMarketCap, this.chartFilter);
		}, e => {
			toastr.error('Error while getting Security Market Cap data. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	calculateSecurityMarketCapChartData(data, chartFilter) {
		console.debug('SecurityMarketCapChartComponent::calculateSecurityMarketCapChartData', data, chartFilter);
		var chartCatagories = [];
		var chartSeries = [];
		var out = [];
		
		if(data && data.length > 0) {
			out = data.reverse();
		}
		
		if(chartFilter) {
			chartCatagories = this.clientOverviewChartService.getChartCategories(out, chartFilter.type);
		}
		
		chartSeries.push({name:'Micro',data:_.map(_.pluck(out, 'micro'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#ff8c00'});
		chartSeries.push({name:'Nano',data:_.map(_.pluck(out, 'nano'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#bc8f8f'});
		chartSeries.push({name:'Small',data:_.map(_.pluck(out, 'small'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#191970'});				
		chartSeries.push({name:'Big Large',data:_.map(_.pluck(out, 'bigLarge'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#2f4f4f'});	
		chartSeries.push({name:'Others',data:_.map(_.pluck(out, 'other'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#969696'});
		chartSeries.push({name:'Mid',data:_.map(_.pluck(out, 'mid'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#90CCEF'});
		chartSeries.push({name:'Mega',data:_.map(_.pluck(out, 'mega'),function(value,key,items){return Math.round(value/100000000)/10}),color : '#4E728F'});
				
		this.securityMarketCapChart = this.clientOverviewChartService.plotChart('GMV By Market Cap', chartCatagories, '($ Billions)', chartSeries);
	}

}

