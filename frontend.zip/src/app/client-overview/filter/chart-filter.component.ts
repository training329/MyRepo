// Framework
import {Component, Input, Output, SimpleChange, EventEmitter} from "@angular/core";
import { Router, ActivatedRoute, Params } from'@angular/router';
import {Location} from '@angular/common';
import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import { SelectItem } from "../../common/api";
import { MasterData } from '../../models/master-data';
import { ChartFilter } from '../../models/chart-filter';

//Application Services
import {HttpErrorHandler} from "../../services/http-error-handler";
import { ClientOverviewService } from '../client-overview.service';

@Component({
	selector: 'chart-filter',
	styleUrls: ['./chart-filter.component.scss'],
	templateUrl: './chart-filter.component.html'
})

export class ChartFilterComponent  {
	
	newChartFilter: ChartFilter;
	@Output() onFilterChangesNotify: EventEmitter<{chartFilterObj: ChartFilter}>;

	clients: SelectItem[] = [];
	funds: SelectItem[] = [];
	regions: SelectItem[] = [];
	COBDates: SelectItem[] = [];
	
	selectedClientId: string = '999999';
	selectedFundId: string = '9999999999';
	selectedRegionId: string = '1';
	
	selectedClient: string = 'ALL';
	selectedFund: string  = 'ALL';
	selectedRegion: string = 'GLOBAL';
	selectedCOBDate: number = 0;
	type: string = 'D';
	
	formattedCOBDate: Date = new Date();
	
	constructor(private router: Router,
			private errorHandler: HttpErrorHandler,
			private _location: Location,
			private route: ActivatedRoute,
			private clientOverviewService: ClientOverviewService) {
		console.debug('ChartFilterComponent::constructor');
		this.onFilterChangesNotify = new EventEmitter<{chartFilterObj: ChartFilter}>();
	}
	
	ngOnInit() {
		console.debug('ChartFilterComponent::ngOnInit');
		if(this.route.snapshot && this.route.snapshot.params['client'] && this.route.snapshot.params['fund']) {
			this.selectedClient = this.route.snapshot.params['client'];
			this.selectedFund = this.route.snapshot.params['fund'];
			this.getClients();
		} else {
			this.selectedClient = 'ALL';
			this.selectedFund = 'ALL';
			this.initChartFilter();
			
			this.getAllClients();
			this.getAllFunds();
			this.getAllRegions();
		}
		this.selectedRegion = 'GLOBAL';
	}
	
	initChartFilter(): void {
		console.debug('ChartFilterComponent::initChartFilter');
		this.clientOverviewService.getCOBDates().subscribe(res => {
			this.COBDates = res;
			var date = res[0].value;
			this.selectedCOBDate = date;
			
			this.setFilterNotifyCharts();
			
		}, e => this.errorHandler.handle(e))
	}
	
	setFilterNotifyCharts() {
		console.debug('ChartFilterComponent::setFilterNotifyCharts');
		this.newChartFilter = new ChartFilter();
		this.newChartFilter.type = this.type;
		this.newChartFilter.cob_date = this.selectedCOBDate;
		this.newChartFilter.client = this.selectedClient;
		this.newChartFilter.fund = this.selectedFund;
		this.newChartFilter.region = this.selectedRegion;
		
		this.formatCOBDate(this.selectedCOBDate);
		
		this.onFilterChangesNotify.next({ chartFilterObj: this.newChartFilter });
	}
	
	formatCOBDate(date) {
		console.debug('ChartFilterComponent::formatCOBDate ', date);
		var dateString = date.toString();
	    var year = dateString.substring(0,4);
	    var month = dateString.substring(4,6);
	    var day = dateString.substring(6,8);	
	    this.formattedCOBDate = new Date(year, month-1, day);
	}
	
	getAllClients(): void {
		console.debug('ChartFilterComponent::getAllClients');
		this.clientOverviewService.getClients().subscribe(res => {
			this.clients = res;
		}, e => {
			toastr.error('Error while getting clients. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	getAllFunds(): void {
		console.debug('ChartFilterComponent::getAllFunds');
		this.clientOverviewService.getAllFunds().subscribe(res => {
			this.funds = res;
		}, e => {
			toastr.error('Error while getting funds. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	getAllRegions(): void {
		console.debug('ChartFilterComponent::getAllRegions');
		this.clientOverviewService.getAllRegions().subscribe(res => {
			this.regions = res;
		}, e => {
			toastr.error('Error while getting regions. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	getClients(): void {
		console.debug('ChartFilterComponent::getClients');
		this.clientOverviewService.getClients().subscribe(res => {
			this.clients = res;
			
			if(this.route.snapshot && this.route.snapshot.params['client']) {
				this.extractClientId(this.selectedClient);
			} else {
				this.extractClient(this.selectedClientId);
			}
			this.getFunds();
		}, e => {
			toastr.error('Error while getting clients. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}

	getFunds(): void {
		console.debug('ChartFilterComponent::getFunds ', this.selectedClient);
		this.clientOverviewService.getFunds(this.selectedClient).subscribe(res => {
			this.funds = res;
			
			if(this.route.snapshot && this.route.snapshot.params['fund']) {
	            this.extractFundId(this.selectedFund);
	        } else {
	        	this.extractFund(this.selectedFundId);
	        }
			
			this.getRegions();
		}, e => {
			toastr.error('Error while getting funds. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	getRegions(): void {
		console.debug('ChartFilterComponent::getRegions ', this.selectedFund);
		this.clientOverviewService.getRegions(this.selectedFund).subscribe(res => {
			this.regions = res;
			this.extractRegion(this.selectedRegionId);
			this.getCOBDates();
		}, e => {
			toastr.error('Error while getting regions. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	getCOBDates(): void {
		console.debug('ChartFilterComponent::getCOBDates');
		this.clientOverviewService.getCOBDates() .subscribe(res => {
			this.COBDates = res;
			var date = res[0].value;
			 
			if(this.route.snapshot && this.route.snapshot.params['cobdate']){
			    this.selectedCOBDate = this.route.snapshot.params['cobdate'];
		    } 
			else if(this.selectedCOBDate == 0) {
				this.selectedCOBDate = date;
			}
			this.setFilterNotifyCharts();
		}, e => {
			toastr.error('Error while getting cob dates. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	getCOBDatesMonthly(): void {
		console.debug('ChartFilterComponent::getCOBDatesMonthly');
		this.clientOverviewService.getCOBDatesMonthly() .subscribe(res => {
			this.COBDates = res;
			var date = res[0].value;
			
			if(this.route.snapshot && this.route.snapshot.params['cobdate']){
			    this.selectedCOBDate = this.route.snapshot.params['cobdate'];
		    } 
			
			if(this.selectedCOBDate == 0) {
				this.selectedCOBDate = date;
			}
			this.setFilterNotifyCharts();
		}, e => {
			toastr.error('Error while getting monthly cob dates. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
	}
	
	extractClient(clientId): void {
		console.time('ChartFilterComponent::extractClient');
		var result = _.filter(this.clients, function (item) {
			return item.value == clientId
		});
		var client =  (result[0] as any).label;
		this.selectedClient = client;
		console.timeEnd('ChartFilterComponent::extractClient');
	}
	
	extractClientId(client): void {
		console.time('ChartFilterComponent::getCOBDates');
		var result = _.filter(this.clients, function (item) {
            return item.label == client
        });
     
        this.selectedClient = (result[0] as any).label;
        this.selectedClientId = (result[0] as any).value;
        console.timeEnd('ChartFilterComponent::extractClient');
    }
	
	extractFund(fundId): void {
		console.time('ChartFilterComponent::extractFund');
		var result  = _.filter(this.funds, function (item) {
			return item.value == fundId
		});
		
		var fund = (result[0] as any).label;
		this.selectedFund = fund;
		console.timeEnd('ChartFilterComponent::extractFund');
	}
	
	extractFundId(fund): void {
		console.time('ChartFilterComponent::extractFundId');
		var result  = _.filter(this.funds, function (item) {
            return item.label == fund;
        });
        
        this.selectedFund = (result[0] as any).label;
        this.selectedFundId = (result[0] as any).value;
        console.timeEnd('ChartFilterComponent::extractFundId');
    }
	
	extractRegion(regionId): void {
		console.time('ChartFilterComponent::extractRegion');
		var result  = _.filter(this.regions, function (item) {
			return item.value == regionId
		});
		var region = (result[0] as any).label;
		this.selectedRegion = region;
		console.timeEnd('ChartFilterComponent::extractRegion');
	}
	
	clear(): void {
		console.debug('ChartFilterComponent::clear');
		this.selectedClientId = '999999';
		this.selectedFundId = '9999999999';
		this.selectedRegionId = '1';
		this.type = 'D';
	
		this.selectedClient = 'ALL';
		this.selectedFund  = 'ALL';
		this.selectedRegion = 'GLOBAL';

		this.initChartFilter();
	}
	
	back() {
		this._location.back();
	}
	
	onMenuBeforeShow(event, msg) {
		console.debug('ChartFilterComponent::onMenuBeforeShow: ' + msg, event);
	}

}

