//Framework
import { Injectable } from '@angular/core';
import {JsonHttp} from "../services/json-http";
import { Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import "../common/rxjs-operators";
import { SelectItem } from "../common/api";
import * as _ from 'underscore';

//Application models
import { FinancingBalance } from '../models/financing-balance';
import { EquityBalance } from '../models/equity-balance';
import { BalanceSheetROA } from '../models/balance-sheet-roa';
import { Revenue } from '../models/revenue';
import { SecurityCountryRisk } from '../models/security-country-risk';
import { SecurityProduct } from '../models/security-product';
import { SecuritySector } from '../models/security-sector';
import { SecurityMarketCap } from '../models/security-market-cap';

//Service End Point URI
const getClientsServiceEndPoint = '/api/clientoverview/getClientList';
const getFundsServiceEndPoint = '/api/clientoverview/getFundList/';
const getRegionsServiceEndPoint = '/api/clientoverview/getRegionList/';
const getCOBDatesServiceEndPoint = '/api/clientoverview/getCOBDateList';
const getCOBDatesMonthlyServiceEndPoint = '/api/clientoverview/getMonthlyCOBDateList';

const getFinancingBalanceServiceEndPoint = '/api/clientoverview/getFinancingBalanceDetails/';
const getEquityBalanceServiceEndPoint = '/api/clientoverview/getEquityBalanceDetails/';
const getBalanceSheetROAServiceEndPoint = '/api/clientoverview/getBalanceSheetROA/';
const getRevenueServiceEndPoint = '/api/clientoverview/getRevenue/';
const getSecurityCountryRiskServiceEndPoint = '/api/clientoverview/getSecurityCountryRisk/';
const getSecurityProductServiceEndPoint = '/api/clientoverview/getSecurityProduct/';
const getSecuritySectorServiceEndPoint = '/api/clientoverview/getSecuritySector/';
const getSecurityMarketCapServiceEndPoint = '/api/clientoverview/getSecurityMarketCap/';

@Injectable()
export class ClientOverviewService {
	
	clients: Observable<SelectItem[]>;
	funds: Observable<SelectItem[]>;
	regions: Observable<SelectItem[]>;
	COBDates: Observable<SelectItem[]>;
	COBDatesMonthly: Observable<SelectItem[]>;

	constructor(private http: JsonHttp) {
		console.debug('ClientOverviewService::constructor');
	}
	
	getClients(): Observable<SelectItem[]> {
		console.debug('ClientOverviewService::getClients');
		if(!this.clients) {
			this.clients = this.http.get(getClientsServiceEndPoint)
				.map(this.extractDropDownData)
                .publishReplay(1)
                .refCount()
		}
		return this.clients;
	}
	
	getFunds(client): Observable<SelectItem[]> {
		console.debug('ClientOverviewService::getFunds ', client);
		if(client == 'ALL') {
			return this.getAllFunds();
		} else {
			return this.http.get(getFundsServiceEndPoint + client)
					.map(this.extractDropDownData)
		}
	}
	
	getAllFunds(): Observable<SelectItem[]> {
		console.debug('ClientOverviewService::getAllFunds');
		if(!this.funds) {
			this.funds = this.http.get(getFundsServiceEndPoint + 'ALL')
					.map(this.extractDropDownData)
	                .publishReplay(1)
	                .refCount()
		}
		return this.funds;
	}
	
	getRegions(fund): Observable<SelectItem[]> {
		console.debug('ClientOverviewService::getRegions ', fund);
		if(fund == 'ALL') {
			return this.getAllRegions();
		} else {
			return this.http.get(getRegionsServiceEndPoint + fund)
					.map(this.extractDropDownData)
		}
	}
	
	getAllRegions(): Observable<SelectItem[]> {
		console.debug('ClientOverviewService::getAllRegions');
		if(!this.regions) {
			this.regions = this.http.get(getRegionsServiceEndPoint + 'ALL')
					.map(this.extractDropDownData)
	                .publishReplay(1)
	                .refCount()
		}
		return this.regions;
	}
	
	getCOBDates(): Observable<SelectItem[]> {
		console.debug('ClientOverviewService::getCOBDates');
		if(!this.COBDates) {
			this.COBDates = this.http.get(getCOBDatesServiceEndPoint)
					.map(this.extractCOBDate)
	                .publishReplay(1)
	                .refCount()
		}
		return this.COBDates;
	}
	
	getCOBDatesMonthly(): Observable<SelectItem[]> {
		console.debug('ClientOverviewService::getCOBDatesMonthly');
		if(!this.COBDatesMonthly) {
			this.COBDatesMonthly = this.http.get(getCOBDatesMonthlyServiceEndPoint)
					.map(this.extractCOBDateMonthly)
	                .publishReplay(1)
	                .refCount()
		}
		return this.COBDatesMonthly;
	}
	
	getFinancingBalance(chartFilter): Observable<FinancingBalance[]> {
		console.debug('ClientOverviewService::getFinancingBalance ', chartFilter);
		return this.http.post(getFinancingBalanceServiceEndPoint, chartFilter)
				.map(this.extractUserData)
	}
	
	getEquityBalance(chartFilter): Observable<EquityBalance[]> {
		console.debug('ClientOverviewService::getEquityBalance ', chartFilter);
		return this.http.post(getEquityBalanceServiceEndPoint, chartFilter)
				.map(this.extractUserData)
	}
	
	getBalanceSheetROA(chartFilter): Observable<BalanceSheetROA[]> {
		console.debug('ClientOverviewService::getBalanceSheetROA ', chartFilter);
		return this.http.post(getBalanceSheetROAServiceEndPoint, chartFilter)
				.map(this.extractUserData)
	}
	
	getRevenue(chartFilter): Observable<Revenue[]> {
		console.debug('ClientOverviewService::getRevenue ', chartFilter);
		return this.http.post(getRevenueServiceEndPoint, chartFilter)
				.map(this.extractUserData)
	}
	
	getSecurityCountryRisk(chartFilter): Observable<SecurityCountryRisk[]> {
		console.debug('ClientOverviewService::getSecurityCountryRisk ', chartFilter);
		return this.http.post(getSecurityCountryRiskServiceEndPoint, chartFilter)
				.map(this.extractUserData)
	}
	
	getSecurityProduct(chartFilter): Observable<SecurityProduct[]> {
		console.debug('ClientOverviewService::getSecurityProduct ', chartFilter);
		return this.http.post(getSecurityProductServiceEndPoint, chartFilter)
				.map(this.extractUserData)
	}
	
	getSecuritySector(chartFilter): Observable<SecuritySector[]> {
		console.debug('ClientOverviewService::getSecuritySector ', chartFilter);
		return this.http.post(getSecuritySectorServiceEndPoint, chartFilter)
				.map(this.extractUserData)
	}
	
	getSecurityMarketCap(chartFilter): Observable<SecurityMarketCap[]> {
		console.debug('ClientOverviewService::getSecurityMarketCap ', chartFilter);
		return this.http.post(getSecurityMarketCapServiceEndPoint, chartFilter)
				.map(this.extractUserData)
	}	

	extractUserData(res: Response) {
		console.debug('ClientOverviewService::extractUserData ', res);
		let data = res.json();
		return data;
	}
	
	extractDropDownData(res: Response) {
		console.debug('ClientOverviewService::extractDropDownData ', res);
		let response = res.json();
		var sortedData = _.sortBy(response, function (item) {
			return (item as any).text;
		});
		var data =	 _.map(sortedData, function(item) {
			return {
				"value": (item as any).value,
				"label": (item as any).text
			};
		});
		return data;
	}
	
	extractCOBDate(res: Response) {
		console.debug('ClientOverviewService::extractCOBDate ', res);
		let response = res.json();
		var date =	 _.map(response, function(item) {
			return {
				"value": item,
				"label": item.toString().substring(4,6)+'/'+item.toString().substring(6, 8)+'/'+item.toString().substring(0, 4)
			};
		});
		return date;
	}
	
	extractCOBDateMonthly(res: Response) {
		console.debug('ClientOverviewService::extractCOBDateMonthly ', res);
		let response = res.json();
		var monthNames: any[] = ["Months","Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];
		var date =	 _.map(response, function(item) {
			return {
				"value": item,
				"label": monthNames[parseInt(item.toString().substring(4,6))]+ ' - '+item.toString().substring(0, 4)
			};
		});
		return date;
	}
	
}
