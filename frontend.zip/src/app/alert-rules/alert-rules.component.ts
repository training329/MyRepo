import {Component, OnInit, ViewChild, OnDestroy, Renderer} from'@angular/core';
import {FormControl} from "@angular/forms";
import {Router} from '@angular/router';
import {DataTable} from 'primeng/primeng';
import {Subscription} from 'rxjs/Subscription'

import {AlertRule} from '../models/alert-rule';
import {AlertRulesService} from '../alert-rules/alert-rules.service';
import {HttpErrorHandler} from "../services/http-error-handler";
import {UtilService} from "../services/util.service";
import {AppStateService} from "../services/app-state.service";

@Component({
	selector:'alert-rules',
	templateUrl:'alert-rules.component.html',
	styleUrls:['alert-rules.component.scss'],
	providers: [HttpErrorHandler]
})

export class AlertRulesComponent implements OnInit, OnDestroy {
	
	alertRules:AlertRule[];
	searchText : string = "";
	
	private termControl : FormControl = new FormControl();
    private rulesSubscription:Subscription;

	@ViewChild('dt') rulesTable : DataTable;
	@ViewChild('searchTerm') searchTerm;

	constructor(private router: Router,
				private errorHandler: HttpErrorHandler,
				private alertRulesService: AlertRulesService,
				private utilService:UtilService,
				private appStateService:AppStateService,
				private renderer:Renderer) {
		console.debug('AlertRulesComponent::constructor');
		// Bind search call to formControl
        this.termControl.valueChanges
            .debounceTime(400)
            .distinctUntilChanged()
            .subscribe(term => {
                let previousSearchTerm = this.appStateService.getModuleComponentState('search', 'term');
            	if(term != null && term != previousSearchTerm) {
                    this.appStateService.setModuleComponentState('search', 'term', term);
                    this.appStateService.setModuleComponentState('datatable', 'currentpage', 0);
                }
            });
	}
	
	ngOnInit(): void {
	    console.debug('AlertRulesComponent::ngOnInit');
		this.getFlaggedExceptionList();
	}
	
	getFlaggedExceptionList(): void {
		console.debug('AlertRulesComponent::getFlaggedExceptionList ', 'subscribing to alertRulesService.isReady');
		this.rulesSubscription = this.alertRulesService.getDataNotification()
		.subscribe(isReady => {
            console.debug('AlertRulesComponent::getFlaggedExceptionList ', 'subscriptions completed', isReady);
            if(isReady) {
            	this.alertRules = this.alertRulesService.getRules();
            	this.utilService.showNoRecordMessage(this.rulesTable, (this.alertRules ? this.alertRules.length : 0));
            	setTimeout(() => { // need delay to load data in grid before search
            		this.checkCachedData();
                }, 300);
            }		
		});
	}
	
	onPageChange(event) {
        if(this.rulesTable.rows) {
            console.debug("AlertRulesComponent::onPageChange on page ", event.first/event.rows + " event ", event);
            this.appStateService.setModuleComponentState('datatable', 'currentpage', event.first / event.rows);
            console.debug("AlertRulesComponent::onPageChange rulesTableCurrentPage ",  event.first/event.rows);
        }        
    }
	
	checkCachedData() {
		console.debug("AlertRulesComponent::checkCachedData ");
		this.setCurrentSearch();
		setTimeout(() => {  // need delay to load data in grid before paging
		    let currentpage = this.appStateService.getModuleComponentState('datatable', 'currentpage')
            if(currentpage)
                this.setCurrentPage(Number(currentpage));
			this.appStateService.activateModuleState();
        }, 300);		
	}
	
	setCurrentSearch() {
		console.debug("AlertRulesComponent::setCurrentSearch ");
		var searchTxt =  this.appStateService.getModuleComponentState('search', 'term');
        if(searchTxt && searchTxt != null && searchTxt.trim() != "") {
        	this.searchText = searchTxt;  
        } else {
        	this.searchText = "";
        }
        this.onSearchTextChange();
	}
	
	onSearchTextChange() {
		console.debug('AlertRulesComponent::onSearchTextChange');
		this.rulesTable.onFilterKeyup(this.searchText, 'data', 'contains');  // invoking global filter on data table manually with dummy arguments 
	}
	
	setCurrentPage(n: number) {
        console.debug("AlertRulesComponent::setCurrentPage page ", n + " rulesTable rows"+ this.rulesTable.rows);
        if(this.rulesTable.rows) {
            let paging = {
                first: (n * this.rulesTable.rows),
                rows: this.rulesTable.rows
             };
              
             console.debug("AlertRulesComponent::setCurrentPage  paging", paging +" page ", n);
             this.rulesTable.paginate(paging);
        }
        //this.rulesTable.sortField = "cob_date";
        //this.rulesTable.sortOrder = -1;  
    }
	
	onRowDblclick(event) {
		console.debug('AlertRulesComponent::onRowDblclick ', event.data.exceptionRuleId);
	    this.router.navigate( ['alerts/rule-item', event.data.exceptionRuleId] );
	}
	
	onAddNewAlertDialog() {
		console.debug('AlertRulesComponent::onAddNewAlertDialog');
        this.router.navigate( ['alerts/rule-item', 'new'] );
	}

	ngOnDestroy(){
        console.debug('AlertRulesComponent::ngOnDestory: ');
        this.rulesSubscription.unsubscribe();
    }
	
	clearSearch() {
		console.debug('AlertRulesComponent::clearSearch');
		this.searchText = "";
		this.onSearchTextChange();
	}
}
