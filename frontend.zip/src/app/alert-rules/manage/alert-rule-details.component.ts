import { AlertSummaryService } from './../../alert-summary/alert-summary.service';
// Framework
import {Component, ElementRef, OnInit, Input } from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {Observable} from 'rxjs/Observable';

// Application Component
import {Alert} from '../../models/alert';
import {AlertRule} from '../../models/alert-rule';
import {HttpErrorHandler} from "../../services/http-error-handler";
import {AlertRuleEditService} from "./alert-rule-edit.service";

//Application Shared
import {SelectItem} from '../../common/api';

import * as toastr from 'toastr';

@Component( {
    selector: 'cba-alert-rule-details',
    templateUrl: './alert-rule-details.component.html',
    providers: [HttpErrorHandler]
})
export class AlertRuleDetailsComponent implements OnInit {

    historyTableCols: any[] = [];
    alertTableCols: any[] = [];
    historyColumnOptions: SelectItem[] = [];
    totalPages: number;
    totalRecords: number = 0;
    page: number;

    id: number;
    alerts: Array<Alert> = [];
    @Input() historyList: Array<AlertRule>;

    constructor( private router: Router,
        private errorHandler: HttpErrorHandler,
        private route: ActivatedRoute,
        private alertRuleEditService: AlertRuleEditService,
        private alertSummaryService:AlertSummaryService ) {

        console.debug( 'AlertRuleDetailsComponent::constructor: ');
        
        this.historyTableCols = [
            { header: 'Version', field: 'version_id', style:{ 'width': '5%','text-align':'center'} },
            { header: 'Priority', field: 'exceptionPriorityName', style:{'width': '5%', 'text-align':'left'} },
            { header: 'Fund', field: 'fundName', style:{ 'width': '10%','text-align':'left'} },
            { header: 'Region', field: 'regionName', style:{'width': '4%', 'text-align':'left'} },
            { header: 'Aggr Level', field: 'aggregation_level_name', style:{'width': '6%', 'text-align':'left'} },
            { header: 'Data Type', field: 'exceptionRuleDataTypeName', style:{'width': '10%', 'text-align':'left'} },
            { header: 'Time Period', field: 'exceptionRuleTimePeriodName', style:{'width': '7%', 'text-align':'left'} },
            { header: 'Threshold Value', field: 'threshold_dollar_mask', style:{'width': '7%', 'text-align':'right'} },
            { header: 'Threshold %', field: 'threshold_percent', style:{'width': '7%', 'text-align':'right'} },
            { header: 'Status', field: 'exceptionStatusName', style:{'width': '4%', 'text-align':'left'} },
            { header: 'Comments', field: 'exceptionComments', style:{'width': '10%', 'text-align':'left'} },
            { header: 'Alert Rule Owner', field: 'ruleOwnerName', style:{'width': '12%', 'text-align':'left'} },
            { header: 'Updated By', field: 'updatedBy', style:{'width': '9%', 'text-align':'left'} },
            { header: 'Update Time', field: 'create_time', style:{'width': '8%', 'text-align':'left'} }
        ];


        this.alertTableCols = [
            { header: 'Alert #', field: 'exception_id', style:{ 'width': '3%','text-align':'left'}, sortable:true},
            { header: 'Rule Version', field: 'version_id', style:{'width': '3%','text-align':'center'}, sortable:true},
            { header: 'COB Date', field: 'cob_date', style:{ 'width': '6%','text-align':'left'}, sortable:true},
            { header: 'Client', field: 'client_fund', style:{'width': '10%','text-align':'left'}, sortable:true},
            { header: 'Age', field: 'age', style:{'width': '3%','text-align':'center'}, sortable:true},
            { header: 'COB Value', field: 'first_value', style:{'width': '6%','text-align':'right'}, sortable:false},
            { header: 'Prev Value', field: 'second_value', style:{'width': '6%', 'text-align':'right'}, sortable:false},
            { header: 'Change', field: 'delta', style:{'width': '7%','text-align':'right'}, sortable:false},
            { header: '% Change', field: 'delta_percent', style:{ 'width': '4%','text-align':'right'}, sortable:true}

        ];

        this.historyColumnOptions = [];
        for ( let i = 0; i < this.historyTableCols.length; i++ ) {
            this.historyColumnOptions.push( { label: this.historyTableCols[i].header, value: this.historyTableCols[i] });
        }
    }

    ngOnInit() {
        console.debug( 'AlertRuleDetailsComponent::ngOnInit: ');
        if ( this.route.snapshot && this.route.snapshot.params['id'] ) {
            this.id = this.route.snapshot.params['id'];

            this.alertRuleEditService.getAlerts( this.id ).subscribe(
                alerts => {
                this.alerts = alerts;
                }, e => {
        			toastr.error('Error while getting alerts. Please try again or contact AQUA RACE support', 'Error');
        			this.errorHandler.handle(e);
        		});

        }
    }

    tabClick( index ) {
        console.debug( 'AlertRuleDetailsComponent::tabClick: ', index + '' );
    }

    onRowDblclick(event) {
        console.debug("AlertRuleDetailsComponent::onRowDblclick: ",event, event.data.exception_id);
        this.router.navigate(['alerts/summary/alert-item', event.data.exception_id]);
    }

}

