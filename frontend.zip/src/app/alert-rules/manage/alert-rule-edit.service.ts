// Framework
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Response} from '@angular/http';
import "../../common/rxjs-operators";
import * as _ from 'underscore';

// Application
import {JsonHttp} from "../../services/json-http";
import {HttpErrorHandler} from "../../services/http-error-handler";
import { SelectItem } from "../../common/api";

import {Alert} from '../../models/alert';
import {AlertRule} from '../../models/alert-rule';
import {ExceptionMaster} from '../../models/exception-master';
import {DropDownModel} from '../../models/dropdown-model';
import {APIResponse} from '../../models/api-response';
import {ExceptionUser} from '../../models/exception-user';

// Service END Point URL should be declared as SERVICE END POINT
const clientListURI: string = "/api/exceptionrule/clientslist.json";
const fundListURI = '/api/exceptionrule/getfunds/';
const legalEntitiesListURI: string = '/api/exceptionrule/getlegalentities/';
const regionListURI: string = '/api/exceptionrule/getregions/';
const meansureListURI: string = '/api/exceptionrule/getmeasures/';
const mastersURI: string = '/api/exceptionrule/getmasters/';

const addRuleURI: string = '/api/exceptionrule/add';
const getRuleURI: string = '/api/exceptionrule/get/';
const updateRuleURI: string = '/api/exceptionrule/update';

const getAlertsURI: string = '/api/exceptionrule/getAlerts/';
const userListURI: string = '/api/exceptionrule/getUsersOnExceptionType/';

@Injectable()
export class AlertRuleEditService {

    private clientsObservable:Observable<SelectItem[]>;
    private meansuresObservable:Observable<DropDownModel[]>;
    private mastersObservable:Observable<ExceptionMaster[]>;
    
    constructor( private http: JsonHttp,
        private errorHandler: HttpErrorHandler ) {
        console.debug( "AlertRuleEditService::constructor");
    }

    getClients(): Observable<SelectItem[]> {
        console.debug( "AlertRuleEditService::getClients " + clientListURI );
        if(this.clientsObservable == null){
            this.clientsObservable = this.http.get( clientListURI )
            .map(this.extractDropDownData)
            .publishReplay( 1 )
            .refCount();
        }
        return this.clientsObservable;
    }
    
    getFunds(client:string): Observable<SelectItem[]> {
        console.debug( "AlertRuleEditService::getFunds " + clientListURI );
        return this.http.get( fundListURI + client )
         .map(this.extractDropDownData)    
        //.map( res => res.json() )   // both result and error responsens are handled by Observable

    }
    
    getLegalEntities(client:string, fund:string): Observable<SelectItem[]> {
        console.debug( "AlertRuleEditService::getLegalEntities ", client, fund);
        return this.http.get( legalEntitiesListURI + client + '/' + fund)
         .map(this.extractDropDownData)    
        //.map( res => res.json() )   // both result and error responsens are handled by Observable
    }
    
    getRegions(client:string, fund:string, entity:string): Observable<SelectItem[]> {
        console.debug( "AlertRuleEditService::getRegions ", client, fund, entity);
        return this.http.get( regionListURI + client + '/'+ fund + '/' + entity)
         .map(this.extractDropDownData)
        //.map( res => res.json() )   // both result and error responsens are handled by Observable

    }
    
    extractDropDownData(res: Response) {
        console.time( "AlertRuleEditService::extractDropDownData ");
        let response = res.json();
        var sortedData = _.sortBy(response, function (item) {
            return (item as any).text;
        });
        var data =   _.map(sortedData, function(item) {
            return {
                "value": (item as any).value,
                "label": (item as any).text
            };
        });
        console.timeEnd( "AlertRuleEditService::extractDropDownData ");
        return data;
    }
    
    getMeasures(): Observable<DropDownModel[]> {
        console.debug( "AlertRuleEditService::getMeasures ");
        if(this.meansuresObservable == null){
            this.meansuresObservable = this.http.get( meansureListURI)
            .map( res => res.json() )
            .publishReplay( 1 )
            .refCount();
        }
        return this.meansuresObservable;
    }
    
    getMasters(): Observable<ExceptionMaster[]> {
        console.debug( "AlertRuleEditService::getMasters ");
        if(this.mastersObservable == null){
            this.mastersObservable = this.http.get( mastersURI)
            .map( res => res.json() )
            .publishReplay( 1 )
            .refCount();
        }
        return this.mastersObservable;
    }
    
    addExceptionRule(exceptionmodel:AlertRule): Observable<APIResponse> {
        console.debug( "AlertRuleEditService::addExceptionRule ", exceptionmodel);
        return this.http.post(addRuleURI, exceptionmodel)
            .map( res => res.json() )   // both result and error responsens are handled by Observable

    }
    
    getExceptionRule(id:string): Observable<AlertRule[]> {
        console.debug( "AlertRuleEditService::getExceptionRule ",id);
        return this.http.get( getRuleURI +id)
            .map( res => res.json() )   // both result and error responsens are handled by Observable

    }
    
    // can be replace with alert summary service call
    
    getAlerts(id:number): Observable<Alert[]> {
        console.debug( "AlertRuleEditService::getAlerts ", id);
        return this.http.get( getAlertsURI +id)
            .map( res => res.json() )   // both result and error responsens are handled by Observable

    }
    
    updateExceptionRule(exceptionmodel:AlertRule): Observable<APIResponse> {
        console.debug( "AlertRuleEditService::getAlerts ", exceptionmodel);
        return this.http.put( updateRuleURI, exceptionmodel)
            .map( res => res.json() )   // both result and error responsens are handled by Observable

    }
    
    getAllUsers(exceptionRuleType:string, client:string, region:string): Observable<ExceptionUser[]> {
        console.debug( "AlertRuleEditService::getAlerts ", exceptionRuleType, client, region);
        return this.http.get( userListURI + exceptionRuleType+'/'+client+'/'+region)
            .map( res => res.json() )   // both result and error responsens are handled by Observable
    };
    
    getSecurityAtrributs( key ) {
        console.debug( "AlertRuleEditService::getSecurityAtrributs ");
        var label = "";
        switch ( key ) {
            case "country_of_risk_grouping":
                label = "Country Of Risk Grouping";
                break;
            case "product_grouping":
                label = "Product Grouping";
                break;
            case "sector":
                label = "Sector";
                break;
            case "marketcap":
                label = "Market Cap";
                break;
        }
        return label;
    };

    getColor( data ) {
        console.debug( "AlertRuleEditService::getColor ");
        if ( data )
            return {
                backgroundColor: '#FFFF99'
            }
    };
    
}
