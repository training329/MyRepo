import {inject, TestBed} from "@angular/core/testing";
import {ResponseOptions, Response, RequestMethod, HttpModule} from "@angular/http";
import {MockBackend} from "@angular/http/testing";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../../testing";

import {HttpErrorHandler} from "../../services/http-error-handler";
import {AlertRuleEditService} from "./alert-rule-edit.service";
import {MockAppStateService, MockHttpErrorHandler} from '../../testing/mock.services';


//Service END Point URL should be declared as SERVICE END POINT
const clientListURI: string = "/api/exceptionrule/clientslist.json";
const fundListURI = '/api/exceptionrule/getfunds/';
const legalEntitiesListURI: string = '/api/exceptionrule/getlegalentities/';
const regionListURI: string = '/api/exceptionrule/getregions/';
const meansureListURI: string = '/api/exceptionrule/getmeasures/';
const mastersURI: string = '/api/exceptionrule/getmasters/';

const addRuleURI: string = '/api/exceptionrule/add';
const getRuleURI: string = '/api/exceptionrule/get/';
const updateRuleURI: string = '/api/exceptionrule/update';

const getAlertsURI: string = '/api/exceptionrule/getAlerts/';
const userListURI: string = '/api/exceptionrule/getUsersOnExceptionType/';

const updateAlertURI = '/api/exceptionsummary/update';

let client: string = "999999";
let fund: string = "9999999999";
let entity: string = "26";
let region: string = "2";
let exceptionRuleType: string = "2";
let ruleId: number = 761;

//Service Mock response copied from current real service
const mastersMetaMockResponse =[{ "value": "1", "text": "Client Specific", "type": "rule_type" },
                                { "value": "1", "text": "Current COB Date Vs Prior COB Date", "type": "rule_period" },
                                { "value": "2", "text": "Global (All Client)", "type": "rule_type" },
                                { "value": "1", "text": "High", "type": "priority_type" },
                                { "value": "2", "text": "Medium", "type": "priority_type" },
                                { "value": "3", "text": "Low", "type": "priority_type" },
                                { "value": "3", "text": "Regional (All Regional Client)", "type": "rule_type" },
                                { "value": "4", "text": ">=", "type": "rule_limits" },
                                { "value": "5", "text": ">", "type": "rule_limits" },
                                { "value": "1", "text": "Active", "type": "rule_status_type" },
                                { "value": "0", "text": "Inactive ", "type": "rule_status_type" },
                                { "value": "1", "text": "$", "type": "threshold_type" },
                                { "value": "2", "text": "%", "type": "threshold_type" },
                                { "value": "5", "text": "Current COB Date Vs Prior 30 Day Running Average", "type": "rule_period" },
                                { "value": "1", "text": "Open", "type": "exception_status" },
                                { "value": "3", "text": "Resolved", "type": "exception_status" },
                                { "value": "2", "text": "Under Review", "type": "exception_status" },
                                { "value": "1", "text": "Client", "type": "aggr_level" },
                                { "value": "2", "text": "Fund", "type": "aggr_level" },
                                { "value": "6", "text": "Current COB Date Vs Prior Month Average", "type": "rule_period" },
                                { "value": "7", "text": "Current COB Date Vs Prior Year Average", "type": "rule_period" },
                                { "value": "0", "text": "Fail", "type": "bulk_status_type" },
                                { "value": "1", "text": "Success", "type": "bulk_status_type" },
                                { "value": "2", "text": "No Coverage", "type": "bulk_status_type" },
                                { "value": "3", "text": "Alert updated by another user", "type": "bulk_status_type" },
                                { "value": "4", "text": "Not Processed", "type": "bulk_status_type" },
                                { "value": "4", "text": "Entity (All Entity Client)", "type": "rule_type" }];

const measuresMetaMockResponse =   [{ "value": "1", "text": "Change in Balance Sheet" },
                                    { "value": "2", "text": "Change in Total Equity" },
                                    { "value": "3", "text": "Change in Total Financing" },
                                    { "value": "4", "text": "Change in Net Equity" },
                                    { "value": "6", "text": "Change in Short Financing" },
                                    { "value": "7", "text": "Change in Debit Financing" },
                                    { "value": "9", "text": "Change in GMV By Security Country of Risk Grouping" },
                                    { "value": "10", "text": "Change in GMV By Security Product Grouping" },
                                    { "value": "11", "text": "Change in GMV By Security Sector Grouping" },
                                    { "value": "12", "text": "Change in GMV By Security Market Cap" },
                                    { "value": "13", "text": "Change in Gross ROA" },
                                    { "value": "14", "text": "Change in GMV" },
                                    { "value": "15", "text": "Change in Total Revenue" }];

const clientslistMockResponse =[{ "value": "155058", "text": "ZAZOVE" },
                                { "value": "178173", "text": "LNG" },
                                { "value": "115834", "text": "JP MORGAN INVESTMENT MGMT" },
                                { "value": "259263", "text": "FOLGER HILL" },
                                { "value": "201286", "text": "SINOPAC AM" },
                                { "value": "173713", "text": "SMITH" }];


const getexceptionrule =   [{ "rule_group_id": "2326", "total_open_alerts": 0, "today_open_alerts": 0, "create_time": "2017-02-07 07:36:44", "version_id": "4", "ruleOwner": "498", "ruleOwnerName": "Talwelkar, Kunal (kt54248)", "threshold_dollar": 1000, "threshold_dollar_mask": "1,000", "aggregation_level": "1", "aggregation_level_name": "Client", "createdBy": null, "threshold_percent": 10, "updatedBy": "Kherde, Milind", "client": "999999", "fund": "9999999999", "exceptionRuleType": "2", "exceptionPriority": "3", "legalEntity": "26", "exceptionRuleTimePeriod": "7", "exceptionRuleDataType": "6", "region": "1", "exceptionRuleId": 761, "exceptionRuleTypeName": "Global (All Client)", "exceptionPriorityName": "Low", "legalEntityName": "ALL", "regionName": "GLOBAL", "clientName": "ALL", "fundName": "ALL", "exceptionRuleDataTypeName": "Change in Short Financing", "exceptionRuleTimePeriodName": "Vs Prior Year AVG", "exceptionRuleLimitType": null, "exceptionRuleLimitTypeName": null, "exceptionRuleThresholdType": null, "exceptionRuleThresholdTypeName": null, "exceptionRuleLimits": null, "exceptionStatus": "0", "exceptionStatusName": "Inactive ", "exceptionComments": "" },
                            { "rule_group_id": "2326", "total_open_alerts": 0, "today_open_alerts": 0, "create_time": "2017-02-03 05:07:01", "version_id": "3", "ruleOwner": "498", "ruleOwnerName": "Talwelkar, Kunal (kt54248)", "threshold_dollar": 1000, "threshold_dollar_mask": "1,000", "aggregation_level": "1", "aggregation_level_name": "Client", "createdBy": null, "threshold_percent": 10, "updatedBy": "Nimbalkar, Viraj Ashokrao", "client": "999999", "fund": "9999999999", "exceptionRuleType": "2", "exceptionPriority": "3", "legalEntity": "26", "exceptionRuleTimePeriod": "7", "exceptionRuleDataType": "6", "region": "1", "exceptionRuleId": 753, "exceptionRuleTypeName": "Global (All Client)", "exceptionPriorityName": "Low", "legalEntityName": "ALL", "regionName": "GLOBAL", "clientName": "ALL", "fundName": "ALL", "exceptionRuleDataTypeName": "Change in Short Financing", "exceptionRuleTimePeriodName": "Vs Prior Year AVG", "exceptionRuleLimitType": null, "exceptionRuleLimitTypeName": null, "exceptionRuleThresholdType": null, "exceptionRuleThresholdTypeName": null, "exceptionRuleLimits": null, "exceptionStatus": "0", "exceptionStatusName": "Inactive ", "exceptionComments": "0 removed" },
                            { "rule_group_id": "2326", "total_open_alerts": 0, "today_open_alerts": 0, "create_time": "2017-02-03 05:06:36", "version_id": "2", "ruleOwner": "498", "ruleOwnerName": "Talwelkar, Kunal (kt54248)", "threshold_dollar": 10000, "threshold_dollar_mask": "10,000", "aggregation_level": "1", "aggregation_level_name": "Client", "createdBy": null, "threshold_percent": 10, "updatedBy": "Nimbalkar, Viraj Ashokrao", "client": "999999", "fund": "9999999999", "exceptionRuleType": "2", "exceptionPriority": "3", "legalEntity": "26", "exceptionRuleTimePeriod": "7", "exceptionRuleDataType": "6", "region": "1", "exceptionRuleId": 752, "exceptionRuleTypeName": "Global (All Client)", "exceptionPriorityName": "Low", "legalEntityName": "ALL", "regionName": "GLOBAL", "clientName": "ALL", "fundName": "ALL", "exceptionRuleDataTypeName": "Change in Short Financing", "exceptionRuleTimePeriodName": "Vs Prior Year AVG", "exceptionRuleLimitType": null, "exceptionRuleLimitTypeName": null, "exceptionRuleThresholdType": null, "exceptionRuleThresholdTypeName": null, "exceptionRuleLimits": null, "exceptionStatus": "0", "exceptionStatusName": "Inactive ", "exceptionComments": "0 added" },
                            { "rule_group_id": "2326", "total_open_alerts": 0, "today_open_alerts": 0, "create_time": "2016-07-27 07:12:09", "version_id": "1", "ruleOwner": "498", "ruleOwnerName": "Talwelkar, Kunal (kt54248)", "threshold_dollar": 1000, "threshold_dollar_mask": "1,000", "aggregation_level": "1", "aggregation_level_name": "Client", "createdBy": null, "threshold_percent": 10, "updatedBy": "Talwelkar, Kunal", "client": "999999", "fund": "9999999999", "exceptionRuleType": "2", "exceptionPriority": "3", "legalEntity": "26", "exceptionRuleTimePeriod": "7", "exceptionRuleDataType": "6", "region": "1", "exceptionRuleId": 580, "exceptionRuleTypeName": "Global (All Client)", "exceptionPriorityName": "Low", "legalEntityName": "ALL", "regionName": "GLOBAL", "clientName": "ALL", "fundName": "ALL", "exceptionRuleDataTypeName": "Change in Short Financing", "exceptionRuleTimePeriodName": "Vs Prior Year AVG", "exceptionRuleLimitType": null, "exceptionRuleLimitTypeName": null, "exceptionRuleThresholdType": null, "exceptionRuleThresholdTypeName": null, "exceptionRuleLimits": null, "exceptionStatus": "0", "exceptionStatusName": "Inactive ", "exceptionComments": "test" }];

const getUsersOnExceptionType = [{ "groupId": 461, "soeid": "ig55749", "gpName": "Gritsayuk, Igor (ig55749)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 467, "soeid": "mk35063", "gpName": "Kherde, Milind (mk35063)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 475, "soeid": "sl98093", "gpName": "Ligade, Shivaprasad Audumbar (sl98093)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 477, "soeid": "jm27909", "gpName": "Mascarenhas, Justin (jm27909)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 488, "soeid": "pr81190", "gpName": "Ramtirthkar, Parag (pr81190)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 489, "soeid": "ar98440", "gpName": "Rastogi, Aditya (ar98440)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 491, "soeid": "vs54390", "gpName": "Sakhare, Vipin (vs54390)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 492, "soeid": "ms55678", "gpName": "Salmani, Mohammed (ms55678)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 494, "soeid": "ms75707", "gpName": "Seedorf, Matthew (ms75707)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 496, "soeid": "ns60276", "gpName": "Shapka, Nikolay (ns60276)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 498, "soeid": "kt54248", "gpName": "Talwelkar, Kunal (kt54248)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 513, "soeid": "ad90248", "gpName": "Dhariwal, Amit (ad90248)", "region": "Global", "gpType": "Admin", "primary": false },
                                { "groupId": 514, "soeid": "vn06956", "gpName": "Nimbalkar, Viraj Ashokrao (vn06956)", "region": "Global", "gpType": "Admin", "primary": false }];

const getfundsMockResponse = [{ "value": "9999999999", "text": "ALL" }];
const getlegalentitiesMockResponse = [{ "value": "22", "text": "CEI" },
                                    { "value": "23", "text": "CBNA      " },
                                    { "value": "24", "text": "CBCA" },
                                    { "value": "25", "text": "BNMX" },
                                    { "value": "26", "text": "ALL" },
                                    { "value": "10", "text": "CGMM" },
                                    { "value": "11", "text": "CGML" },
                                    { "value": "12", "text": "CGMJ" },
                                    { "value": "13", "text": "CGMIPL" },
                                    { "value": "14", "text": "CGMI" },
                                    { "value": "15", "text": "CGMHK" },
                                    { "value": "16", "text": "CGMD" }];
const getregionsMockResponse = [{ "value": "1", "text": "GLOBAL" },
                                { "value": "2", "text": "NAM" },
                                { "value": "3", "text": "APAC" },
                                { "value": "4", "text": "EMEA" }];

const getAlerts = [{ "rule_id": "753", "rule_group_id": "2326", "exception_activity_id": null, "exception_id": 258535, "version_id": "3", "type": "Global (All Client)", "priority": "Low", "priority_id": null, "legal_entity": "ALL", "client": "STEADFAST", "region": "GLOBAL", "fund": "ALL", "country": "country", "product": "product", "rule_period": "Vs Prior Year AVG", "aggregation_level": "Client", "aggregation_level_name": null, "description": "0 removed", "measure": "Short Fin Bal", "limit_type": null, "limit": "1.0k & 10%", "is_active": null, "threshold_type": null, "create_user": "VN06956", "create_time": "02-06-2017", "cob_date": "2017-02-03 00:00:00.0", "open_date": "02-06-2017", "status": "1", "status_name": null, "age": 4, "comment": null, "file_name": null, "attachements": null, "exception_owner": "383", "updatedby": null, "first_date": "02-03-2017", "first_value": "958.6m", "second_date": "12-30-2016", "second_value": "1107.5m", "delta": "-148.8m", "delta_percent": "16", "exception_owner_name": "383", "client_fund": "STEADFAST", "is_security": false, "clientTier": null, "is_primary": false, "is_clientgroup": false, "nam": null, "emea": null, "apac": null, "nam_aqua": null, "emea_aqua": null, "apac_aqua": null },
                   { "rule_id": "753", "rule_group_id": "2326", "exception_activity_id": null, "exception_id": 258536, "version_id": "3", "type": "Global (All Client)", "priority": "Low", "priority_id": null, "legal_entity": "ALL", "client": "AVENUE CAPITAL GROUP", "region": "GLOBAL", "fund": "ALL", "country": "country", "product": "product", "rule_period": "Vs Prior Year AVG", "aggregation_level": "Client", "aggregation_level_name": null, "description": "0 removed", "measure": "Short Fin Bal", "limit_type": null, "limit": "1.0k & 10%", "is_active": null, "threshold_type": null, "create_user": "VN06956", "create_time": "02-06-2017", "cob_date": "2017-02-03 00:00:00.0", "open_date": "02-06-2017", "status": "1", "status_name": null, "age": 4, "comment": null, "file_name": null, "attachements": null, "exception_owner": "36", "updatedby": null, "first_date": "02-03-2017", "first_value": "9.6m", "second_date": "12-30-2016", "second_value": "8.6m", "delta": "1.0m", "delta_percent": "10", "exception_owner_name": "36", "client_fund": "AVENUE CAPITAL GROUP", "is_security": false, "clientTier": null, "is_primary": false, "is_clientgroup": false, "nam": null, "emea": null, "apac": null, "nam_aqua": null, "emea_aqua": null, "apac_aqua": null }];


describe( 'AlertRuleEditService', () => {

    let alertRuleEditService: AlertRuleEditService;
    let backend: MockBackend;

    let mockResponse;
    let requestURL;
    let requestMethod = RequestMethod.Get;

    beforeEach(() => {
        TestBed.configureTestingModule( {
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                APP_TEST_HTTP_PROVIDERS,
                AlertRuleEditService,
            ],
        });
    });

    /**
     *  We will be using common mock backend observable and pass the request and response data from outside.
     */
    beforeEach( inject( [AlertRuleEditService, MockBackend], ( ..._ ) => {
        [alertRuleEditService, backend] = _;
        backend.connections.subscribe( conn => {
            conn.mockRespond( new Response( new ResponseOptions( {
                body: JSON.stringify( mockResponse ),
            }) ) );
            expect( conn.request.method ).toEqual( requestMethod );
            expect( conn.request.url ).toEqual( requestURL );
        });
    }) );

    describe( '.getMasters', () => {

        describe( 'when masters reference data returned', () => {
            it( 'masters list should be non-empty', () => {
                // set request, response for mock service
                requestURL = mastersURI;
                mockResponse = mastersMetaMockResponse;

                alertRuleEditService.getMasters().subscribe( masters => {
                    expect( masters ).not.toBeUndefined();
                    expect( masters ).not.toBeNull();
                    expect( masters.length ).toEqual( 27 );
                });
            });
        });

        describe( 'when master reference data is not returned', () => {
            it( 'masters list should be empty', () => {
                // set request, response for mock service
                requestURL = mastersURI;
                mockResponse = "";

                alertRuleEditService.getMasters().subscribe( masters => {
                    expect( masters ).toBe( "" );
                });
            });
        });
    });

    describe( '.getMeasures', () => {
        describe( 'when measures reference data returned', () => {
            it( 'measures list should be non-empty', () => {
                // set request, response for mock service
                requestURL = meansureListURI;
                mockResponse = measuresMetaMockResponse;

                alertRuleEditService.getMeasures().subscribe( measures => {
                    expect( measures ).not.toBeUndefined();
                    expect( measures ).not.toBeNull();
                    expect( measures.length ).toEqual( 13 );
                });
            });
        });

        describe( 'when measures reference data not returned', () => {
            it( 'measures list should be empty', () => {
                // set request, response for mock service
                requestURL = meansureListURI;
                mockResponse = "";

                alertRuleEditService.getMeasures().subscribe( measures => {
                    expect( measures ).toBe( "" );
                });
            });
        });
    });

    describe( '.getClients', () => {
        describe( 'when clients are returned', () => {
            it( 'clients list should be non-empty', () => {
                // set request, response for mock service
                requestURL = clientListURI;
                mockResponse = clientslistMockResponse;

                alertRuleEditService.getClients().subscribe( clients => {
                    expect( clients ).not.toBeUndefined();
                    expect( clients ).not.toBeNull();
                    expect( clients.length ).toEqual( 6 );
                });
            });
        });

        describe( 'when clients data not returned', () => {
            it( 'clients list should be empty', () => {
                // set request, response for mock service
                requestURL = clientListURI;
                mockResponse = "";

                alertRuleEditService.getClients().subscribe( clients => {
                    expect( clients.length ).toEqual( 0 );
                });
            });
        });
    });


    describe( '.getFunds', () => {
        describe( 'when funds are returned', () => {
            it( 'funds list should be non-empty', () => {
                // set request, response for mock service
                requestURL = fundListURI + client;
                mockResponse = getfundsMockResponse;

                alertRuleEditService.getFunds( client ).subscribe( funds => {
                    expect( funds ).not.toBeUndefined();
                    expect( funds ).not.toBeNull();
                    expect( funds.length ).toEqual( 1 );
                });
            });
        });

        describe( 'when funds data not returned', () => {
            it( 'funds list should be empty', () => {
                // set request, response for mock service
                requestURL = fundListURI + client;
                mockResponse = "";

                alertRuleEditService.getFunds( client ).subscribe( funds => {
                    expect( funds.length ).toEqual( 0 );
                });
            });
        });
    });

    describe( '.getLegalEntities', () => {
        describe( 'when legal entities are returned', () => {
            it( 'legal entities should be non-empty', () => {
                // set request, response for mock service
                requestURL = legalEntitiesListURI + client + '/' + fund;
                mockResponse = getlegalentitiesMockResponse;

                alertRuleEditService.getLegalEntities( client, fund ).subscribe( legalEntities => {
                    expect( legalEntities ).not.toBeUndefined();
                    expect( legalEntities ).not.toBeNull();
                    expect( legalEntities.length ).toEqual( 12 );
                });
            });
        });

        describe( 'when legal entities data not returned', () => {
            it( 'legal entities should be empty', () => {
                // set request, response for mock service
                requestURL = legalEntitiesListURI + client + '/' + fund;
                mockResponse = "";

                alertRuleEditService.getLegalEntities( client, fund ).subscribe( legalEntities => {
                    expect( legalEntities.length ).toEqual( 0 );
                });
            });
        });
    });

    describe( '.getRegions', () => {
        describe( 'when region are returned', () => {
            it( 'region should be non-empty', () => {
                // set request, response for mock service
                requestURL = regionListURI + client + '/' + fund + '/' + entity;
                mockResponse = getregionsMockResponse;

                alertRuleEditService.getRegions( client, fund, entity ).subscribe( region => {
                    expect( region ).not.toBeUndefined();
                    expect( region ).not.toBeNull();
                    expect( region.length ).toEqual( 4 );
                });
            });
        });

        describe( 'when region data not returned', () => {
            it( 'region should be empty', () => {
                // set request, response for mock service
                requestURL = regionListURI + client + '/' + fund + '/' + entity;
                mockResponse = "";

                alertRuleEditService.getRegions( client, fund, entity ).subscribe( region => {
                    expect( region.length ).toEqual( 0 );
                });
            });
        });
    });

    describe( '.getAlerts', () => {
        describe( 'when open alerts are returned', () => {
            it( 'alerts should be non-empty', () => {
                // set request, response for mock service
                requestURL = getAlertsURI + ruleId;
                mockResponse = getAlerts;

                alertRuleEditService.getAlerts( ruleId ).subscribe( alerts => {
                    expect( alerts ).not.toBeUndefined();
                    expect( alerts ).not.toBeNull();
                    expect( alerts.length ).toEqual( 2 );
                });
            });
        });

        describe( 'when open alerts not returned', () => {
            it( 'alerts should be empty', () => {
                // set request, response for mock service
                requestURL = getAlertsURI + ruleId;
                mockResponse = "";

                alertRuleEditService.getAlerts( ruleId ).subscribe( alerts => {
                    expect( alerts.length ).toEqual( 0 );
                });
            });
        });
    });

    describe( '.getAllUsers', () => {
        describe( 'when users are returned', () => {
            it( 'users should be non-empty', () => {
                // set request, response for mock service
                requestURL = userListURI + exceptionRuleType + '/' + client + '/' + region;
                mockResponse = getUsersOnExceptionType;

                alertRuleEditService.getAllUsers( exceptionRuleType, client, region ).subscribe( users => {
                    expect( users ).not.toBeUndefined();
                    expect( users ).not.toBeNull();
                    expect( users.length ).toEqual( 13 );
                });
            });
        });

        describe( 'when users not returned', () => {
            it( 'users should be empty', () => {
                // set request, response for mock service
                requestURL = userListURI + exceptionRuleType + '/' + client + '/' + region;
                mockResponse = "";

                alertRuleEditService.getAllUsers( exceptionRuleType, client, region ).subscribe( users => {
                    expect( users.length ).toEqual( 0 );
                });
            });
        });
    });


    describe( '.getExceptionRule', () => {
        describe( 'when rules data is returned', () => {
            it( 'rules data should be non-empty', () => {
                // set request, response for mock service
                requestURL = getRuleURI + ruleId;
                mockResponse = getexceptionrule;

                alertRuleEditService.getExceptionRule( ruleId.toString() ).subscribe( rules => {
                    expect( rules ).not.toBeUndefined();
                    expect( rules ).not.toBeNull();
                    expect( rules.length ).toEqual( 4 );
                });
            });
        });

        describe( 'when rules data is not returned', () => {
            it( 'rules data should be empty', () => {
                // set request, response for mock service
                requestURL = getRuleURI + ruleId;
                mockResponse = "";

                alertRuleEditService.getExceptionRule( ruleId.toString() ).subscribe( rules => {
                    expect( rules.length ).toEqual( 0 );
                });
            });
        });
    });

   //TODO: Create the rest of test cases for add and update rule data of AlertRuleEditService
});

