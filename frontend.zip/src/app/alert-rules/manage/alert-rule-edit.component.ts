// Framework
import {Component, ElementRef, SimpleChange, Input, OnDestroy, AfterViewChecked, ViewChild} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {Location}  from '@angular/common';
import {Observable} from 'rxjs/Observable';
import {Subscription} from 'rxjs/Subscription';
import {NgForm, Validators} from '@angular/forms';
import {Message} from 'primeng/primeng';

// Application Component
import {Alert} from '../../models/alert';
import {AlertRule} from '../../models/alert-rule';
import {DropDownModel} from '../../models/dropdown-model';
import {HttpErrorHandler} from "../../services/http-error-handler";
import {ReferenceDataService} from "../../services/reference-data.service";
import {AlertRuleEditService} from "./alert-rule-edit.service";
import {AlertRulesService} from "../alert-rules.service";
import {ExceptionMaster} from '../../models/exception-master';
// import {FlagedSecurityExceptionRule} from '../../models/flaged-security-exception-rule';
import {ExceptionUser} from '../../models/exception-user';
import {LoginService} from "../../services/login.service";

// Application Shared
import {SelectItem} from '../../common/api';
import {NumberFormatPipe} from './../../pipes/number-formatting-pipe';
import {NumberFormatDirective} from './../../directives/number.format.directive';

import * as _ from 'underscore';
import * as toastr from 'toastr';

@Component( {
    selector: 'cba-alert-edit',
    styleUrls: ['./alert-rule-edit.component.scss'],
    templateUrl: './alert-rule-edit.component.html',
    providers: [HttpErrorHandler,NumberFormatPipe]
})
export class AlertRuleEditComponent implements OnDestroy {
	private formChangeSubScription : Subscription;

    id: string;
    showForm = false;
    cobdate: number;

    exceptionmodel: AlertRule = new AlertRule();
    Exceptions: Array<AlertRule> = [];
    legalEntityList: Array<SelectItem> = [];
    clientList: Array<SelectItem> = [];
    fundList: Array<SelectItem> = [];
    historyList: Array<AlertRule> = [];
    regionsList: Array<SelectItem> = [];

    priorityTypes: ExceptionMaster[] = [];
    limits: ExceptionMaster[] = [];
    periods: ExceptionMaster[] = [];
    statusTypes: ExceptionMaster[] = [];
    ruleTypes: ExceptionMaster[] = [];
    thresholdTypes: ExceptionMaster[] = [];
    agg: ExceptionMaster[] = [];
    measures: DropDownModel[];
    oldThresholdDollar = 0;
    oldThresholdpercent = 0;
    result;// = user;//$cookies.getObject('Userinfo');

    oldModel: AlertRule;
    selectedUser: DropDownModel;
    selectedStatus: ExceptionMaster;

    alerts: Array<Alert>;
    users: Array<ExceptionUser>;
    filteredUsers: Array<DropDownModel>;
    // statusTypes: Array<ExceptionMaster>;
    msgs: Message[] = [];
    soeid:string = "";

    threshold1: boolean = false;
    threshold2: boolean = false;
    threshold_percent_old: number;
    threshold_dollar_old: number;

    editMode:boolean = false;
    disabled:boolean = false;
    title:string = " Alert Rule"

    selectedClientId: string = '999999';
    selectedFundId: string = '9999999999';
    selectedRegionId: string = '1';    
    
    orgRuleOwner: any = "";
    defaultSelectionValue: string = '';
    isChange:boolean = false;
    
    // Form 
    // Reset the form with a new hero AND restore 'pristine' class state
    // by toggling 'active' flag which causes the form
    // to be removed/re-added in a tick via NgIf
    // TODO: Workaround until NgForm has a reset method (#6822)
    active = true;
    alertForm: NgForm;
    submitted = false;

	private local_threshold_dollar:string;

    @ViewChild( 'ruleForm' ) currentForm: NgForm;
    // initialization
    constructor( private router: Router,
    		private errorHandler: HttpErrorHandler,
    		private route: ActivatedRoute,
    		private location: Location,
    		private alertRulesService: AlertRulesService,
    		private alertRuleEditService: AlertRuleEditService,
    		private referenceDataService: ReferenceDataService,
    		private loginService:LoginService,
			private _numberFormatPipe:NumberFormatPipe ) {

    	console.debug('AlertRuleEditComponent::constructor');
    	// read router parameter 
    	if(this.route.snapshot && this.route.snapshot.params['id']){
    		this.id = this.route.snapshot.params['id'];
    	}

    	this.soeid = this.loginService.getUserSoeId();
    	
    	this.getMetaData();

    	if(this.id == "new"){
    		this.editMode = false;
    		this.showForm = true;
    		this.title = "New" + this.title;
    	} else{
    		this.editMode = true;
    		this.getRuleData();
    		this.title = "Manage" + this.title;
    	}

    	this.initDropDown();
    }

    getMetaData() {
    	console.debug('AlertRuleEditComponent::getMetaData');
    	this.alertRuleEditService.getMasters().subscribe(
    			masterList => {
    				for ( let master of masterList ) {
    					switch ( master.type ) {
    					case "priority_type":
    						this.priorityTypes.push( master );
    						break;
    					case "rule_limits":
    						this.limits.push( master );
    						break;
    					case "rule_period":
    						this.periods.push( master );
    						break;
    					case "rule_status_type":
    						this.statusTypes.push( master );
    						break;
    					case "rule_type":
    						this.ruleTypes.push( master );
    						break;
    					case "threshold_type":
    						this.thresholdTypes.push( master );
    						break;
    					case "aggr_level":
    						this.agg.push( master );
    						break;
    					}
    				}
    			}, e => {
    				toastr.error('Error while getting masters. Please try again or contact AQUA RACE support', 'Error');
    				this.errorHandler.handle(e);
    			});


    	this.alertRuleEditService.getMeasures().subscribe(
    			measures => {
    				this.measures = measures;
    			}, e => {
    				toastr.error('Error while getting measures. Please try again or contact AQUA RACE support', 'Error');
    				this.errorHandler.handle(e);
    			});

    	this.getClientList();
    }

    getClientList(): void {
    	console.debug('AlertRuleEditComponent::getClientList');
    	this.alertRuleEditService.getClients().subscribe(res => {
    		this.clientList = res;
    		//this.getFundList(this.selectedClientId);
    	}, e => {
			toastr.error('Error while getting clients. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }

    getFundList(clientId): void {
    	console.debug('AlertRuleEditComponent::getFundList ', clientId);
    	if(clientId){
    	    this.alertRuleEditService.getFunds(clientId).subscribe(res => {
                this.fundList = res;
                
                if(!this.editMode && this.exceptionmodel.exceptionRuleType=='1'){
                    this.exceptionmodel.fund = '9999999999';
                    this.getLegalEntityList(clientId, this.exceptionmodel.fund);
                }            
            }, e => {
                toastr.error('Error while getting funds. Please try again or contact AQUA RACE support', 'Error');
                this.errorHandler.handle(e);
            });
    	}
    }

    getLegalEntityList(clientId, fundId): void {
    	console.debug('AlertRuleEditComponent::getLegalEntityList ', clientId, fundId);
    	if(clientId && fundId){
    	    this.alertRuleEditService.getLegalEntities(clientId, fundId).subscribe(res => {
                this.legalEntityList = res;
                if(!this.editMode && this.exceptionmodel.exceptionRuleType=='1'){
                    this.exceptionmodel.legalEntity = "26";
                    this.getRegionList(clientId, fundId, this.exceptionmodel.legalEntity);
                }

            }, e => {
                toastr.error('Error while getting legal entities. Please try again or contact AQUA RACE support', 'Error');
                this.errorHandler.handle(e);
            });
    	}
    }

    getRegionList(client, fund, entity): void {
    	console.debug('AlertRuleEditComponent::getRegionList ', client, fund, entity);
    	if(client && fund && entity){
    	    this.alertRuleEditService.getRegions(client, fund, entity).subscribe(res => {
                this.regionsList = res;

                if( !this.editMode && this.exceptionmodel.exceptionRuleType=='1'){
                    this.exceptionmodel.region = "1";
                }
                
                if(this.exceptionmodel.exceptionRuleType!='') {
                    this.getAllUsers(this.exceptionmodel.exceptionRuleType, client, this.exceptionmodel.region);
                }

            }, e => {
                toastr.error('Error while getting regions. Please try again or contact AQUA RACE support', 'Error');
                this.errorHandler.handle(e);
            });
    	}
    }

    onClientListChange(clientId): void {
    	console.debug('AlertRuleEditComponent::onClientListChange ', clientId);
    	if(this.exceptionmodel.exceptionRuleType=='1'){
    		this.exceptionmodel.fund = '';
    	}

    	this.getFundList(clientId);
    }

    onFundListChange(clientId, fundId): void {
    	console.debug('AlertRuleEditComponent::onFundListChange ', clientId, fundId);
    	if(this.exceptionmodel.exceptionRuleType=='1'){
    		this.exceptionmodel.legalEntity = "";
    	}

    	this.getLegalEntityList(clientId, fundId);
    }

    onLegalEntityListChange(client, fund, entity): void {
    	console.debug('AlertRuleEditComponent::onLegalEntityListChange ', client, fund, entity);
    	if(this.exceptionmodel.exceptionRuleType=='1'){
    		this.exceptionmodel.region = "";
    	}

    	this.getRegionList(client, fund, entity);
    }

    onRegionListChange(clientId, regionId): void {
    	console.debug('AlertRuleEditComponent::onRegionListChange ', clientId, regionId);
        if(this.exceptionmodel.exceptionRuleType!='') {
            this.getAllUsers(this.exceptionmodel.exceptionRuleType, clientId, regionId);
        }
    }

    getRuleData( refresh: boolean = false ) {
    	console.debug('AlertRuleEditComponent::getRuleData ', this.id, refresh);
    	this.alertRuleEditService.getExceptionRule( this.id ).subscribe( data => {
    		if ( data && data.length > 0 ) {

    			let ruleData: AlertRule = _.clone( data[0] );
	    		ruleData.exceptionComments = '';
	    		this.isChange = false;

	    		this.getFundList( ruleData.client );
	    		this.getLegalEntityList( ruleData.client, ruleData.fund );
	    		this.getRegionList( ruleData.client, ruleData.fund, ruleData.legalEntity );
	
	    		if ( ruleData.threshold_dollar ) {
	    			this.threshold_dollar_old = _.clone( ruleData.threshold_dollar );
	    			this.threshold1 = true;
	    			//this.threshold1_old=true;
	    		}
	    		if ( ruleData.threshold_percent ) {
	    			this.threshold_percent_old = _.clone( ruleData.threshold_percent )
	    			this.threshold2 = true;
	    			//this.threshold2_old=true;
	    		}
	    		this.exceptionmodel = _.clone( ruleData );
				this.local_threshold_dollar=this._numberFormatPipe.parse(this.exceptionmodel.threshold_dollar+"",true);
	    		this.historyList = _.clone( data );
	    		this.showForm = true;
	    		this.orgRuleOwner = _.clone(this.exceptionmodel.ruleOwner);
	    		this.oldModel = _.clone( this.exceptionmodel );
	    		
	    		// add form change listener, when form is completely loaded 
                setTimeout(() => {
					this.formChanged();
                }, 1000);
	    	}

    	}, e => {
			toastr.error('Error while getting exception rule. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }

    save( exceptionmodel: AlertRule, isValid: boolean ): void {
    	console.debug('AlertRuleEditComponent::save ', exceptionmodel, isValid);
		 this.exceptionmodel.threshold_dollar= parseInt(this._numberFormatPipe.parse(this.local_threshold_dollar,false));
        if (this.threshold1 == false && this.threshold2 == false) {
                toastr.error('Threshold value is not selected. Please select atleast one', 'Error');
                return;
        } else {
            let isValid:boolean = true;
            if (this.threshold1 == true && (this.exceptionmodel.threshold_dollar == 0 || this.exceptionmodel.threshold_dollar == undefined)) {
                toastr.error('Threshold value should be greater than zero.', 'Error');
                isValid = false; 
            }
        
            if (this.threshold2 == true && (this.exceptionmodel.threshold_percent == 0 || this.exceptionmodel.threshold_percent == undefined)) {
                    toastr.error('Threshold % should be greater than zero.', 'Error');
                    isValid = false;
            }
            if(isValid == false){
                return;
            }
        }        
 	   
        if (!this.editMode) {
        	this.alertRuleEditService.addExceptionRule( this.exceptionmodel )
            .subscribe( apiResponse => {
                console.debug('AlertRuleEditComponent::addExceptionRule'+ apiResponse );
                this.msgs = [];
                if ( apiResponse.status ) {
                    toastr.success('New alert rule added succesfully', 'Success!');
                    this.active = false;
                    this.active = true;
                    this.alertRulesService.clearCache();
                } else {
                    toastr.error(apiResponse.message, 'Error');
                }
                this.goBack()
            }, e => {
                        this.errorHandler.handle( e );
                        toastr.error('Error while adding exception rule. Please try again or contact AQUA RACE support', 'Error');
                    }
            );
        } else {
        	this.alertRuleEditService.updateExceptionRule( this.exceptionmodel )
            .subscribe( apiResponse => {
                console.debug('AlertRuleEditComponent::updateExceptionRule'+ apiResponse );
                this.msgs = [];
                if ( apiResponse.status ) {
                    toastr.success('Alert Rule updated successfully', 'Success!');
                    this.active = false;
                    this.active = true;
                    this.getRuleData( true );
                    this.alertRulesService.clearCache();
                } else {
                    toastr.error(apiResponse.message, 'Error');
                }
            }, e => {
                        this.errorHandler.handle( e );
                        toastr.error('Error while updating Alert rule. Please try again or contact AQUA RACE support', 'Error');
                    }
            );
        }
    }

    onThresholdSelectionChange( val ) {
    	console.debug('AlertRuleEditComponent::onThresholdSelectionChange ', val);
    	if ( val.target.name === 'threshold1' ) {
    		if ( val.target.checked ) {
    			this.exceptionmodel.threshold_dollar = this.threshold_dollar_old;
				this.local_threshold_dollar=this._numberFormatPipe.parse(this.threshold_dollar_old+"",true);
    		} else {
    			this.exceptionmodel.threshold_dollar = 0;
    		}
    	}

    	if ( val.target.name === 'threshold2' ) {
    		if ( val.target.checked ) {
    			this.exceptionmodel.threshold_percent = this.threshold_percent_old;
    		} else {
    			this.exceptionmodel.threshold_percent = 0;
    		}
    	}
    }

    goBack(): void {
    	console.debug('AlertRuleEditComponent::goBack');
    	this.location.back();
    }

    ngOnDestroy() {
    	console.debug('AlertRuleEditComponent::ngOnDestroy');
    	if (this.formChangeSubScription && this.editMode) {
    		this.formChangeSubScription.unsubscribe();
    	}
    }

    formChanged() {
    	console.debug('AlertRuleEditComponent::formChanged');
    	if ( this.currentForm === this.alertForm ) { return; }
    	this.alertForm = this.currentForm;
    	if ( this.alertForm ) {
    		this.formChangeSubScription = this.alertForm.valueChanges
    		.subscribe( data => this.onValueChanged( data ) );
    	}
    }

    onValueChanged( data?: any ) {
    	console.debug('AlertRuleEditComponent::onValueChanged ', data);
    	if (!this.alertForm) { return; }
    	if (this.exceptionmodel && this.oldModel) {
    		if (!_.isEqual(this.exceptionmodel, this.oldModel)) {
    			this.isChange = true;
    		} else {
    			this.isChange = false;
    		}
    	}
    }
    
    getAllUsers = function( exceptionRuleType, client, region ) {
    	console.debug('AlertRuleEditComponent::getAllUsers ', exceptionRuleType, client, region);
        if (exceptionRuleType && exceptionRuleType != '' && exceptionRuleType != this.defaultSelectionValue
        		&& client && client != '' && client != this.defaultSelectionValue
        		&& region && region != '' && region != this.defaultSelectionValue) {
        	this.alertRuleEditService.getAllUsers( exceptionRuleType, client, region ).subscribe(
                users => {
                this.users = users;
                if (!this.editMode){
                	for ( let user of users ) {
                		if (user.soeid == this.soeid) {
                			this.exceptionmodel.ruleOwner = user.groupId + '';
                			this.exceptionmodel.ruleOwnerName = user.gpName;
                			this.isChange = true;
                		}
                	}
                }           	
            }, e => {
    			toastr.error('Error while getting users. Please try again or contact AQUA RACE support', 'Error');
    			this.errorHandler.handle(e);
    		});	
        }
    };

    //events
    onRuleTypeChange( ruleType :number ) {
    	console.debug('AlertRuleEditComponent::onRuleTypeChange ', ruleType);
    	
    	if (!this.editMode) {
    		if (ruleType == 2 || ruleType == 3) {
    			this.exceptionmodel.client = '999999';
    			this.onClientListChange(this.exceptionmodel.client);
    			this.exceptionmodel.fund = '9999999999';
    			this.onFundListChange(this.exceptionmodel.client, this.exceptionmodel.fund);
    			this.exceptionmodel.legalEntity = "26";
    			this.onLegalEntityListChange(this.exceptionmodel.client, this.exceptionmodel.fund, this.exceptionmodel.legalEntity);
    			this.exceptionmodel.aggregation_level = '1';
    				
    			if (ruleType == 2) {
    				this.exceptionmodel.region = "1";
    			}
    		} else if (ruleType == 1) {
    			this.exceptionmodel.client = '';
    			this.exceptionmodel.fund = '';
    			this.exceptionmodel.legalEntity = '';
    			this.exceptionmodel.aggregation_level = '';
    			this.exceptionmodel.region = '';
    		}
    	}
    }

    initDropDown(): void {
    	console.debug('AlertRuleEditComponent::initDropDown');
    	this.exceptionmodel.exceptionRuleType = '';
    	this.exceptionmodel.exceptionPriority = '';
    	this.exceptionmodel.client = '';
    	this.exceptionmodel.fund = '';
    	this.exceptionmodel.legalEntity = '';
    	this.exceptionmodel.region = '';
    	this.exceptionmodel.exceptionRuleDataType = '';
    	this.exceptionmodel.aggregation_level = '';
    	this.exceptionmodel.exceptionRuleTimePeriod = '';
    	this.exceptionmodel.exceptionStatus = '';
    }
    
    onRuleOwnerChange(event) {
    	console.debug('AlertRuleEditComponent::onRuleOwnerChange', event);
    	for ( let user of this.users ) {
    		if (user.groupId == event.userGrpId) {
    			this.exceptionmodel.ruleOwner = user.groupId + '';
    			this.exceptionmodel.ruleOwnerName = user.gpName;
    			break;
    		}
    	}
    	if (this.exceptionmodel && this.oldModel) {
    		if (this.exceptionmodel.ruleOwner != this.oldModel.ruleOwner) {
        		this.isChange = true;
        	} else {
        		this.isChange = false;
        	}
    	}
    }
}

