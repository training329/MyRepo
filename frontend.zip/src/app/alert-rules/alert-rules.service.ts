import {Injectable}from'@angular/core';
import {Http, Response}from'@angular/http';
import {Observable}from'rxjs/Observable';
import {Subscription} from 'rxjs/Subscription';
import {BehaviorSubject} from "rxjs/Rx";

import {JsonHttp} from "../services/json-http";
import {AlertRule}from'../models/alert-rule';
import {HttpErrorHandler} from "../services/http-error-handler";
import {AppStateService} from  "../services/app-state.service";
import {EventBusService} from  "../services/event-bus.service";
import {UtilService} from "../services/util.service";

import "../common/rxjs-operators";
import * as toastr from 'toastr';

//Service END Point URL should be declared as SERVICE END POINT
const serviceURI = '/api/exceptionrule/exceptionrulelist.json';
const exportToExcelURI = '/api/exceptionrule/export/';

@Injectable()
export class AlertRulesService {

	 /**
     * Indicates when service is in process of loading data from backend
     * @type {boolean}
     */
    private isLoadingData:boolean = false;

    /**
     *  Observable to subscribe to receive data loaded notification
     *  Check implementation details here: https://github.com/ReactiveX/rxjs/blob/master/doc/subject.md
     *  Idea is to use the Subject to communicate completion of data retrieval process in service
     * @type {BehaviorSubject}
     */
    private dataIsReady:BehaviorSubject<boolean> = new BehaviorSubject(false);
    
	private ruleData: AlertRule[];
	
	private rulesDataObservable:Observable<AlertRule[]>;
	private rulesSubscription:Subscription;

    constructor(private http: JsonHttp, 
                private errorHandler: HttpErrorHandler, 
                private eventBusService:EventBusService,
                private appStateService:AppStateService,
                private utilService:UtilService) { 
        console.debug( "AlertRulesService::constructor ");
        
        this.eventBusService.listen('ClearCacheOnUserUpdate').subscribe((customEvent)=>{
            console.log('AlertRulesService::eventBusService.listen: ClearCacheOnUserUpdate event');
            this.clearCache(); 
        });
    }

    loadData(): Observable<boolean> {
        console.debug( "AlertRulesService::loadData ");
        
        // fire up the request to backend service
        // mark loading by service. Note: it will become false once table produced from response
        this.isLoadingData = true;
        this.dataIsReady.next(false);
        
        this.rulesDataObservable = this.http.get(serviceURI)
	        .map(res => res.json())   // both result and error responsens are handled by Observable
	        .publishLast() // required to prevent multiple requests
	        .refCount()
	        .catch((error:any) => Observable.throw(error.json().error || 'Server error'))
	        .finally(()=> {
	            console.timeEnd("AlertRulesService::loadData GET:" + serviceURI)
	        });

	    // subscribe to HTTP Get Observable
	    this.rulesSubscription = this.rulesDataObservable.subscribe(
	        data => {
	            this.isLoadingData = false;
	            this.loadRules(data);
	            // notify calling service subscribers
	            this.dataIsReady.next(true);
	        },
	        err => {  // Log errors if any
	        	toastr.error('Error while getting rules data. Please try again or contact AQUA RACE support', 'Error');
				this.errorHandler.handle(err);
	            this.isLoadingData = false;
	            // notify calling service subscribers
	            this.dataIsReady.next(true);
	        },
	        () => console.debug("AlertRulesService::loadData GET unsubscribe")
	    );
	    
	    // return Observable to calling component to notify when data is ready to be requested directly
	    return this.dataIsReady.asObservable();
    }
    
    getDataNotification() : Observable<boolean> {
        if(this.rulesDataObservable == null){
            this.loadData()
        }
        return this.dataIsReady.asObservable();
    }
    
    loadRules(data:AlertRule[]):void {
        console.debug("AlertRulesService::loadAlerts ", data);
        if (data && data.length > 0) {
            console.time("AlertRulesService::loadAlerts");
            this.ruleData = data;
            console.timeEnd("AlertRulesService::loadRules");
        }
    }

    getRules():AlertRule[] {
        return this.ruleData;
    }
    
    clearCache(): void {
        console.debug( "AlertRulesService::clearCache");
        if(this.rulesSubscription)
            this.rulesSubscription.unsubscribe();
        this.rulesDataObservable = null;
        this.ruleData = null;
    }
    
    exportToExcel(searchText) {
		console.debug('AlertRulesService::exportToExcel ', searchText);
		var url = exportToExcelURI;
	    if (searchText && searchText != "") {
	    	url = url + searchText;
	    }
		this.utilService.exportToExcel(url);
	}
}
