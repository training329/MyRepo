import {inject, TestBed} from "@angular/core/testing";
import {
    ResponseOptions,
    Response,
    RequestMethod,
    HttpModule
} from "@angular/http";
import {MockBackend} from "@angular/http/testing";
import {AlertRule}from'../models/alert-rule';
import {AlertRulesService} from "./alert-rules.service";
import {AppStateService} from "../services/app-state.service";
import {HttpErrorHandler} from "../services/http-error-handler";
import {UtilService} from "../services/util.service";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../testing";

import {MockAppStateService, MockHttpErrorHandler, MockUtilService} from '../testing/mock.services';

//Service END Point URL should be declared as SERVICE END POINT
const serviceURI = '/api/exceptionrule/exceptionrulelist.json';

//Service Mock response copied from current real service 
const serviceMockResponse = [{ "rule_group_id": "2331", "total_open_alerts": 4599, "today_open_alerts": 0, "create_time": "2017-02-06 02:46:39.783", "version_id": "2", "ruleOwner": null, "ruleOwnerName": "Kherde, Milind (mk35063)", "threshold_dollar": 0, "threshold_dollar_mask": null, "aggregation_level": "Client", "aggregation_level_name": null, "createdBy": null, "threshold_percent": 0, "region": "GLOBAL", "client": "ALL", "fund": "ALL", "exceptionRuleId": 758, "exceptionRuleType": "Global (All Client)", "exceptionRuleTypeName": null, "exceptionPriority": "Medium", "exceptionPriorityName": null, "legalEntity": "ALL", "legalEntityName": null, "regionName": null, "clientName": null, "fundName": null, "exceptionRuleDataType": "GMV(Security Sector)", "exceptionRuleDataTypeName": null, "exceptionRuleTimePeriod": "Vs Prior Month AVG", "exceptionRuleTimePeriodName": null, "exceptionRuleLimitType": null, "exceptionRuleLimitTypeName": null, "exceptionRuleThresholdType": null, "exceptionRuleThresholdTypeName": null, "exceptionRuleLimits": "0.6m", "exceptionStatus": "Inactive ", "exceptionStatusName": null, "exceptionComments": "", "updatedBy": "Nimbalkar, Viraj Ashokrao" }, { "rule_group_id": "2326", "total_open_alerts": 3622, "today_open_alerts": 107, "create_time": "2017-02-03 05:07:01.073", "version_id": "3", "ruleOwner": null, "ruleOwnerName": "Talwelkar, Kunal (kt54248)", "threshold_dollar": 0, "threshold_dollar_mask": null, "aggregation_level": "Client", "aggregation_level_name": null, "createdBy": null, "threshold_percent": 0, "region": "GLOBAL", "client": "ALL", "fund": "ALL", "exceptionRuleId": 753, "exceptionRuleType": "Global (All Client)", "exceptionRuleTypeName": null, "exceptionPriority": "Low", "exceptionPriorityName": null, "legalEntity": "ALL", "legalEntityName": null, "regionName": null, "clientName": null, "fundName": null, "exceptionRuleDataType": "Short Fin Bal", "exceptionRuleDataTypeName": null, "exceptionRuleTimePeriod": "Vs Prior Year AVG", "exceptionRuleTimePeriodName": null, "exceptionRuleLimitType": null, "exceptionRuleLimitTypeName": null, "exceptionRuleThresholdType": null, "exceptionRuleThresholdTypeName": null, "exceptionRuleLimits": "1.0k & 10%", "exceptionStatus": "Active", "exceptionStatusName": null, "exceptionComments": "0 removed", "updatedBy": "Nimbalkar, Viraj Ashokrao" }]

describe( 'AlertRulesService', () => {

    let alertRulesService: AlertRulesService;
    let backend: MockBackend;
    let appState: AppStateService;
	let utilService: UtilService;

    beforeEach(() => {
        TestBed.configureTestingModule( {
            imports: [
                HttpModule
            ],
            providers: [
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                {
                	provide: UtilService,
                    useClass: MockUtilService,
                },
                APP_TEST_HTTP_PROVIDERS,
                AlertRulesService,
            ],
        });
    });

    beforeEach( inject( [AlertRulesService, UtilService, MockBackend], ( ..._ ) => {
        [alertRulesService, utilService, backend] = _;
    }) );


    describe( '.getDataNotification', () => {
        describe( 'when rules data has loaded', () => {
            it( 'rules data should be available', () => {
                backend.connections.subscribe( conn => {
                    conn.mockRespond( new Response( new ResponseOptions( {
                        body: JSON.stringify( serviceMockResponse ),
                    }) ) );
                    expect( conn.request.method ).toEqual( RequestMethod.Get );
                    expect( conn.request.url ).toEqual( serviceURI );
                });
                alertRulesService.getDataNotification().subscribe( isReady => {
                    expect( isReady ).toBeTruthy();

                    let ruleData = alertRulesService.getRules();
                    expect( ruleData ).toBeDefined();
                    expect( ruleData.length ).toEqual( 2 );
                });
            });
                
            it( 'rules data should not be available', () => {
                backend.connections.subscribe( conn => {
                    conn.mockRespond( new Response( new ResponseOptions( {
                        body: JSON.stringify( "" ),
                    }) ) );
                    expect( conn.request.method ).toEqual( RequestMethod.Get );
                    expect( conn.request.url ).toEqual( serviceURI );
                });
                alertRulesService.getDataNotification().subscribe( isReady => {
                    expect( isReady ).toBeTruthy();
    
                    // get cache data from service
                    let ruleData = alertRulesService.getRules();
                    expect( ruleData ).toBeUndefined();
                });
            });
        });
    });

    describe( '.loadData', () => {
        describe( 'when rules data is cached', () => {
            it( 'cached data should be available', () => {
                backend.connections.subscribe( conn => {
                    conn.mockRespond( new Response( new ResponseOptions( {
                        body: JSON.stringify( serviceMockResponse ),
                    }) ) );
                    expect( conn.request.method ).toEqual( RequestMethod.Get );
                    expect( conn.request.url ).toEqual( serviceURI );
                });
                // call load data to invoke call to service
                alertRulesService.loadData().subscribe( isReady => {
                    expect( isReady ).toBeTruthy();
                });
    
                // try loading cached data from observer
                alertRulesService.getDataNotification().subscribe( isReady => {
                    expect( isReady ).toBeTruthy();
                });
    
                // get cache data from service
                let ruleData = alertRulesService.getRules();
                expect( ruleData ).toBeDefined();
                expect( ruleData.length ).toEqual( 2 );
    
            });
    
            it( 'cached data should not be available', () => {
                backend.connections.subscribe( conn => {
                    conn.mockRespond( new Response( new ResponseOptions( {
                        body: JSON.stringify( serviceMockResponse ),
                    }) ) );
                    expect( conn.request.method ).toEqual( RequestMethod.Get );
                    expect( conn.request.url ).toEqual( serviceURI );
                });
                // call load data to invoke call to service
                alertRulesService.loadData().subscribe( isReady => {
                    expect( isReady ).toBeTruthy();
                });
    
                // try loading cached data from observer
                alertRulesService.getDataNotification().subscribe( isReady => {
                    expect( isReady ).toBeTruthy();
                });
    
                // get cache data from service
                let ruleData = alertRulesService.getRules();
    
                //clear cache data
                alertRulesService.clearCache();
                ruleData = alertRulesService.getRules();
                expect( ruleData ).toBeNull();
            });
        });
    });
    
    describe( '.clearCache', () => {
            it( 'clearCache execution clears cached data', () => {
                alertRulesService.clearCache();
                expect( alertRulesService.getRules() ).toBeNull();;
            });
        }); 
    });

