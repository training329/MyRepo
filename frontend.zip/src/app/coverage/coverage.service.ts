import {Injectable} from '@angular/core';
import {JsonHttp} from "../services/json-http";
import {Response} from '@angular/http';
import {Coverage} from '../models/coverage';
import {Observable} from 'rxjs/Observable';
import "../common/rxjs-operators";

import {UtilService} from "../services/util.service";

//Service End Point URI
const getCoverageServiceEndPoint = '/api/coverage/coverage.json';
const exportToExcelURI = '/api/coverage/export/';

@Injectable()
export class CoverageService {

	constructor(private http: JsonHttp,
				private utilService: UtilService) {
    	console.debug('CoverageService::constructor');
    }
    
    loadData(): Observable<Coverage[]> {
    	console.debug('CoverageService::loadData');
        return this.http.get(getCoverageServiceEndPoint)
        		.map(this.extractUserData)
    }

    extractUserData(res: Response) {
    	console.debug('CoverageService::extractUserData');
		let data = res.json();
		return data;
    }
    
    exportToExcel(searchTerm : string) {
    	console.debug('CoverageService::exportToExcel ', searchTerm);
    	var url = exportToExcelURI;
        if (searchTerm && searchTerm != "") {
            url = url + searchTerm;
        }
    	this.utilService.exportToExcel(url);
    }
}
