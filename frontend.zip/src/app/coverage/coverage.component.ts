import { AppStateService } from './../services/app-state.service';
import { FormControl } from '@angular/forms';
//Framework
import {Component, ElementRef, OnInit, ViewChild} from "@angular/core";
import {Router} from "@angular/router";
import {Subscription} from 'rxjs/Subscription';
import {Observable} from "rxjs/Rx";
import {DataTable} from 'primeng/primeng';

import * as _ from 'underscore';
import * as toastr from 'toastr';

//Application Models
import {Coverage} from '../models/coverage';

//Application Services
import {HttpErrorHandler} from "../services/http-error-handler";
import {CoverageService} from "./coverage.service";
import {UtilService} from "../services/util.service";

//Application Shared
import {SelectItem} from '../common/api';


@Component({
  selector: 'cba-coverage',
  styleUrls: ['coverage.component.scss'],
  templateUrl: 'coverage.component.html',
  providers: [HttpErrorHandler]
})

export class CoverageComponent implements OnInit {
    
	public coverages : Coverage[];
	private coverageOrg : any;
	private serachSubscription : Subscription;
	private termControl:FormControl = new FormControl();
	private searchTerm:string = "";

	@ViewChild('dt') coverageTable : DataTable;

	constructor(private router:Router,
				private errorHandler: HttpErrorHandler,
	            private coverageService:CoverageService,
				private appStateService:AppStateService,
	            private utilService:UtilService) {
		console.debug('CoverageComponent::constructor')
		
		let searchText = this.appStateService.getModuleComponentState('search', 'term');
		if (searchText && searchText != "") {
			this.searchTerm = searchText;
		}
		
		// Bind search call to formControl
        this.termControl.valueChanges
            .debounceTime(400)
            .distinctUntilChanged()
            .subscribe(term => {				
                if(term != null && term != searchText) {
                	this.applyGlobalSearch(term);
                	this.appStateService.setModuleComponentState('search', 'term', term);
                    this.appStateService.setModuleComponentState('datatable', 'currentpage', 0);
                    searchText = null;
                }
            });
	}

	ngOnInit() {
		console.debug('CoverageComponent::ngOnInit')
		this.coverageService.loadData().subscribe(res => {
			this.coverages = res;
			this.coverageOrg = _.clone(this.coverages);
			this.utilService.showNoRecordMessage(this.coverageTable, (this.coverages ? this.coverages.length : 0));
			setTimeout(() => { // need delay to load data in grid before search
        		this.checkCachedData();
            }, 300);
		}, e => {
			toastr.error('Error while getting coverage details. Please try again or contact AQUA RACE support',	',', 'Error');
			this.errorHandler.handle(e);
		}); 
	}
	
	checkCachedData() {
		console.debug("CoverageComponent::checkCachedData ");
		this.setCurrentSearch();
		setTimeout(() => {  // need delay to load data in grid before paging
		    let currentpage = this.appStateService.getModuleComponentState('datatable', 'currentpage')
            if(currentpage)
                this.setCurrentPage(Number(currentpage));
			this.appStateService.activateModuleState();
        }, 300);
		
	}
	
	setCurrentSearch() {
		console.debug("CoverageComponent::setCurrentSearch ");
		var searchTxt =  this.appStateService.getModuleComponentState('search', 'term');
        if(searchTxt && searchTxt != null && searchTxt.trim() != "") {
        	this.searchTerm = searchTxt;  
        } else {
        	this.searchTerm = "";
        }
        this.applyGlobalSearch(this.searchTerm);
	}
	
	setCurrentPage(n: number) {
        console.debug("CoverageComponent::setCurrentPage page ", n + " coverageTable rows"+ this.coverageTable.rows);
        if(this.coverageTable.rows) {
            let paging = {
                first: (n * this.coverageTable.rows),
                rows: this.coverageTable.rows
             };
              
             console.debug("CoverageComponent::setCurrentPage  paging", paging +" page ", n);
             this.coverageTable.paginate(paging);
        }
    }
	
	onPageChange(event) {
        if(this.coverageTable.rows) {
            console.debug("CoverageComponent::onPageChange on page ", event.first/event.rows + " event ", event);
            this.appStateService.setModuleComponentState('datatable', 'currentpage', event.first / event.rows);
            console.debug("CoverageComponent::onPageChange coverageTableCurrentPage ",  event.first/event.rows);
        }        
    }
  
	applyGlobalSearch(term) {
		console.debug('CoverageComponent::applyGlobalSearch ', term)
		var criterias = ["relation", "coverage"];
		if (this.coverageOrg) {
			this.coverages = this.coverageOrg.filter(function (item) {
				var found = false;
				criterias.forEach((criteria:string) => {
					if (item[criteria] && ((item[criteria]).toString().toLowerCase()).indexOf(term.toLowerCase()) != -1) {
						return found = true;
					}
				})
				return found;
			});
			this.utilService.showNoRecordMessage(this.coverageTable, (this.coverages ? this.coverages.length : 0));
		}
	};
	
	resetPage() {
		console.debug('CoverageComponent::resetPage');
		setTimeout(() => { // need delay to load refreshed data in grid
			this.setCurrentPage(0);			
        }, 300);
	}

}

