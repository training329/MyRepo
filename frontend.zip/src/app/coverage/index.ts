export * from './coverage.component';
export * from '../services/private-page.guard';
