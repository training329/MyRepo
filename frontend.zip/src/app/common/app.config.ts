import {Injectable} from '@angular/core';


@Injectable()
export class AppConfig {

    //Base settings
    public  API:string='/api';

    //Controller End Points
    public  ADMIN_EP:string='/adm';

}