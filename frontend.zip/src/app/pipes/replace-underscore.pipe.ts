//Framework
import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
	name: 'replaceUnderscore'
})
export class ReplaceUnderscorePipe implements PipeTransform {
	public transform(input : string): string {
        if (!input || input == null) {
            return '';
        } else {
        	return input.replace(/_/g, ' ');
        }
    }	
}

