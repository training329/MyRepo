//Framework
import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
	name: 'ClientPipe'
})

export class ClientPipe implements PipeTransform {

	transform(clientList, exceptionRuleType) {
		if (exceptionRuleType == '1') {
			return clientList.filter(item => {
			      return item.label !== 'ALL';
			    });
		}
		return clientList;
	}
	
}

