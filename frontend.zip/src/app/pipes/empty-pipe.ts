//Framework
import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
	name: 'EmptyPipe'
})

export class EmptyPipe implements PipeTransform {

	transform(value) {
		if(value == null || value == '') {
		   	return '-';
		} else {
			return value;
		}
	}
	
}

