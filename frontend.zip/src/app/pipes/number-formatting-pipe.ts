//Framework
import { Pipe, PipeTransform } from '@angular/core';


@Pipe({ name: 'numberFormat'})
export class NumberFormatPipe implements PipeTransform {
    public transform(input : string,isAddComma:boolean): string {
        return this.formatNumber(input,isAddComma);
    }
   public parse(input : string,isAddComma:boolean): string {
        return this.formatNumber(input,isAddComma);
  }

  private formatNumber(input : string,isAddComma:boolean):string{
      console.debug('NumberFormatPipe::formatNumber');
       if (!isAddComma) {
            return input.replace(new RegExp(',', 'g'), '');
        } else {
            let _input=parseInt(input)||0;
            if(typeof _input === "number")
                return Math.max(0, _input).toFixed(0).replace(/(?=(?:\d{3})+$)(?!^)/g, ',');
            else
                return input;
        }
  } 
}

