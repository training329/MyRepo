//Framework
import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
	name: 'RegionalPipe'
})

export class RegionalPipe implements PipeTransform {

	transform(regionalList, exceptionRuleType) {
		if (exceptionRuleType == '3') {
			return regionalList.filter(item => {
			      return item.label !== 'GLOBAL';
			    });
		}
		return regionalList;
	}
	
}

