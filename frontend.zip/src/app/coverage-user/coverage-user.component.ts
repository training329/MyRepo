// Framework
import {Component, OnInit, Input, Output, EventEmitter, SimpleChange, ElementRef, ViewChild} from "@angular/core";
import {Observable} from 'rxjs/Observable';
//import {DataTable} from 'primeng/primeng';

// Application Component
// import {Alert} from '../models/Alert';
import {ExceptionUser} from '../models/exception-user';
import {HttpErrorHandler} from "../services/http-error-handler";

//Application Shared
import {SelectItem} from '../common/api';

@Component({
	selector: 'coverage-user',
	templateUrl: './coverage-user.component.html',
	host: {
	    '(document:click)': 'onClick($event)'
	}
})

export class CoverageUserComponent implements OnInit {
	
	@Input() ownername: string;
	@Input() users: Array<ExceptionUser>;
	@Input() orgOwner: any;
	@Input() currOwner: any;
	@Input() bulkUpdate: boolean;
	    
    @Output() onUserChangeNotify: EventEmitter<{userGrpId: string}>;
    
    // For primeng component
    //@ViewChild('coverUsersTable') coverUsersTable: DataTable;
    
    // For old UI component
	@ViewChild('selectCoverAssigment') coverageAssignment;
    
    isDropdownOpened: boolean = false;
	filteredUsers: Array<ExceptionUser>;
    
    constructor(private errorHandler: HttpErrorHandler) {
		console.debug('CoverageUserComponent::constructor');
		this.onUserChangeNotify = new EventEmitter<{userGrpId: string}>();
	}

	ngOnInit() {
		console.debug('CoverageUserComponent::ngOnInit');
	}
	
	ngOnChanges(changes:SimpleChange) {
        console.debug("CoverageUserComponent::ngOnChanges ", changes);
        if (this.users) {
        	this.filteredUsers = this.users;
        }
    }
	
	// For primeng component
	/*onRowSelect(event) {
        console.debug('CoverageUserComponent::onRowSelect', event);
        this.onUserChangeNotify.next({ userGrpId: event.data.groupId });
    }
	
	getRowStyle(rowData: any, rowIndex: number) : string {
		console.log("getRowStyle "+rowData+"  index "+ this.coverUsersTable);
		if (rowData._$visited && !rowData.org_selected) {
 			return 'curr-selection';
		} else if(rowData.org_selected){
			return 'org-selection';
		}
		return "";
	}*/
	
	onRowSelect(userGrpId) {
        console.debug('CoverageUserComponent::onRowSelect', userGrpId);
        this.onUserChangeNotify.next({ userGrpId: userGrpId });
    }
	
	toggleCoverageDropdown() {
		console.debug('CoverageUserComponent::toggleCoverageDropdown');
		this.isDropdownOpened = true;
	}

	checkCoverageDropdown() {
		console.debug('CoverageUserComponent::checkCoverageDropdown');
	    if (this.coverageAssignment) {
	      	const element = this.coverageAssignment.nativeElement;
	       	if (!element.classList.contains("show")) {
	       		this.isDropdownOpened = false;
	       	}
	    }
	}
		
	onClick(event) {
		console.debug('CoverageUserComponent::onClick', event);
		if (event && event.srcElement && event.srcElement.id != "ownerbtn") {
			this.checkCoverageDropdown();
		}	
	}
	
	applyGlobalSearch(term) {
        console.time("CoverageUserComponent::applyGlobalSearch " + term);
        this.filteredUsers = [];
        if (term === "") {								// reset the data to original list
            this.filteredUsers = this.users;
        } else {										// filter the data
            this.filteredUsers = this.users;
            if (term != null && this.users) {
                var criterias = ["soeid", "gpName", "region", "gpType"];
                this.filteredUsers = this.users.filter(function (item) {
                    var found = false;
                    criterias.forEach((criteria:string) => {
                        if (item[criteria] && ((item[criteria]).toString().toLowerCase()).indexOf(term.toLowerCase()) != -1) {
                            return found = true;
                        }
                    })
                    return found;
                });
            }
        }
        console.timeEnd("CoverageUserComponent::applyGlobalSearch " + term);
    }
}
