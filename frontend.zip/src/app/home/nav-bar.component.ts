import { Component } from '@angular/core';

@Component({
    selector: 'ews-nav',
    templateUrl: 'nav-bar.component.html',
    styleUrls: ['nav-bar.component.scss']
})

export class NavBarComponent {
    name = 'navbar';
}
