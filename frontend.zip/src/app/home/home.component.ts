import { Component } from '@angular/core';
import { AlertSummaryService, AlertEditService } from '../alert-summary/';
import { BulkUpdateService } from '../alert-summary/bulk-update/bulk-update.service';
import { AlertRulesService, AlertRuleEditService } from '../alert-rules/';
import { ClientOverviewService } from '../client-overview/client-overview.service';
import { ClientOverviewChartService } from '../client-overview/charts/client-overview-chart.service';
import { CoverageService } from '../coverage/coverage.service';
import { AdminService } from '../admin/admin.service';
import { AdminEditService } from '../admin/manage/admin-edit.service';
import {EventBusService } from "../services/";

@Component({
    selector: 'home',
    templateUrl: 'home.component.html',
    styleUrls: ['home.component.scss'],
    providers: [
                AlertSummaryService,
                AlertEditService, BulkUpdateService,
                AlertRulesService, AlertRuleEditService,
                ClientOverviewService,
                ClientOverviewChartService,
                CoverageService,
                AdminService, AdminEditService,
                EventBusService,
            ],
})
export class HomeComponent {}
