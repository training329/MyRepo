import {Component, OnInit, OnChanges} from '@angular/core';

import {LoginService} from "../services/login.service";
import {UserParams, EnvironmentVersion} from "../shared/dto";

import {ReferenceDataService} from "../services/reference-data.service";

@Component({
    selector: 'ews-header',
    styleUrls:['./header.component.scss'],
    templateUrl: './header.component.html',
})

export class HeaderComponent implements OnInit {
    name = 'header';
    userName: string;
    showUserMenu:boolean = false;
    cbaAccess: boolean = false;
    
    env: EnvironmentVersion;
    
    constructor(private loginService: LoginService,
    			private refDataService: ReferenceDataService) {
        console.debug('HeaderComponent::constructor');
        this.userName = '';
        this.showUserMenu = false;
    }

    ngOnInit() {
    	console.debug('{TODO here} HeaderComponent::ngOnInit ', this.userName );
    	// TODO: Fix LoginComponent to EMIT the empty user name upon LogIn screen initialization,
        // TODO: So this observer will receive NOTIFICATION event and can clean remaining Displayed Welcome User and Top Navigation Bar
        this.loginService.subscribeToUserChange().subscribe((userParams:UserParams) => {
            this.toggleUserName(userParams);
        });
        
        if (this.loginService.isSignedIn()) {
            this.toggleUserName(this.loginService.getUserParams());
        }
        
        this.refDataService.subscribeToEnvDetails().subscribe((env: EnvironmentVersion) => {
        	this.env = env;
        });        
    }

    toggleUserName(userParams:UserParams) {
        console.debug('HeaderComponent::toggleUserName subscribed: ', userParams);
        if(!userParams || userParams == null){
            this.showUserMenu = false;
            this.cbaAccess = false;
            this.userName = "";
        }else{
            console.log('Welcome %s', userParams.name);
            this.showUserMenu = true;
            this.cbaAccess = userParams.isCBAAccessible;
            this.userName = userParams.name;
        }
    }
    
    
    logout() {
    	console.debug('HeaderComponent::logout');
    	this.loginService.logout()
    }
}