import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';



import { PrivatePageGuard } from './services/private-page.guard';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AlertSummaryComponent } from './alert-summary/alert-summary.component';
import { AllAlertsComponent } from './alert-summary/all-alerts.component';
import { ResolvedAlertsComponent } from './alert-summary/resolved-alerts.component';
import { AlertEditComponent } from './alert-summary/manage/alert-edit.component';
import { AlertRuleEditComponent } from './alert-rules/manage/alert-rule-edit.component';
import { AlertRulesComponent } from './alert-rules/alert-rules.component';
import { ClientOverviewComponent } from './client-overview/client-overview.component';
import { CoverageComponent } from './coverage/coverage.component';
import { AdminComponent } from './admin/admin.component';
import { AdminEditComponent } from './admin/manage/admin-edit.component';


const appRoutes: Routes = [

    {
        path: '', 
        component: LoginComponent
    },
    {
        path: 'login', 
        component: LoginComponent
    },
     {
         path: 'alerts',
         component: HomeComponent,
         canActivate: [PrivatePageGuard],
         children: [
                    {
                        path: 'summary', 
                        component: AlertSummaryComponent, 
                        canActivate: [PrivatePageGuard],
                        children: [
                                    {
                                        path: 'myalerts', 
                                        component: AllAlertsComponent, 
                                        canActivate: [PrivatePageGuard]
                                    },
                                    {
                                        path: 'all', 
                                        component: AllAlertsComponent, 
                                        canActivate: [PrivatePageGuard]
                                    },
                                    {
                                        path: 'resolved', 
                                        component: ResolvedAlertsComponent, 
                                        canActivate: [PrivatePageGuard]
                                    },
                                    {
                                        path: 'alert-item/:id', 
                                        component: AlertEditComponent, 
                                        canActivate: [PrivatePageGuard]
                                    },
                                    {
                                        path: '**',
                                        redirectTo: 'myalerts',
                                        pathMatch: 'full'
                                    }
                                    
                        ]
                    },
                    
                    {
                        path: 'rules', 
                        component: AlertRulesComponent, 
                        canActivate: [PrivatePageGuard]
                    },
                    {
                        path: 'rule-item/:id', 
                        component: AlertRuleEditComponent, 
                        canActivate: [PrivatePageGuard]
                    },
                    {
                        path: 'clientoverview', 
                        component: ClientOverviewComponent, 
                        canActivate: [PrivatePageGuard]
                    },
                    {
                        path: 'coverage', 
                        component: CoverageComponent, 
                        canActivate: [PrivatePageGuard]
                    },
                    {
                        path: 'admin',
                        component: AdminComponent,
                        canActivate: [PrivatePageGuard]
                    },
                    {
                    	path: 'manage-user/:id',
                    	component: AdminEditComponent,
                    	canActivate: [PrivatePageGuard]
                    },
                    {
                        path: '',
                        redirectTo: 'summary',
                        pathMatch: 'full'
                    },
         ]
     },
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    }//,
//    {
//        path: '**',
//        redirectTo: '/login',
//        pathMatch: 'full'
//    }
];

export const appRouterProviders: any[] = [];

export const routing: ModuleWithProviders =
  RouterModule.forRoot(appRoutes);
