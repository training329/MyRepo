// Angular
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { LocationStrategy, HashLocationStrategy, APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, JsonpModule } from '@angular/http';

// Vendors
import { AlertModule, DatepickerModule, TabsModule, TypeaheadModule } from 'ng2-bootstrap/ng2-bootstrap';

import { InputTextModule, DataTableModule, ButtonModule, PanelModule, DialogModule, MultiSelectModule, DropdownModule, CalendarModule, RadioButtonModule, GrowlModule, MessagesModule} from 'primeng/primeng';
import { AccordionModule, PanelMenuModule, OverlayPanelModule, SharedModule, TabViewModule, FieldsetModule, AutoCompleteModule, ContextMenuModule} from 'primeng/primeng';

import {PasswordModule } from 'primeng/primeng';
import {ChartModule} from 'angular2-highcharts';

import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';

/* app common */
import { routing, appRouterProviders } from './app.routing';
import { MyStorage,  MySessionStorage} from "./services/";
import { CalendarComponent } from './calendar/calendar.component';

/* app pipes */
import {EmptyPipe} from './pipes/empty-pipe';
import {RegionalPipe} from './pipes/regional-pipe';
import {ClientPipe} from './pipes/client-pipe';
import {ReplaceUnderscorePipe} from './pipes/replace-underscore.pipe';
import {TitleCasePipe} from './pipes/title-case.pipe';
import {NumberFormatPipe} from './pipes/number-formatting-pipe';

/* app directives */
import { ConditionalRequiredValidator} from "./directives/conditional-required-validator.directive";
import { SummaryHighlightDirective } from "./alert-summary/summary-highlight.directive";
import { AccessDirective } from "./directives/access.directive";
import { BackNavigationDirective } from "./directives/back-navigation.directive";
import { NumberFormatDirective } from './directives/number.format.directive';

/*  app components */
import { AppComponent } from './app.component';
import { HeaderComponent } from './home/header.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './home/footer.component';
import { NavBarComponent } from './home/nav-bar.component';

import { LoginComponent} from "./login/login.component";
import { SpinnerComponent } from "./services/spinner/spinner.component";

/* Alert Summary*/
import { AlertSummaryComponent, MyAlertsComponent, AllAlertsComponent, ResolvedAlertsComponent} from "./alert-summary";
import { AlertEditComponent, AlertEditHistoryComponent } from "./alert-summary/manage/";
import { AlertStatusChartComponent } from "./alert-summary/charts/alert-status-chart.component";
import { TopClientsChartComponent } from "./alert-summary/charts/top-clients-chart.component";
import { AlertStatusByVolumnChartComponent } from "./alert-summary/charts/alert-status-by-volumn-chart.component";
import { BulkUpdateComponent } from "./alert-summary/bulk-update/bulk-update.component";

/* Alert Rule*/
import { AlertRulesComponent, AlertRuleEditComponent, AlertRuleDetailsComponent } from './alert-rules/';

/* Client Overview*/
import { ClientOverviewComponent } from "./client-overview/client-overview.component";
import { ChartFilterComponent } from "./client-overview/filter/chart-filter.component";
import { FinancingBalanceChartComponent } from "./client-overview/charts/financing-balance-chart.component";
import { EquityBalanceChartComponent } from "./client-overview/charts/equity-balance-chart.component";
import { BalanceSheetROAChartComponent } from "./client-overview/charts/balance-sheet-roa-chart.component";
import { RevenueChartComponent } from "./client-overview/charts/revenue-chart.component";
import { SecurityCountryRiskChartComponent } from "./client-overview/charts/security-country-risk-chart.component";
import { SecurityProductChartComponent } from "./client-overview/charts/security-product-chart.component";
import { SecuritySectorChartComponent } from "./client-overview/charts/security-sector-chart.component";
import { SecurityMarketCapChartComponent } from "./client-overview/charts/security-market-cap-chart.component";

/* Coverage */
import { CoverageComponent } from "./coverage/coverage.component";
import { CoverageUserComponent } from "./coverage-user/coverage-user.component";

/* Admin */
import { AdminComponent } from './admin/admin.component';
import { AdminEditComponent } from './admin/manage/admin-edit.component';
import { AdminEditHistoryComponent } from './admin/manage/admin-edit-history.component';
import { AdminEditCoverageComponent } from './admin/manage/admin-edit-coverage.component';

/* app services */
import { HttpErrorHandler } from "./services/http-error-handler";
import { JsonHttp} from "./services/json-http";
import { PrivatePageGuard } from './services/private-page.guard';
import { LoginService, ReferenceDataService, IdleService, UtilService } from "./services/";
import { SpinnerService } from "./services/spinner/spinner.service";

import { AppStateService } from "./services/app-state.service";
import { AppConfig } from './common/app.config';

// import { AdminService } from "./admin/admin.service";

@NgModule({
    declarations: [AppComponent,
        // AboutComponent,
        CalendarComponent,
        HeaderComponent,
        HomeComponent,
        FooterComponent,
        NavBarComponent,
        LoginComponent,
        SpinnerComponent,
        AlertSummaryComponent, MyAlertsComponent, AllAlertsComponent, ResolvedAlertsComponent, AlertEditComponent, AlertEditHistoryComponent,
        AlertStatusChartComponent,
        AlertStatusByVolumnChartComponent,
        BulkUpdateComponent, CoverageUserComponent,
        TopClientsChartComponent,
        AlertRulesComponent, AlertRuleEditComponent, AlertRuleDetailsComponent,
        ClientOverviewComponent,
        ChartFilterComponent,
        FinancingBalanceChartComponent,
        EquityBalanceChartComponent,
        BalanceSheetROAChartComponent,
        RevenueChartComponent,
        SecurityCountryRiskChartComponent,
        SecurityProductChartComponent,
        SecuritySectorChartComponent,
        SecurityMarketCapChartComponent,
        CoverageComponent,
        AdminComponent, AdminEditComponent, AdminEditHistoryComponent, AdminEditCoverageComponent,
        EmptyPipe, RegionalPipe, ClientPipe, ReplaceUnderscorePipe, TitleCasePipe,NumberFormatPipe,
        ConditionalRequiredValidator, SummaryHighlightDirective, AccessDirective, BackNavigationDirective,NumberFormatDirective
    ],
    imports: [BrowserModule, FormsModule, ReactiveFormsModule,
              HttpModule, JsonpModule,  AlertModule, TabsModule, TypeaheadModule, DatepickerModule,
              InputTextModule, DataTableModule,ButtonModule, PanelModule, DialogModule, MultiSelectModule,
              DropdownModule, CalendarModule, RadioButtonModule, GrowlModule, MessagesModule, 
              AccordionModule, PanelMenuModule, OverlayPanelModule, SharedModule, TabViewModule, ContextMenuModule,
              FieldsetModule, AutoCompleteModule, PasswordModule,
              routing, ChartModule, NgIdleKeepaliveModule.forRoot()],
    schemas:  [CUSTOM_ELEMENTS_SCHEMA],
    providers: [
        JsonHttp,
        IdleService,
        SpinnerService,
        UtilService,
        
        PrivatePageGuard,
        appRouterProviders,
        MyStorage,
        MySessionStorage,
        ReferenceDataService,
        AppStateService,
        LoginService,
        HttpErrorHandler,
        
        [{ provide: APP_BASE_HREF, useValue: '/' }],
        [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
        AppConfig
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }