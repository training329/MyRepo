export * from './login.component';
export * from '../services/private-page.guard';
