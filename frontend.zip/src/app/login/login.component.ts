import {Component, ElementRef, OnInit} from "@angular/core";
import {Router} from "@angular/router";
import {LoginService} from "../services/login.service";
// import {MyHttp} from "../services/http";
import {PrivatePageGuard} from "../services/private-page.guard";
import {PasswordModule} from 'primeng/primeng';
import {HttpErrorHandler} from "../services/http-error-handler";

//KEEP THE FOLLOWING LINE TO PREVEN TS ERRORS:
/// <reference path="./toaster.d.ts" />
import * as toastr from 'toastr';

@Component({
    selector: 'cba-login',
    styleUrls: ['./login.component.scss'],
    templateUrl: './login.component.html',
    providers: [PrivatePageGuard]
})


export class LoginComponent implements OnInit {

    public user = new User('', '', '', '');
    private isLogin: boolean = true;

    constructor(private router:Router,
                private loginService:LoginService,
                private errorHandler: HttpErrorHandler,) {
        console.debug("LoginComponent::constructor");
    }
    
    ngOnInit() {
    	console.debug("LoginComponent::ngOnInit");
    	this.loginService.clearUserData();
    }

    login() {
    	console.debug("LoginComponent::login", this.user.soeid);
    	if(this.user.soeid && this.user.password) {
	        this.loginService.login(this.user.soeid, this.user.password)
	            .subscribe(res => {
	            	if ((res as any).statusCode == 'EWS_1000') {
		            	this.clear();
		            	this.isLogin = false;
		            	toastr.error('Please change your password', 'Alert');
	        		} else {
	        			this.router.navigate(['/alerts/summary']);
	        		}
	            }, this.handleError);
    	} else {
    		 toastr.error('User name or password is incorrect.', 'Error');
    	}
    }

    changePwd() {
    	console.debug("LoginComponent::changePwd");
        let soeid = this.user.soeid;
        let oldPassword = this.user.password;
        let newPassword = this.user.newPassword;
        let confirmPassword = this.user.confirmPassword;
        
        if (soeid === null || oldPassword === null || newPassword === null || confirmPassword === null || (confirmPassword !== newPassword)) {
        	alert("Please enter valid values");
        	return false;
        } else {
	        this.loginService.changePwd(soeid, oldPassword, newPassword)
            .subscribe(data => {
	            if ((data as any).isAuthenticated) {
	            	this.clear();
	            	this.isLogin = false;
                    toastr.success('Change password Successful', 'Alert');
	            } else {
	            	toastr.error('User not Authenticated', 'Error');
	            }
	        }, e => this.errorHandler.handle(e) );
        }
    }

    toggleLoginChangePwd() {
    	console.debug("LoginComponent::toggleLoginChangePwd");
    	this.isLogin = !this.isLogin;
    }
    
    clear() {
    	console.debug("LoginComponent::clear");
    	this.user = new User('', '', '', '');
    }

    handleError(error) {
        console.debug("LoginComponent::handleError", error);
        switch (error.status) {
            case 401:
                toastr.error('User name or password is invalid.', 'Error');
        }
    }
}

export class User {
    constructor(public soeid:string,
                public password:string,
                public newPassword:string,
                public confirmPassword:string) {
    }
}

