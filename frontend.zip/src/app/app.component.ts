import { Component, HostListener, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'client-alert-dashboard',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class AppComponent {
    name = 'cba-admin';
    
    @HostListener('window:beforeunload', ['$event'])
    clear($event) {
    	console.debug('AppComponent::clear');
    }
}
