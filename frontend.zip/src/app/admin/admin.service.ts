// Framework
import {Injectable} from '@angular/core';
import {Response, URLSearchParams} from '@angular/http';
import {Observable}from'rxjs/Observable';
import {Subscription} from 'rxjs/Subscription';
import {BehaviorSubject} from "rxjs/Rx";

// Application
import {PageRequest, Page, UserParams} from "../shared/dto";
import {JsonHttp} from "../services/json-http";
import {objToSearchParams} from "../services/helpers";
import {HttpErrorHandler} from "../services/http-error-handler";
import {AppStateService} from  "../services/app-state.service";
import {EventBusService} from  "../services/event-bus.service";
import {UtilService} from "../services/util.service";
import {EWSUser} from '../models/ews-user';

import "../common/rxjs-operators";

import * as toastr from 'toastr';

// Service END Point URL should be declared as SERVICE END POINT
const serviceEndPoint = '/api/adm/ewsusers.json';
const exportToExcelURI = '/api/adm/export/';
const defaultPageRequest: PageRequest = {page: 1, size: 5};

@Injectable()
export class AdminService {

	/**
     * Indicates when service is in process of loading data from backend
     * @type {boolean}
     */
    private isLoadingData:boolean = false;

    /**
     *  Observable to subscribe to receive data loaded notification
     *  Check implementation details here: https://github.com/ReactiveX/rxjs/blob/master/doc/subject.md
     *  Idea is to use the Subject to communicate completion of data retrieval process in service
     * @type {BehaviorSubject}
     */
    private dataIsReady:BehaviorSubject<boolean> = new BehaviorSubject(false);
    
    private usersData: EWSUser[];
    
    private usersDataObservable:Observable<EWSUser[]>;
	private usersSubscription:Subscription;
    
    constructor(private http: JsonHttp,
                private errorHandler: HttpErrorHandler,
                private eventBusService:EventBusService,
                private appStateService:AppStateService,
                private utilService: UtilService) {
    	console.debug('AdminService::constructor');
    }

    loadData(pageRequest: PageRequest): Observable<boolean> {
        console.debug( "AdminService::loadData ");
        
        // fire up the request to backend service
        // mark loading by service. Note: it will become false once table produced from response
        this.isLoadingData = true;
        this.dataIsReady.next(false);
        
        this.usersDataObservable = this.http.get(serviceEndPoint, {search: objToSearchParams(pageRequest)})
	        .map(res => res.json())   // both result and error responsens are handled by Observable
	        .publishLast() // required to prevent multiple requests
	        .refCount()
	        //.catch((error:any) => Observable.throw(error.json().error || 'Server error'))
	        .finally(()=> {
	            console.timeEnd("AdminService::loadData GET:" + serviceEndPoint)
	        });

	    // subscribe to HTTP Get Observable
	    this.usersSubscription = this.usersDataObservable.subscribe(
	        data => {
	            this.isLoadingData = false;
	            this.loadUsers(data);
	            // notify calling service subscribers
	            this.dataIsReady.next(true);
	        },
	        err => {  // Log errors if any
	        	toastr.error('Error while getting users data. Please try again or contact AQUA RACE support', 'Error');
				this.errorHandler.handle(err);
	            this.isLoadingData = false;
	            // notify calling service subscribers
	            this.dataIsReady.next(false);
	        },
	        () => console.debug("AdminService::loadData GET unsubscribe")
	    );
	    
	    // return Observable to calling component to notify when data is ready to be requested directly
	    return this.dataIsReady.asObservable();
    }
    
    getDataNotification(pageRequest: PageRequest = defaultPageRequest) : Observable<boolean> {
        if(this.usersDataObservable == null){
            this.loadData(pageRequest)
        }
        return this.dataIsReady.asObservable();
    }
    
    loadUsers(data:EWSUser[]):void {
        console.debug("AdminService::loadUsers ", data);
        if (data && data.length > 0) {
            console.time("AdminService::loadUsers");
            this.usersData = data;
            console.timeEnd("AdminService::loadUsers");
        }
    }

    getUsers():EWSUser[] {
        return this.usersData;
    }
    
    clearCache(): void {
        console.debug( "AdminService::clearCache");
        if(this.usersSubscription)
            this.usersSubscription.unsubscribe();
        this.usersDataObservable = null;
        
       // droppping app cache since change in coverage will impact other modules summary and rules
        this.eventBusService.dispatch(new CustomEvent("ClearCacheOnUserUpdate"));
    }

    get():Observable<EWSUser[]> {
       console.debug('AdminService::get');
       return this.http.get(
           serviceEndPoint,
           { search: objToSearchParams('p=dummy')} )
           .map
           //<EWSUser[]>
           ((res:Response) => res.json());
    }
    
    exportToExcel(searchText : string) {
    	console.debug('AdminService::exportToExcel ', searchText);
    	var url = exportToExcelURI;
        if (searchText && searchText != "") {
            url = url + searchText;
        }
    	this.utilService.exportToExcel(url);
    }

}
