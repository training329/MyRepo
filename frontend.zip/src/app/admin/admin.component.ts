// Framework
import {Component, ElementRef, OnInit, ViewChild, OnDestroy, Renderer} from "@angular/core";
import {FormControl} from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import {DataTable} from 'primeng/primeng';
import {Subscription} from 'rxjs/Subscription'

// Application Component
import {EWSUser} from '../models/ews-user';
import {HttpErrorHandler} from "../services/http-error-handler";
import {AdminService} from "./admin.service";
import {UtilService} from "../services/util.service";
import {AppStateService} from "../services/app-state.service";

// Application Shared
import {SelectItem} from '../common/api';
import {ReplaceUnderscorePipe} from '../pipes/replace-underscore.pipe';

import * as toastr from 'toastr';

@Component({
  selector: 'admin',
  styleUrls: ['./admin.component.scss'],
  templateUrl: './admin.component.html',
  providers: [HttpErrorHandler, ReplaceUnderscorePipe]
})
export class AdminComponent implements OnInit, OnDestroy {
    
  ewsUsers:Array<EWSUser> = [];
  cols: any[] = [];
  columnOptions: SelectItem[] = [];
  totalPages: number;
  page: number;
  
  searchText : string = "";
  private termControl : FormControl = new FormControl();
  private usersSubscription:Subscription;
  
  @ViewChild('dt') usersTable : DataTable;
  @ViewChild('searchTerm') searchTerm;

  constructor(private router:Router,
              private errorHandler: HttpErrorHandler,
              private route: ActivatedRoute,
              private adminService:AdminService,
              private utilService:UtilService,
              private appStateService:AppStateService,
			  private renderer:Renderer,
			  private replaceUnderscore:ReplaceUnderscorePipe) {
	  console.debug("AdminComponent::constructor");
      this.cols = [
          {header:'DOMAIN', field:'domain_name'},
          {header:'SOE ID', field:'soeid'},
          {header:'NAME', field:'friendly_name' },
          {header:'ROLE', field:'race_role'},
          {header:'ALL CLIENTS', field:'all_client'},
          {header:'MANAGE ALERT', field:'manage_alert'},
          {header:'MANAGE RULE', field:'manage_alert_rule' },
          {header:'ADD ADMIN', field:'add_admin'},
          {header:'MANAGE COVERAGE', field:'manage_coverage'}
      ];

      this.columnOptions = [];
      for(let i = 0; i < this.cols.length; i++) {
          this.columnOptions.push({label: this.cols[i].header, value: this.cols[i]});
      }
      
      // Bind search call to formControl
      this.termControl.valueChanges
          .debounceTime(400)
          .distinctUntilChanged()
          .subscribe(term => {
              let previousSearchTerm = this.appStateService.getModuleComponentState('search', 'term');
          	  if(term != null && term != previousSearchTerm) {
          	    this.appStateService.setModuleComponentState('search', 'term', term);
                this.appStateService.setModuleComponentState('datatable', 'currentpage', 0);
              }            	
          });
  }

  ngOnInit() {
	  console.debug("AdminComponent::ngOnInit");
      this.route.params.subscribe(params => {
          this.page = +(params['page'] || 1);
          this.list(this.page);
      });
  }

  private list(page: number) {
	console.debug('AdminComponent::list ', 'subscribing to adminService.isReady');
	this.usersSubscription = this.adminService.getDataNotification({page: page, size: 5})
	.subscribe(isReady => {
        console.debug('AdminComponent::list ', 'subscriptions completed', isReady);
        if(isReady) {
        	this.ewsUsers = this.adminService.getUsers();
        	//Update race role value to replace underscore
        	this.formatUserRaceRoles();
        	this.utilService.showNoRecordMessage(this.usersTable, (this.ewsUsers ? this.ewsUsers.length : 0));
        	setTimeout(() => {// need delay to load data in grid before search
        		this.checkCachedData();
            }, 300);
        }		
	});
  }
  
  formatUserRaceRoles() {
	  console.debug('AdminComponent::formatUserRaceRoles');
	  for (let user of this.ewsUsers) {
		  user.race_role = this.replaceUnderscore.transform(user.race_role);
	  }
  }
  
  onPageChange(event) {
      if(this.usersTable.rows) {
          console.debug("AdminComponent::onPageChange on page ", event.first/event.rows + " event ", event);
          this.appStateService.setModuleComponentState('datatable', 'currentpage', event.first / event.rows);
          console.debug("AdminComponent::onPageChange usersTableCurrentPage ",  event.first/event.rows);
      }        
  }
	
  checkCachedData() {
	  this.setCurrentSearch();
	  	setTimeout(() => {// need delay to load data in grid before paging
	  	  let currentpage = this.appStateService.getModuleComponentState('datatable', 'currentpage')
          if(currentpage)
              this.setCurrentPage(Number(currentpage));
          this.appStateService.activateModuleState();
	  	}, 300);
  }
	
  setCurrentSearch() {
	  console.debug("AdminComponent::setCurrentSearch ");
	  var searchTxt = this.appStateService.getModuleComponentState('search', 'term');
      if(searchTxt && searchTxt != null && searchTxt.trim() != "") {
      	this.searchText = searchTxt;  
      } else {
      	this.searchText = "";
      }
      this.onSearchTextChange();
  }
  
  onSearchTextChange() {
	  console.debug('AdminComponent::onSearchTextChange');
	  this.usersTable.onFilterKeyup(this.searchText, 'data', 'contains');  // invoking global filter on data table manually with dummy arguments
  }
	
  setCurrentPage(n: number) {
      console.debug("AdminComponent::setCurrentPage page ", n + " usersTable rows"+ this.usersTable.rows);
      if(this.usersTable.rows) {
          let paging = {
              first: (n * this.usersTable.rows),
              rows: this.usersTable.rows
           };
            
           console.debug("AdminComponent::setCurrentPage  paging", paging +" page ", n);
           this.usersTable.paginate(paging);
      }
      //this.usersTable.sortField = "cob_date";
      //this.usersTable.sortOrder = -1;  
  }
  
  onRowSelect(event) {
	  console.debug("AdminComponent::onRowSelect ", event);
      console.log("on row selected data "+ event.data.soeid);
      this.router.navigate( ['alerts/manage-user', event.data.soeid] );
  }
  
  /*exportToExcel() {
  	console.debug('AdminComponent::exportToExcel ', this.ewsUsers);
  	this.utilService.exportToExcel(exportToExcelURI, this.ewsUsers, "Users.xls");
  }*/
  
  ngOnDestroy(){
      console.debug('AdminComponent::ngOnDestory: ');
      this.usersSubscription.unsubscribe();
  }
  
  clearSearch() {
	  console.debug('AdminComponent::clearSearch');
	  this.searchText = "";
	  this.onSearchTextChange();
  }

}

