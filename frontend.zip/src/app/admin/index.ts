export * from './admin.component';
export * from '../services/private-page.guard';
