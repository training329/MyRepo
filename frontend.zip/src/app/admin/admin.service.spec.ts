import {inject, TestBed} from "@angular/core/testing";
import {Router} from "@angular/router";
import {
    ResponseOptions,
    Response,
    RequestMethod,
    HttpModule,
    ResponseType
} from "@angular/http";
import {MockBackend} from "@angular/http/testing";
import {AdminService} from "./admin.service";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../testing";

import {UserParams, EnvironmentVersion} from "../shared/dto";
import {MyStorage} from "../services/storage-wrapper";
import {JsonHttp} from "../services/json-http";
import {APIResponse} from '../models/api-response';
import {IdleService} from "../services/idle.service";
import {AppStateService} from "../services/app-state.service";
import {EventBusService} from  "../services/event-bus.service";
import {ReferenceDataService} from "../services/reference-data.service";
import {HttpErrorHandler}  from '../services/http-error-handler';
import {UtilService} from "../services/util.service";

import {MockError,
        MockRouter,
        MockReferenceDataService,
        MockAppStateService,
        MockIdleService,
        MockHttpErrorHandler,
        MockEventBusService,
        MockUtilService} from '../testing/mock.services';

const adminServiceMockResponse=[{"id":null,"soeid":"ar98440","friendly_name":"Rastogi, Aditya ","domain_name":"NAM\\ar98440","email":"ar98440@imcnam.ssmb.com","status":"ACTIVE    ","user_role":"APPUSER","race_role":"view_only","all_client":true,"manage_alert":false,"manage_alert_rule":false,"add_admin":false,"manage_coverage":false},{"id":null,"soeid":"mk35063","friendly_name":"Kherde, Milind","domain_name":"NAM\\mk35063","email":"mk35063@imcnam.ssmb.com","status":"ACTIVE    ","user_role":"APPUSER","race_role":"global_admin","all_client":true,"manage_alert":true,"manage_alert_rule":true,"add_admin":true,"manage_coverage":true},{"id":null,"soeid":"JB33959","friendly_name":"Bajus, John","domain_name":"NAM\\JB33959","email":"john.e.bajus@citi.com","status":"ACTIVE    ","user_role":"APPUSER","race_role":"coverage_based","all_client":false,"manage_alert":true,"manage_alert_rule":false,"add_admin":false,"manage_coverage":false},{"id":null,"soeid":"vn06956","friendly_name":"Nimbalkar, Viraj Ashokrao","domain_name":"NAM\\vn06956","email":"vn06956@imcnam.ssmb.com","status":"ACTIVE    ","user_role":"APPUSER","race_role":"admin","all_client":true,"manage_alert":true,"manage_alert_rule":true,"add_admin":true,"manage_coverage":true}];


describe('AdminService: Admin Service for showing list of user and his access', () => {

    let adminService: AdminService;
    let backend: MockBackend;

    let router: Router;
    let refService: ReferenceDataService;
    let appState: AppStateService;
    let idle: IdleService;
	let eventBusService: EventBusService;
	let utilService: UtilService; 

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: Router,
                    useClass: MockRouter,
                },
                {
                    provide: ReferenceDataService,
                    useClass: MockReferenceDataService,
                },
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                 {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                {
                    provide: IdleService,
                    useClass: MockIdleService,
                },
                {
                	provide: EventBusService,
                	useClass: MockEventBusService,
                },
                {
                	provide: UtilService,
                    useClass: MockUtilService,
                },
                APP_TEST_HTTP_PROVIDERS,
                AdminService,
            ],
        });
    });


    beforeEach(inject([AdminService, EventBusService, UtilService, MockBackend], (..._) => {
        [adminService, eventBusService, utilService, backend] = _;
    }));

    describe('getDataNotification: Load user data in Admin', () => {
        let subscription;
        describe('When data is available', () => {
                it('Is data loading and ready to return data ?', () => {
                    backend.connections.subscribe(conn => {
                        
                        conn.mockRespond(new Response(new ResponseOptions({
                            body: adminServiceMockResponse
                        })));
                        expect(conn.request.method).toEqual(RequestMethod.Get);
                        expect(conn.request.url).toEqual('/api/adm/ewsusers.json?page=1&size=2');
                        expect(conn.request.json()).not.toBeTruthy();
                    });
                    adminService.getDataNotification({page: 1, size: 2}).subscribe(isReady => {
                        expect(isReady).toBeTruthy();
                    });
                });
                it("Are there any user and having length 4 ?", function() {
                    backend.connections.subscribe(conn => {
                        conn.mockRespond(new Response(new ResponseOptions({body: adminServiceMockResponse})));
                    });
                    adminService.getDataNotification({page: 1, size: 2}).subscribe(isReady => {
                        let ewsUSer=adminService.getUsers();
                        expect(ewsUSer).toBeDefined();
                        expect(ewsUSer.length).toEqual(4);
                    });
                });
         });
         describe('When data is not available or exception occured', () => {
                let subscription=undefined;
                beforeEach(function() {
                        subscription=backend.connections.subscribe(conn => {
                        conn.mockError(new MockError(new ResponseOptions(MockError.error_500)));
                    });
                });
                afterEach(function() { subscription.unsubscribe(); });

                it('Data should not be ready ?', () => {
                    adminService.getDataNotification({page: 0, size: 0}).subscribe(isReady => {
                        expect(isReady).toBeFalsy();
                    });
                });
                it("Data must not return  ?", function() {
                    adminService.getDataNotification({page: 1, size: 2}).subscribe(isReady => {
                        let ewsUSer=adminService.getUsers();
                        expect(ewsUSer).toBeUndefined();
                    });
                });
         });
         
    }); 

});