import { inject, TestBed } from "@angular/core/testing";
import { Router } from "@angular/router";
import {
    ResponseOptions,
    Response,
    RequestMethod,
    HttpModule,
    ResponseType
} from "@angular/http";
import { MockBackend } from "@angular/http/testing";
import { AdminEditService } from "./admin-edit.service";

// Application services
import { APP_TEST_HTTP_PROVIDERS } from "../../testing";

import { JsonHttp } from "../../services/json-http";
import { APIResponse } from '../../models/api-response';
import { IdleService } from "../../services/idle.service";
import { AppStateService } from "../../services/app-state.service";
import { ReferenceDataService } from "../../services/reference-data.service";
import { HttpErrorHandler } from '../../services/http-error-handler';

import { DropDownModel } from '../../models/dropdown-model';
import { EWSUser } from '../../models/ews-user';
import { Coverage } from '../../models/coverage';
import { AppConfig } from '../../common/app.config';

import {
    MockError,
    MockRouter,
    MockReferenceDataService,
    MockAppStateService,
    MockIdleService,
    MockHttpErrorHandler
} from '../../testing/mock.services';

const userDetails = {
    "id": null, "soeid": "AW11769", "friendly_name": "Waste, Avinash", "domain_name": "NAM\\AW11769",
    "email": "avinash.guruling.waste@citi.com", "status": "ACTIVE    ", "user_role": "APPUSER", "race_role": "coverage_based",
    "all_client": false, "manage_alert": true, "manage_alert_rule": false, "add_admin": false, "manage_coverage": false
};

const userHistoryDetails = [{
    "id": 0, "soeid": "MK31857", "friendly_name": "Kishore, Mayank", "domain_name": "NAM\\mk31857",
    "email": "mayank.kishore@citi.com", "manager_soeid": null, "status": "ACTIVE    ", "user_role": "APPUSER",
    "race_role": "coverage_based", "all_client": false, "manage_alert": true, "manage_alert_rule": false, "add_admin": false,
    "manage_coverage": false, "operation": "Updated", "created_by": "Kherde, Milind", "created_time": "2017-01-17 04:14:10",
    "created_time_db": "2017-01-17 04:14:10.2"
},
{
    "id": 0, "soeid": "MK31857", "friendly_name": "Kishore, Mayank", "domain_name": "NAM\\mk31857",
    "email": "mayank.kishore@citi.com", "manager_soeid": null, "status": "ACTIVE    ", "user_role": "APPUSER",
    "race_role": "coverage_based", "all_client": false, "manage_alert": true, "manage_alert_rule": false,
    "add_admin": false, "manage_coverage": false, "operation": "Updated", "created_by": "Kherde, Milind",
    "created_time": "2017-01-17 04:13:58", "created_time_db": "2017-01-17 04:13:58.867"
},
{
    "id": 0, "soeid": "MK31857", "friendly_name": "Kishore, Mayank", "domain_name": "NAM\\mk31857",
    "email": "mayank.kishore@citi.com", "manager_soeid": null, "status": "ACTIVE    ",
    "user_role": "APPUSER", "race_role": "coverage_based", "all_client": false, "manage_alert": true,
    "manage_alert_rule": false, "add_admin": false, "manage_coverage": false, "operation": "Updated",
    "created_by": "White,Scott", "created_time": "2017-01-14 09:54:18",
    "created_time_db": "2017-01-14 09:54:18.803"
},
{
    "id": 0, "soeid": "MK31857", "friendly_name": "Kishore, Mayank", "domain_name": "NAM\\mk31857",
    "email": "mayank.kishore@citi.com", "manager_soeid": null, "status": "ACTIVE    ",
    "user_role": "APPUSER", "race_role": "coverage_based", "all_client": true, "manage_alert": true, "manage_alert_rule": false,
    "add_admin": false, "manage_coverage": false, "operation": "Updated", "created_by": "Waste, Avinash",
    "created_time": "2016-08-10 05:01:27", "created_time_db": "2016-08-10 05:01:27.893"
}];

const clientCoverageList = [{
    "groupId": 1, "relationId": 116345, "relation": "10V", "gpNum": "24978", "topAccount": null, "gpType": "Primary",
    "region": null, "soeid": null, "active": false, "source": null, "primary": false
},
{
    "groupId": 2, "relationId": 115347, "relation": "398", "gpNum": "12281", "topAccount": null, "gpType": "Primary",
    "region": null, "soeid": null, "active": false, "source": null, "primary": false
},
{
    "groupId": 3, "relationId": 195937, "relation": "683", "gpNum": "66232", "topAccount": null, "gpType": "Primary",
    "region": null, "soeid": null, "active": false, "source": null, "primary": false
},
{
    "groupId": 4, "relationId": 115354, "relation": "ABNAMRO", "gpNum": "16683", "topAccount": null, "gpType": "Primary",
    "region": null, "soeid": null, "active": false, "source": null, "primary": false
},
{
    "groupId": 5, "relationId": 166961, "relation": "ABSOLUTE INVESTMENT", "gpNum": "64245", "topAccount": null,
    "gpType": "Primary", "region": null, "soeid": null, "active": false, "source": null, "primary": false
},
{
    "groupId": 6, "relationId": 249364, "relation": "ADAGE", "gpNum": "53809", "topAccount": null, "gpType": "Primary",
    "region": null, "soeid": null, "active": false, "source": null, "primary": false
},
{
    "groupId": 7, "relationId": 115367, "relation": "ADVENT", "gpNum": "58826", "topAccount": null, "gpType": "Primary",
    "region": null, "soeid": null, "active": false, "source": null, "primary": false
}]

const userCoverage = [{
    "groupId": 2, "relationId": 115347, "relation": "398", "gpNum": "12281", "topAccount": "00398", "gpType": "Primary",
    "region": "NAM", "soeid": "MK31857", "active": true, "source": "AQUA", "primary": true
},
{
    "groupId": 1, "relationId": 116345, "relation": "10V", "gpNum": "24978", "topAccount": "VIKING", "gpType": "Primary",
    "region": "NAM", "soeid": "MK31857", "active": true, "source": "AQUA", "primary": true
},
{
    "groupId": 6, "relationId": 249364, "relation": "ADAGE", "gpNum": "53809", "topAccount": "ADAGE", "gpType": "Primary",
    "region": "APAC", "soeid": "MK31857", "active": true, "source": "AQUA", "primary": true
},
{
    "groupId": 5, "relationId": 166961, "relation": "ABSOLUTE INVESTMENT", "gpNum": "64245", "topAccount": "ABSOLUT",
    "gpType": "Primary", "region": "APAC", "soeid": "MK31857", "active": true, "source": "AQUA", "primary": true
}];

const regionList = [{ "value": "2", "text": "NAM" }, { "value": "3", "text": "APAC" }, { "value": "4", "text": "EMEA" }];

const userCovergaeHistoryLst=[{"id":0,"soeid":"AW11769","gp":"58826","gpname":"ADVENT","operation":"Added"},{"id":0,"soeid":"AW11769","gp":"07156","gpname":"BLACKROCK","operation":"Deleted"}];


describe('AdminEditService: User details for Manage access roles', () => {

    let adminEditService: AdminEditService;
    let backend: MockBackend;
    let http: JsonHttp;

    let router: Router;
    let refService: ReferenceDataService;
    let appState: AppStateService;
    let idle: IdleService;
    let emailRegExp= /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: Router,
                    useClass: MockRouter,
                },
                {
                    provide: ReferenceDataService,
                    useClass: MockReferenceDataService,
                },
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                {
                    provide: IdleService,
                    useClass: MockIdleService,
                },

                APP_TEST_HTTP_PROVIDERS,
                AdminEditService,
                AppConfig
            ],
        });
    });


    beforeEach(inject([AdminEditService, MockBackend, JsonHttp], (..._) => {
        [adminEditService, backend, http] = _;
    }));

    // --- Get user details service function testing start here---------------------------
    describe('getUserDetails: Load user details and his access ', () => {
        let subscription;
        describe('When data is available', () => {
            it('Is user data available ?', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: userDetails
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual('/api/adm/getEWSUser/AW11769');
                    expect(conn.request.json()).not.toBeTruthy();
                });
                adminEditService.getUserDetails("AW11769").subscribe((user) => {
                    expect(user).toBeDefined();
                });
            });
            it('Check all Fields matching properly !', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({ body: userDetails })));
                });

                adminEditService.getUserDetails("AW11769").subscribe((user) => {
                    expect(user.friendly_name).toEqual("Waste, Avinash");
                    expect(user.domain_name).toEqual("NAM\\AW11769");
                    expect(user.email).toMatch(emailRegExp);
                    expect(user.email).toEqual("avinash.guruling.waste@citi.com");
                    expect(user.soeid).toEqual("AW11769");
                    expect(user.race_role).toEqual("coverage_based");
                    expect(user.status).toEqual("ACTIVE    ");
                    expect(user.all_client).toBeFalsy();
                    expect(user.manage_alert).toBeTruthy();
                    expect(user.manage_alert_rule).toBeFalsy();
                    expect(user.add_admin).toBeFalsy();
                    expect(user.manage_coverage).toBeFalsy();
                });
            });
        });
        describe('When data is not available or exception occured', () => {
            let subscription = undefined;
            beforeEach(function () {
                subscription = backend.connections.subscribe(conn => {
                    conn.mockError(new MockError(new ResponseOptions(MockError.error_500)));
                });
            });
            afterEach(function () { subscription.unsubscribe(); });

            it('Data must be undefined and/or error should be defined!', () => {
                adminEditService.getUserDetails("AW11769").subscribe((user) => {
                    expect(user).toBeUndefined();
                }, (err) => {
                    expect(err).toBeDefined();
                });
            });
        });

    });
    // --- Get user details service function testing ends here---------------------------

    // --- Get user history service function testing start here---------------------------
    describe('getUserHistory: Load user history access ', () => {
        let subscription;
        describe('When data is available', () => {
            it('Is user history available ?', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: userHistoryDetails
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual('/api/adm/getUserHistory/MK31857');
                    expect(conn.request.json()).not.toBeTruthy();
                });
                adminEditService.getUserHistory("MK31857").subscribe((user) => {
                    expect(user).toBeDefined();
                });
            });
            it('Check all Fields matching properly !', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({ body: userHistoryDetails })));
                });

                adminEditService.getUserHistory("MK31857").subscribe((userHis) => {
                    expect(userHis.length).toBeGreaterThan(0);
                    let firstUserInfo=userHis[0];
                        expect(firstUserInfo.friendly_name).toEqual("Kishore, Mayank");
                        expect(firstUserInfo.domain_name).toEqual("NAM\\mk31857");
                        expect(firstUserInfo.email).toMatch(emailRegExp);
                        expect(firstUserInfo.email).toEqual("mayank.kishore@citi.com");
                        expect(firstUserInfo.soeid).toEqual("MK31857");
                        expect(firstUserInfo.race_role).toEqual("coverage_based");
                        expect(firstUserInfo.status).toEqual("ACTIVE    ");
                        expect(firstUserInfo.all_client).toBeFalsy();
                        expect(firstUserInfo.manage_alert).toBeTruthy();
                        expect(firstUserInfo.manage_alert_rule).toBeFalsy();
                        expect(firstUserInfo.add_admin).toBeFalsy();
                        expect(firstUserInfo.manage_coverage).toBeFalsy();
                        for(let user of userHis) {
                            expect(firstUserInfo.friendly_name).toEqual(user.friendly_name);
                            expect(firstUserInfo.domain_name).toEqual(user.domain_name);
                            expect(firstUserInfo.email).toEqual(user.email);
                            expect(firstUserInfo.soeid).toEqual(user.soeid);                        
                        }
                });
            });
        });
        describe('When data is not available or exception occured', () => {
            let subscription = undefined;
            beforeEach(function () {
                subscription = backend.connections.subscribe(conn => {
                    conn.mockError(new MockError(new ResponseOptions(MockError.error_500)));
                });
            });
            afterEach(function () { subscription.unsubscribe(); });

            it('Data must be undefined and/or error should be defined!', () => {
                adminEditService.getUserHistory("MK31857").subscribe((user) => {
                    expect(user).toBeUndefined();
                }, (err) => {
                    expect(err).toBeDefined();
                });
            });
        });

    });
    // --- Get user history service function testing ends here---------------------------

     // --- Get user coverage service function testing start here---------------------------
    describe('getUserCoverageList: Load user coverage access ', () => {
        let subscription;
        describe('When data is available', () => {
            it('Is user coverage available ?', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: userCoverage
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual('/api/adm/getUserCoverage/MK31857');
                    expect(conn.request.json()).not.toBeTruthy();
                });
                adminEditService.getUserCoverageList("MK31857").subscribe((user) => {
                    expect(user).toBeDefined();
                });
            });
            it('Check all Fields matching properly !', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({ body: userCoverage })));
                });

                adminEditService.getUserCoverageList("MK31857").subscribe((userHis) => {
                    expect(userHis.length).toBeGreaterThan(0);
                    let firstUserInfo=userHis[0];
                        expect(firstUserInfo.groupId).toEqual(2);
                        expect(firstUserInfo.relationId).toEqual(115347);
                        expect(firstUserInfo.relation).toEqual("398");
                        expect(firstUserInfo.soeid).toEqual("MK31857");
                        expect(firstUserInfo.gpNum).toEqual("12281");
                        expect(firstUserInfo.topAccount).toEqual("00398");
                        expect(firstUserInfo.gpType).toEqual("Primary")
                        expect(firstUserInfo.region).toEqual("NAM")
                        expect(firstUserInfo.active).toBeTruthy();
                        expect(firstUserInfo.source).toEqual("AQUA");
                        expect(firstUserInfo.primary).toBeTruthy();
                        for(let user of userHis) {
                            expect(firstUserInfo.source).toBe("AQUA"||"CUES");
                            expect(firstUserInfo.soeid).toEqual(user.soeid);                        
                        }
                });
            });
        });
        describe('When data is not available or exception occured', () => {
            let subscription = undefined;
            beforeEach(function () {
                subscription = backend.connections.subscribe(conn => {
                    conn.mockError(new MockError(new ResponseOptions(MockError.error_500)));
                });
            });
            afterEach(function () { subscription.unsubscribe(); });

            it('Data must be undefined and/or error should be defined!', () => {
                adminEditService.getUserCoverageList("MK31857").subscribe((user) => {
                    expect(user).toBeUndefined();
                }, (err) => {
                    expect(err).toBeDefined();
                });
            });
        });

    });
    // --- Get user coverage service function testing ends here---------------------------

    
     // --- Get user coverage list history service function testing start here---------------------------
    describe('getUserHistoryCoverageList: Load user coverage list history access ', () => {
        let subscription;
        let userRequest={created_time:"2017-01-23 09:01:14.597",operation:"Updated",soeid:"AW11769"};

        describe('When data is available', () => {
            it('Is user coverage list history available ?', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: userCovergaeHistoryLst
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual('/api/adm/UserCoverageHistory.json');
                    expect(conn.request.json()).toBeTruthy();
                });
                adminEditService.getUserHistoryCoverageList(userRequest).subscribe((user) => {
                    expect(user).toBeDefined();
                });
            });
            it('Check all Fields matching properly !', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({ body: userCovergaeHistoryLst })));
                });

                adminEditService.getUserHistoryCoverageList(userRequest).subscribe((covHis) => {
                    expect(covHis.length).toBeGreaterThan(0);
                    let firstCovHis=covHis[0];
                        expect(covHis.length).toEqual(2);
                        expect(firstCovHis.gp).toEqual("58826");
                        expect(firstCovHis.gpname).toEqual("ADVENT");
                        expect(firstCovHis.soeid).toEqual("AW11769");
                        expect(firstCovHis.operation).toEqual("Added");
                       
                        for(let user of covHis) {
                            expect(firstCovHis.soeid).toEqual(user.soeid);                        
                        }
                });
            });
        });
        describe('When data is not available or exception occured', () => {
            let subscription = undefined;
            beforeEach(function () {
                subscription = backend.connections.subscribe(conn => {
                    conn.mockError(new MockError(new ResponseOptions(MockError.error_500)));
                });
            });
            afterEach(function () { subscription.unsubscribe(); });

            it('Data must be undefined and/or error should be defined!', () => {
                adminEditService.getUserHistoryCoverageList(userRequest).subscribe((user) => {
                    expect(user).toBeUndefined();
                }, (err) => {
                    expect(err).toBeDefined();
                });
            });
        });

    });
    // ---  Get user coverage list history service function testing ends here---------------------------

    // --- Get client coverage list service function testing start here---------------------------
    describe('getClientCoverageList: Load client covergae List ', () => {
        let subscription;

        describe('When data is available', () => {
            it('Is client coverage list history available ?', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: clientCoverageList
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual('/api/adm/getClientCoverageList/');
                    expect(conn.request.json()).not.toBeTruthy();
                });
                adminEditService.getClientCoverageList().subscribe((user) => {
                    expect(user).toBeDefined();
                });
            });
            it('Check all Fields matching properly !', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({ body: clientCoverageList })));
                });

                adminEditService.getClientCoverageList().subscribe((clientCoverageList) => {
                     expect(clientCoverageList.length).toBeGreaterThan(0);
                    let firstUserInfo=clientCoverageList[0];
                        expect(firstUserInfo.groupId).toEqual(1);
                        expect(firstUserInfo.relationId).toEqual(116345);
                        expect(firstUserInfo.relation).toEqual("10V");
                        expect(firstUserInfo.soeid).toBeNull();
                        expect(firstUserInfo.gpNum).toEqual("24978");
                        expect(firstUserInfo.topAccount).toBeNull();
                        expect(firstUserInfo.gpType).toEqual("Primary")
                        expect(firstUserInfo.region).toBeNull();
                        expect(firstUserInfo.active).toBeFalsy();
                        expect(firstUserInfo.source).toBeNull();
                        expect(firstUserInfo.primary).toBeFalsy();
                });
            });
        });
        describe('When data is not available or exception occured', () => {
            let subscription = undefined;
            beforeEach(function () {
                subscription = backend.connections.subscribe(conn => {
                    conn.mockError(new MockError(new ResponseOptions(MockError.error_500)));
                });
            });
            afterEach(function () { subscription.unsubscribe(); });

            it('Data must be undefined and/or error should be defined!', () => {
                adminEditService.getClientCoverageList().subscribe((user) => {
                    expect(user).toBeUndefined();
                }, (err) => {
                    expect(err).toBeDefined();
                });
            });
        });

    });
    // --- Get client coverage list service function testing ends here---------------------------

    // --- Get region list service function testing start here---------------------------
    describe('getRegions: Load regions List ', () => {
        let subscription;

        describe('When data is available', () => {
            it('Is regions list available ?', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: regionList
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual('/api/adm/geRegions.json/');
                    expect(conn.request.json()).not.toBeTruthy();
                });
                adminEditService.getRegions().subscribe((user) => {
                    expect(user).toBeDefined();
                });
            });
            it('Check all Fields matching properly !', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({ body: regionList })));
                });

                adminEditService.getRegions().subscribe((dropDownList) => {
                     expect(dropDownList.length).toBeGreaterThan(0);
                    let dropDown=dropDownList[0];
                        expect(dropDown.text).toEqual("NAM");
                        expect(dropDown.value).toEqual("2");
                });
            });
        });
        describe('When data is not available or exception occured', () => {
            let subscription = undefined;
            beforeEach(function () {
                subscription = backend.connections.subscribe(conn => {
                    conn.mockError(new MockError(new ResponseOptions(MockError.error_500)));
                });
            });
            afterEach(function () { subscription.unsubscribe(); });

            it('Data must be undefined and/or error should be defined!', () => {
                adminEditService.getRegions().subscribe((user) => {
                    expect(user).toBeUndefined();
                }, (err) => {
                    expect(err).toBeDefined();
                });
            });
        });

    });
    // --- Get regions list service function testing ends here---------------------------

    // --- update user coverage list service function testing start here---------------------------
    describe('updateUser: Update user coverage List ', () => {
        let subscription;
         let reqObj={all_client:0,gpnum:"2:NAM,6:NAM,7:APAC,5:APAC,130:APAC",role:"coverage_based",soeid:"AW11769"};
        describe('When data is updated', () => {
            it('Is update successfully ?', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: true
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual('/api/adm/UpdateUserRole');
                    let reqObj=conn.request.json();
                    expect(reqObj).toBeDefined();
                    expect(reqObj['all_client']).toEqual(0);
                    expect(reqObj['gpnum']).toEqual('2:NAM,6:NAM,7:APAC,5:APAC,130:APAC');
                    expect(reqObj['role']).toEqual('coverage_based');
                    expect(reqObj['soeid']).toEqual('AW11769');
                });
                adminEditService.updateUser(reqObj).subscribe((res) => {
                    expect(res).toBeTruthy();
                });
            });
        });
        describe("When data doesn't update or exception occured", () => {
            let subscription = undefined;
            beforeEach(function () {
                subscription = backend.connections.subscribe(conn => {
                    conn.mockError(new MockError(new ResponseOptions(MockError.error_500)));
                });
            });
            afterEach(function () { subscription.unsubscribe(); });

            it('False must be received and/or error should be defined!', () => {
                adminEditService.updateUser(reqObj).subscribe((res) => {
                    expect(res).toBeFalsy();
                }, (err) => {
                    expect(err).toBeDefined();
                });
            });
        });

    });
    // --- update user coverage list service function testing ends here---------------------------
});