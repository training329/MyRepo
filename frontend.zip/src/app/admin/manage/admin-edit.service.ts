// Framework
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Response} from '@angular/http';
import "../../common/rxjs-operators";

// Application models
import { APIResponse } from '../../models/api-response';
import { ExceptionUser } from '../../models/exception-user';
import { DropDownModel } from '../../models/dropdown-model';
import { EWSUser } from '../../models/ews-user';
import { Coverage } from '../../models/coverage';
import { AppConfig } from '../../common/app.config';

// Application services
import {JsonHttp} from "../../services/json-http";
import {HttpErrorHandler} from "../../services/http-error-handler";

// Service END Point URL should be declared as SERVICE END POINT
const getUserHistoryURI: string = "/getUserHistory/";
const getUserDetails: string = "/getEWSUser/";
const getUserCoverageList: string = "/getUserCoverage/";
const getClientCoverageList: string = "/getClientCoverageList/";
const getUserHistoryCoverageList: string = "/UserCoverageHistory.json";
const updateUser: string = "/UpdateUserRole";
const getRegions: string = "/geRegions.json/";

@Injectable()
export class AdminEditService {

    constructor( private http: JsonHttp,
    			private errorHandler: HttpErrorHandler,
    			public appConfig: AppConfig ) { 
        console.debug('AdminEditService::constructor');
    }
    
    getUserDetails(userId:String):Observable<EWSUser> {
    	console.debug('AdminEditService::getUserDetails ', userId);
        return this.http.get(this.appConfig.API + this.appConfig.ADMIN_EP + getUserDetails + userId)
                    .map(res => res.json());
    }

    getUserHistory(userId:String):Observable<EWSUser[]> {
    	console.debug('AdminEditService::getUserHistory ', userId);
        return this.http.get(this.appConfig.API + this.appConfig.ADMIN_EP + getUserHistoryURI + userId)
                    .map(res => res.json());
    }

    getUserCoverageList(userId:String):Observable<ExceptionUser[]> {
    	console.debug('AdminEditService::getUserCoverageList', userId);
        return this.http.get(this.appConfig.API + this.appConfig.ADMIN_EP + getUserCoverageList + userId)
                    .map(res => res.json());
    }
    
    getUserHistoryCoverageList(userRequest): Observable<Coverage[]> {
    	console.debug('AdminEditService::getUserHistoryCoverageList: ', userRequest);
        return this.http.post(this.appConfig.API + this.appConfig.ADMIN_EP + getUserHistoryCoverageList, userRequest)
                    .map(res => res.json());
    }

    getClientCoverageList():Observable<ExceptionUser[]> {
    	console.debug('AdminEditService::getClientCoverageList');
        return this.http.get(this.appConfig.API + this.appConfig.ADMIN_EP + getClientCoverageList)
                    .map(res => res.json());
    }

    updateUser(userSaveObj:any): Observable<APIResponse> {
    	console.debug('AdminEditService::updateUser', userSaveObj);
        return this.http.post(this.appConfig.API + this.appConfig.ADMIN_EP + updateUser, userSaveObj)
            .map(res => res.json());
    }

    getRegions():Observable<DropDownModel[]> {
    	console.debug('AdminEditService::getRegions');
        return this.http.get(this.appConfig.API + this.appConfig.ADMIN_EP + getRegions)
                    .map(res => res.json());
    }
}
