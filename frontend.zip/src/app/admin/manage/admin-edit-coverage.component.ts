// Framework
import {Component, OnInit, Output, Input, ViewChild, EventEmitter} from "@angular/core";
import { DataTable } from 'primeng/primeng';

import * as _ from 'underscore';
import * as toastr from 'toastr';

// Application Component
import {HttpErrorHandler} from "../../services/http-error-handler";
import {AdminEditService} from './admin-edit.service';
import {UtilService} from "./../../services/util.service";

//Application Shared
import {SelectItem} from './../../common/api';
import {DropDownModel} from './../../models/dropdown-model';
import {ExceptionUser} from './../../models/exception-user';
import {EWSUser} from './../../models/ews-user';

@Component({
	selector: 'admin-edit-coverage', 
	styleUrls:['../admin.component.scss'],
	templateUrl:'./admin-edit-coverage.html',        
})

export class AdminEditCoverageComponent implements OnInit {

    @Input() user : EWSUser;
    
    @Output() onCoverageUpdate : EventEmitter<{event: any}> = new EventEmitter<{event: any}>();
    
    @ViewChild('aquaCoverageTab') aquaCoverageTab;

    private aquaCoverageList : Array<ExceptionUser> = [];
    private cuesCoverageList : Array<ExceptionUser> = [];
    private clientCoverageList : Array<SelectItem> = [];
    private selectedCoverage : ExceptionUser = null;
    private regionList : Array<DropDownModel> = [];
    private coverageCols : any[];
    private cuesCols : any[];
    
    totalPages : number;
    totalRecords : number = 0;
    page : number;    
    selectedRegion : string = "";
    
    @ViewChild('cuesdt') cuesCoverageTable : DataTable;
    @ViewChild('aquadt') aquaCoverageTable : DataTable;
    
    constructor(private errorHandler : HttpErrorHandler,
    			private adminEditService : AdminEditService,
    			private utilService:UtilService) {
    	console.debug('AdminEditCoverageComponent::constructor');
        this.coverageCols = [
            { header: 'GP', field: 'gpNum', style:{ 'text-align':'left'} },
            { header: 'Relation', field: 'relation', style:{ 'text-align':'left'} },
            { header: 'Region', field: 'region', style:{ 'text-align':'left'} },
            { header: 'Role', field: 'gpType', style:{ 'text-align':'left'} },
            { header: 'Active', field: 'active', style:{ 'text-align':'left'} },
            { header: 'Manage', field: 'manage', style:{ 'text-align':'left'} }
        ];

        this.cuesCols = [
            { header: 'GP', field: 'gpNum', style:{ 'text-align':'left'} },
            { header: 'Relation', field: 'relation', style:{ 'text-align':'left'} },
            { header: 'Top Account', field: 'topAccount', style:{ 'text-align':'left'} },
            { header: 'Region', field: 'region', style:{ 'text-align':'left'} },
            { header: 'Role', field: 'gpType', style:{ 'text-align':'left'} }
        ];
        this.clientCoverageList.push({label: "Select Coverage", value: null}); 
            // Just to avoid screen flickering, Due to width issue in PrimeNG

    }

    ngOnInit(){
        console.debug('AdminEditCoverageComponent::ngOnit:', this.user);
        this.getClientCoverageList();
        this.getUserCoverageList();
        this.getRegionList();
    }

    getClientCoverageList(): void {
        console.debug("AdminEditCoverageComponent::getClientCoverageList");
        this.adminEditService.getClientCoverageList().subscribe(cvgLst => {
        	this.clientCoverageList = [];
        	this.clientCoverageList.push({label: "Select Coverage", value: null});
            for (let cvg of cvgLst) {
            	var labelVal = cvg.gpNum + " - " + cvg.relation;
                this.clientCoverageList.push({label: labelVal, value: cvg});
            }
        }, e => this.errorHandler.handle(e));
    }
    
    getUserCoverageList(): void {
        console.debug("AdminEditCoverageComponent::getUserCoverageList");
        this.adminEditService.getUserCoverageList(this.user.soeid).subscribe(excpUserLst => {
            this.aquaCoverageList = _.filter(excpUserLst, function(item) {
										return item.source == 'AQUA'
									});
			this.cuesCoverageList = _.filter(excpUserLst, function(item) {
										return item.source == 'CUES'
									});
			this.utilService.showNoRecordMessage(this.aquaCoverageTable, (this.aquaCoverageList ? this.aquaCoverageList.length : 0));
			this.utilService.showNoRecordMessage(this.cuesCoverageTable, (this.cuesCoverageList ? this.cuesCoverageList.length : 0));
        }, e => {
			toastr.error('Error while getting user coverage details. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }

    getRegionList(): void {
        console.debug("AdminEditCoverageComponent::getRegionList");
        this.adminEditService.getRegions().subscribe(regionList => {
        	this.regionList = regionList;
        }, e => {
			toastr.error('Error while getting regions. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }

    addClientCoverage() {
    	console.debug("AdminEditCoverageComponent::addClientCoverage");
    	var isNewCoverage : boolean = true;
    	// Following temp variables are required, as underscore library cannot get class level variable access in it's apis 
    	var tmpSelectedCoverage = _.clone(this.selectedCoverage);
    	var tmpSelectedRegion = this.selectedRegion;
    	// Check if selected coverage is already present in Cues or Aqua Coverage list
    	// if present _.find() will return matching coverage from list 
    	var existingAquaCoverage = _.find(this.aquaCoverageList, function(coverage) {
 			return (coverage.relationId + coverage.region) == (tmpSelectedCoverage.relationId + tmpSelectedRegion);
 		});
        var existingCuesCoverage = _.find(this.cuesCoverageList, function(coverage) {
 			return (coverage.relationId + coverage.region) == (tmpSelectedCoverage.relationId + tmpSelectedRegion);
 		});
        if (existingAquaCoverage || existingCuesCoverage) {
        	isNewCoverage = false;        	
        }        
        if (isNewCoverage) {
        	tmpSelectedCoverage.region = tmpSelectedRegion;
        	tmpSelectedCoverage.active = true;
        	this.aquaCoverageList.push(tmpSelectedCoverage);
        	this.notifyCoverageUpdate();
        	this.toggleToAquaCoverageTab();
        } else {
        	toastr.error('Coverage client is already added', 'Error');
        }
        this.selectedCoverage = null;
    	this.selectedRegion = "";
    }
    
    toggleToAquaCoverageTab() {
    	console.debug("AdminEditCoverageComponent::toggleToAquaCoverageTab");
    	this.aquaCoverageTab.nativeElement.parentNode.click();
    }
    
    removeCoverage(coverage : any) {
    	console.debug("AdminEditCoverageComponent::removeCoverage ", coverage);
        this.aquaCoverageList = _.reject(this.aquaCoverageList, function(val) {
			return (val.groupId == coverage.groupId && val.region == coverage.region);
		});
        this.notifyCoverageUpdate();
    }
    
    getCoverageSelection() : string {
    	console.debug("AdminEditCoverageComponent::getCoverageSelection");
        return this.aquaCoverageList.map(coverage => {return coverage.groupId + ":" + coverage.region}).join(",");
    }
    
    notifyCoverageUpdate() {
    	console.debug("AdminEditCoverageComponent::notifyCoverageUpdate");
    	this.onCoverageUpdate.next({event : null});
    }

}