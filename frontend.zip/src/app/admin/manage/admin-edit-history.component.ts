import { Component, OnInit, OnDestroy, Input, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { DataTable } from 'primeng/primeng';

//Application models
import { Coverage } from './../../models/coverage';
import { EWSUser } from './../../models/ews-user';

//Application Shared
import { SelectItem } from './../../common/api';

import * as toastr from 'toastr';

//Application Services
import { AdminEditService } from './admin-edit.service';
import { AdminService } from './../admin.service';
import { HttpErrorHandler } from './../../services/http-error-handler';
import { UtilService } from "./../../services/util.service";

@Component({
	selector: 'admin-edit-history',
	styleUrls:['../admin.component.scss'],
	templateUrl: './admin-edit-history.html',
	providers: [HttpErrorHandler]
})

export class AdminEditHistoryComponent implements OnInit {
	
	@Input() userId : string;
	
    private userHistory:EWSUser[];
	private userCovergareHistory: Coverage[] = [];   
	private display: boolean; 
	
	cols: any[] = [];
    columnOptions: SelectItem[] = [];
    totalPages: number;
    totalRecords: number = 0;
    page: number;
	
	@ViewChild('dt') userHistoryTable : DataTable;

    constructor( private router: Router,
    			private errorHandler: HttpErrorHandler,
    			private route: ActivatedRoute,
    			private adminEditService: AdminEditService,
    			private utilService:UtilService) {
    	console.debug('AdminEditHistoryComponent::constructor');
        this.cols = [
            { header: 'Domain', field: 'domain_name', style:{'text-align':'left'}  },
            { header: 'Role', field: 'race_role', style:{'text-align':'left'}  },
            { header: 'Updated By', field: 'created_by', style:{'text-align':'left'}  },
            { header: 'Updated Time', field: 'created_time', style:{'text-align':'left'}  },
            { header: 'All Clients', field: 'all_client', style:{'text-align':'left'}  },
            { header: 'Manage Alert', field: 'manage_alert', style:{'text-align':'left'}  },
            { header: 'Manage Rule', field: 'manage_alert_rule', style:{'text-align':'left'}  },
            { header: 'Add Admin', field: 'add_admin', style:{'text-align':'left'}  },
            { header: 'Manage Coverage', field: 'manage_coverage', style:{'text-align':'left'}  },
            { header: 'Coverage', field: 'coverage', style:{'text-align':'left'}  },
        ];

        this.columnOptions = [];
        for ( let i = 0; i < this.cols.length; i++ ) {
            this.columnOptions.push( { label: this.cols[i].header, value: this.cols[i] });
        }          
    }

    ngOnInit() {
        console.debug('AdminEditHistoryComponent::ngOnInit');
        this.getUserHistory();
    }

    getUserHistory() {
    	console.debug('AdminEditHistoryComponent::getUserHistory ', this.userId);
    	this.adminEditService.getUserHistory(this.userId).subscribe(userHistory => {
            this.userHistory = userHistory;
            this.utilService.showNoRecordMessage(this.userHistoryTable, (this.userHistory ? this.userHistory.length : 0));
        }, e => {
			toastr.error('Error while getting EWS User history details. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }
    
    refreshHistory() {
    	console.debug('AdminEditHistoryComponent::refreshHistory');
    	this.getUserHistory();
    }

    private showCoverage(userHistory: any): void {
        console.debug('AdminEditHistoryComponent::showCoverage' , userHistory);        
		let request = {
				soeid: userHistory.soeid,
				operation: userHistory.operation,
				created_time: userHistory.created_time_db
		}
        
    	this.adminEditService.getUserHistoryCoverageList(request).subscribe(userCovergareHistory => {
            this.userCovergareHistory = userCovergareHistory;
            this.display = true;
        }, e => {
			toastr.error('Error while getting EWS User coverage history details. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }
    
    getHistoryDataTableRef() : DataTable {
    	console.debug('AdminEditHistoryComponent::getHistoryDataTableRef');
    	return this.userHistoryTable;
    }

}
