// Framework
import {Component, ElementRef, OnInit, OnDestroy, ViewChild, Output, EventEmitter} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {NgForm} from '@angular/forms';
import {Subscription} from 'rxjs/Subscription';

// Application Component
import {EWSUser} from '../../models/ews-user';
import {HttpErrorHandler} from "../../services/http-error-handler";
import {AdminService} from "../admin.service";
import {AdminEditService} from './admin-edit.service';
import {LoginService} from './../../services/login.service';

// Application Shared
import {SelectItem} from '../../common/api';
import {UserRole} from '../../shared/dto';

import * as toastr from 'toastr';

@Component({
	selector: 'admin-edit',
	styleUrls:['../admin.component.scss'],
	templateUrl: './admin-edit.component.html',
	providers: [HttpErrorHandler]
})
export class AdminEditComponent implements OnDestroy {
	
	private sub : Subscription;
	private formChangeSubScription : Subscription;
  	private userId : string = "";
  	private user : EWSUser;
  	private userOrg : EWSUser;
  	private userRole : UserRole = new UserRole();
  	private isChange : boolean = false;
  	private coverageSelection : string;
  	private manageUserForm :  NgForm;
  	private submitted = false;
  	private isLoggedInUserSelfEdit : boolean = false;
  	private isAdminUser : boolean = false;
  	private curLoggedInUser : string = "";
	private curLoggedInUserRole : string = "";

  	@ViewChild('manageUserForm') currentForm : NgForm;
  	@ViewChild('admEditHistory') admEditHistory : any;
  	@ViewChild('admEditCoverage') admEditCoverage : any;
  	
  	constructor(private router : Router,
              	private errorHandler : HttpErrorHandler,
              	private route :  ActivatedRoute,
              	private adminEditService : AdminEditService,
    			private loginService : LoginService,
    			private adminService : AdminService) {
  		console.debug("AdminEditComponent::constructor");
  		this.sub = this.route.params.subscribe( params => {
  			this.userId = params['id'];
  			this.checkRoleEditAccess();
  		});
  		this.getUserDetails();
  	}

  	ngOnDestroy() {
  		console.debug("AdminEditComponent::ngOnDestroy");
  		this.sub.unsubscribe();
  		if (this.formChangeSubScription) {
  			this.formChangeSubScription.unsubscribe();
  		}  		
  	}

  	formChanged() {
    	console.debug('AdminEditComponent::formChanged');
    	if ( this.currentForm === this.manageUserForm ) { return; }
    	this.manageUserForm = this.currentForm;
    	if ( this.manageUserForm ) {
    		this.formChangeSubScription = this.manageUserForm.valueChanges
    		.subscribe( data => this.onValueChanged( data ) );
    	}
    }

    onValueChanged( data?: any ) {
    	console.debug('AdminEditComponent::onValueChanged ', data);
    	if (!this.manageUserForm) { return; }
    	if (this.manageUserForm && this.userOrg) {
    		if (!_.isEqual(this.user, this.userOrg)) {
    			this.isChange = true;
    		} else {
    			this.isChange = false;
    		}
    	}
    }

    getUserDetails() {
    	console.debug("AdminEditComponent::getUserDetails ", this.userId);
    	this.adminEditService.getUserDetails(this.userId).subscribe(user => {
            this.user = user;
            this.userOrg = Object.assign({}, this.user);
			// add form change listener, when form is completely loaded 
            setTimeout(() => {
                   this.formChanged();
            }, 1000);
            this.resizeHistoryDataTable(this.user.race_role);
        }, e => {
			toastr.error('Error while getting EWS user details. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }

    userRoleChanged (value) {
    	console.debug("AdminEditComponent::userRoleChanged ", value, this.user.race_role);
	    switch (value) {
	    	case this.userRole.GLOBAL_ADMIN:
	    			this.user.all_client = true;
	                this.user.manage_alert = true;
	                this.user.manage_alert_rule = true;
	                this.user.add_admin = true;
	                this.user.manage_coverage = true;
	                break;
	      case this.userRole.ADMIN:
	                this.user.all_client = true;
	                this.user.manage_alert = true;
	                this.user.manage_alert_rule = true;
	                this.user.add_admin = false;
	                this.user.manage_coverage = true;
	                break; 
	      case this.userRole.COVERAGE:
	                this.user.all_client = false;
	                this.user.manage_alert = true;
	                this.user.manage_alert_rule = false;
	                this.user.add_admin = false;
	                this.user.manage_coverage = false;        
	                break;
	      case this.userRole.VIEW_ONLY:
	                this.user.all_client = true;
	                this.user.manage_alert = false;
	                this.user.manage_alert_rule = false;
	                this.user.add_admin = false;
	                this.user.manage_coverage = false;
	                break;        
	      default:  break;
	    }
	    this.resizeHistoryDataTable(value);
    }
    
    resizeHistoryDataTable(userRole) {
    	console.debug("AdminEditComponent::resizeHistoryDataTable ", userRole);
    	var userHistoryTableRef = this.admEditHistory.getHistoryDataTableRef();
    	if (userRole == this.userRole.COVERAGE) {
    		userHistoryTableRef.rows = 5;
    		userHistoryTableRef.reset();
    	} else {
    		userHistoryTableRef.rows = 12;
    		userHistoryTableRef.reset();
    	}    	
    }

    save( formModel: any, isValid: boolean ): boolean {
    	console.debug("AdminEditComponent::save ", formModel, isValid);
    	if (this.user.race_role == this.userRole.COVERAGE) {
    		this.coverageSelection = this.admEditCoverage.getCoverageSelection();
    	}
    	let saveObj = {
						'soeid' : this.user.soeid,
						'role' : this.user.race_role,
						'all_client' : 0,
						'gpnum' : this.coverageSelection,
						'updatedby' : this.curLoggedInUser
					};     
    	this.adminEditService.updateUser(saveObj).subscribe(resp => {
    		if (resp) {
    			toastr.success('User role updated successfully.', 'Success');
    			this.isChange = false;
    			this.getUserDetails();
    			this.admEditHistory.refreshHistory();
    			this.adminService.clearCache();
    		} else {
    			toastr.error('Error while updating User Role/Coverage. Please try again or contact AQUA RACE support.', 'Error');
    		}
    	}, e => {
    		toastr.error('Error while updating User Role/Coverage. Please try again or contact AQUA RACE support.', 'Error');
			this.errorHandler.handle(e);
		});     
    	return false;
    }
    
    checkRoleEditAccess() {
    	console.debug("AdminEditComponent::checkRoleEditAccess");
    	this.curLoggedInUser = this.loginService.getUserSoeId();
    	this.curLoggedInUserRole = this.loginService.getUserRole();
    	if (this.userId == this.curLoggedInUser) {
    		this.isLoggedInUserSelfEdit = true;
    	}
    	if (this.curLoggedInUserRole == this.userRole.ADMIN) {
    		this.isAdminUser = true;
    	}
    }
}