// Framework
import {Component, ElementRef, OnInit, Input, ViewChild, SimpleChange, OnDestroy} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {ChartModule} from 'angular2-highcharts';
import {DataTable} from 'primeng/primeng';
import {Subscription} from 'rxjs/Subscription'
import * as toastr from 'toastr';

// Application Component
import {Alert} from '../models/alert';
import {HttpErrorHandler} from "../services/http-error-handler";
import {AlertSummaryService} from "./alert-summary.service";
import {UtilService} from "../services/util.service";
import {AppStateService} from "../services/app-state.service";

// Application Shared
import {SelectItem} from '../common/api';

@Component({
    selector: 'cba-resolved-alerts',
    styleUrls: ['./alert-summary.component.scss'],
    templateUrl: './resolved-alerts.component.html',
    providers: [HttpErrorHandler]
})
export class ResolvedAlertsComponent implements OnInit, OnDestroy {
    cols:any[] = [];
    columnOptions:SelectItem[] = [];
    totalPages:number;
    page:number;
    toggleColumn:string = "Toggle Columns";

    private alertsSubscription:Subscription;
    private alerts:Array<Alert>;
    private emptyMessage : string = "";

    @ViewChild('dt') dt : DataTable;
    
    constructor(private router:Router,
                private errorHandler:HttpErrorHandler,
                private route:ActivatedRoute,
                private alertSummaryService:AlertSummaryService,
                private appStateService:AppStateService) {

        console.debug('ResolvedAlertsComponent::constructor');

        this.cols = [
            {header: 'ALERT#', field: 'exception_id', style: {'width': '4%', 'text-align': 'left'}, sortable:true},
            {header: 'COB DATE', field: 'cob_date', style: {'width': '5%', 'text-align': 'left'}, sortable:true},
            {header: 'CLOSED DATE', field: 'create_time', style: {'width': '6%', 'text-align': 'left'}, sortable:true},
            {header: 'AGE', field: 'age', style: {'width': '4%', 'text-align': 'center'}, sortable:true},
            {header: 'CLIENT/FUND', field: 'client', style: {'width': '8%', 'text-align': 'left'}, sortable:true},
            {header: 'REGION', field: 'region', style: {'width': '4%', 'text-align': 'left'}, sortable:true},
            {header: 'DATA TYPE', field: 'measure', style: {'width': '8%', 'text-align': 'left'}, sortable:true},
            {header: 'PERIOD', field: 'rule_period', style: {'width': '8%', 'text-align': 'left'}, sortable:true},
            {header: 'TIER', field: 'clientTier', style: {'width': '5%', 'text-align': 'left'}, sortable:true},
            {header: 'THRESHOLD', field: 'limit', style: {'width': '6%', 'text-align': 'right'}, sortable:false},
            {header: 'COB VALUE', field: 'first_value', style: {'width': '6%', 'text-align': 'right'}, sortable:false},
            {header: 'PREV VALUE', field: 'second_value', style: {'width': '6%', 'text-align': 'right'}, sortable:false},
            {header: 'CHANGE', field: 'delta', style: {'width': '5%', 'text-align': 'right'}, sortable:false},
            {header: '% CHANGE', field: 'delta_percent', style: {'width': '5%', 'text-align': 'right'}, sortable:false},
            {header: 'ALERT OWNER', field: 'exception_owner_name', style: {'width': '11%', 'text-align': 'left'}, sortable:true}
        ];


        this.columnOptions = [];
        for (let i = 0; i < this.cols.length; i++) {
            this.columnOptions.push({label: this.cols[i].header, value: this.cols[i]});
        }
    }

    updateLabel() {
        console.debug('ResolvedAlertsComponent::updateLabel');
    }

    ngOnInit() {
        console.debug('ResolvedAlertsComponent::ngOnInit');
        this.listCached(1);
    }
    
    private listCached(page:number) {
        console.debug('ResolvedAlertsComponent::listCached: ', 'subscribing to alertSummaryService.isReady');
        this.alertsSubscription = this.alertSummaryService.getDataNotification()
            .subscribe(isReady => {
                console.debug('ResolvedAlertsComponent::listCached: ', 'subscriptions completed', isReady);
                if(isReady){
                    this.alerts = this.alertSummaryService.getAlertsClosed();
                    this.emptyMessage = (this.alerts && this.alerts.length == 0) ? UtilService.noRecordsFoundMessage : "";
                    setTimeout(() => {
                        let currentpage = this.appStateService.getModuleComponentState('datatable', 'currentpage')
                        if(currentpage)
                            this.setCurrentPage(Number(currentpage));
                        this.appStateService.activateModuleState();
                    }, 300);
                }    
            }, e => {
    			toastr.error('Error while getting alerts data. Please try again or contact AQUA RACE support', 'Error');
    			this.errorHandler.handle(e);
    		});
    }
    
    onPageChange(event) {
        if (this.dt.rows) {
            console.debug("ResolvedAlertsComponent::onPageChange on page ", event.first / event.rows + " event ", event);
            this.appStateService.setModuleComponentState('datatable', 'currentpage', event.first / event.rows);
        }
    }

    setCurrentPage(n:number) {
        console.debug("ResolvedAlertsComponent::setCurrentPage page ", n + "dt rows" + this.dt.rows);
        if (this.dt.rows) {
            let paging = {
                first: (n * this.dt.rows),
                rows: this.dt.rows
            };

            console.debug("ResolvedAlertsComponent::setCurrentPage  paging", paging + " page ", n);
            this.dt.paginate(paging);
        }
        //this.dt.sortField = "cob_date";
        //this.dt.sortOrder = -1;  
    }
    
    onRowDblclick(event) {
        console.debug("ResolvedAlertsComponent::onRowDblclick event ",event);
        this.router.navigate(['alerts/summary/alert-item', event.data.exception_id]);
    }
    
    ngOnDestroy() {
        console.debug('ResolvedAlertsComponent::ngOnDestory: ');
        this.alertsSubscription.unsubscribe();
    }

}

