import {inject, TestBed} from "@angular/core/testing";
import {ResponseOptions, Response, RequestMethod, HttpModule} from "@angular/http";
import {MockBackend} from "@angular/http/testing";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../testing";

import {AlertSummaryService} from "./alert-summary.service";
import {JsonHttp} from "../services/json-http";
import {AppStateService} from  "../services/app-state.service";
import {HttpErrorHandler} from "../services/http-error-handler";
import {UtilService} from "../services/util.service";
import {Alert} from '../models/alert';

import {MockAppStateService, MockHttpErrorHandler, MockUtilService} from '../testing/mock.services';

import * as _ from 'underscore';

//Service END Point URL should be declared as SERVICE END POINT
const serviceURI = '/api/exceptionsummary/flaggedexceptionlist.json?page=1&size=5';

describe('AlertSummaryService', () => {

    let alertSummaryService: AlertSummaryService;
    let backend: MockBackend;
	let appStateService: AppStateService;
	let utilService: UtilService;

	let myAlert : any = {"rule_id":"553","rule_group_id":"2303","exception_activity_id":"259468","exception_id":258975,"version_id":null,"type":"Global (All Client)","priority":"High","priority_id":"1",
						"legal_entity":"ALL","client":"10V","region":"GLOBAL","fund":"ALL","country":"country","product":"product","rule_period":"Vs Prior 30Days AVG","aggregation_level":"Client",
						"aggregation_level_name":null,"description":"Gross ROA Prior 30 Day Check","measure":"Gross ROA","limit_type":null,"limit":"50bps","is_active":null,"threshold_type":null,
						"create_user":"sw17383","create_time":"2017-02-06 13:25:06.98","cob_date":"2017-02-03 00:00:00.0","open_date":"2017-02-06 00:00:00.0","status":"1","status_name":"Open","age":1,
						"comment":null,"file_name":null,"attachements":null,"exception_owner":"1","updatedby":"NAM\\pfmis_admin_uat","first_date":"2017-02-03 00:00:00.0","first_value":"309bps",
						"second_date":"2017-02-02 00:00:00.0","second_value":"203bps","delta":"106bps","delta_percent":"52","exception_owner_name":"10V CE Group","client_fund":"10V","is_security":false,
						"clientTier":"1-PLATINUM","is_primary":true,"is_clientgroup":true,"nam":" Aaronson, Jay (ja48224)","emea":null,"apac":null,"nam_aqua":" Kishore, Mayank (mk31857)","emea_aqua":null,
						"apac_aqua":null};
	let openAlert : any = {"rule_id":"482","rule_group_id":"2272","exception_activity_id":"258482","exception_id":257923,"version_id":null,"type":"Global (All Client)","priority":"Low","priority_id":"1",
						"legal_entity":"ALL","client":"398","region":"GLOBAL","fund":"ALL","country":"country","product":"product","rule_period":"Vs Prior 30Days AVG","aggregation_level":"Client",
						"aggregation_level_name":null,"description":"Country Of Risk security level 30 day average rule","measure":"GMV(Country of Risk)","limit_type":null,"limit":"100.0m","is_active":null,
						"threshold_type":null,"create_user":"sw17383","create_time":"2017-02-06 10:30:32.147","cob_date":"2017-02-03 00:00:00.0","open_date":"2017-02-06 00:00:00.0","status":"1",
						"status_name":"Open","age":1,"comment":null,"file_name":null,"attachements":null,"exception_owner":"2","updatedby":"NAM\\pfmis_admin_uat","first_date":"2017-02-03 00:00:00.0",
						"first_value":"1623.5m","second_date":"2017-02-02 00:00:00.0","second_value":"2764.4m","delta":"-1140.9m","delta_percent":"41","exception_owner_name":"398 CE Group","client_fund":"398",
						"is_security":false,"clientTier":"3-CORE","is_primary":false,"is_clientgroup":true,"nam":" Seedorf, Matthew (ms75707)","emea":null,"apac":null,
						"nam_aqua":" Kishore, Mayank (mk31857) | Kohlhase, Brittany (bk13938) | Mason, Lawrence (lm72090) | Waste, Avinash (aw11769)","emea_aqua":null,"apac_aqua":" Mason, Lawrence (lm72090)"};

	let resolvedAlert : any = {"rule_id":"543","rule_group_id":"2270","exception_activity_id":"258676","exception_id":258117,"version_id":null,"type":"Global (All Client)","priority":"Undefined","priority_id":"1",
						"legal_entity":"ALL","client":"10V","region":"GLOBAL","fund":"ALL","country":"country","product":"product","rule_period":"Vs Prior COB","aggregation_level":"Client",
						"aggregation_level_name":null,"description":"","measure":"GMV(Security Sector)","limit_type":null,"limit":"50.0m","is_active":null,"threshold_type":null,"create_user":"sw17383",
						"create_time":"2017-02-06 10:31:52.083","cob_date":"2017-02-03 00:00:00.0","open_date":"2017-02-06 00:00:00.0","status":"1","status_name":"Resolved","age":1,"comment":null,"file_name":null,
						"attachements":null,"exception_owner":"1","updatedby":"NAM\\pfmis_admin_uat","first_date":"2017-02-03 00:00:00.0","first_value":"3282.7m","second_date":"2017-02-02 00:00:00.0",
						"second_value":"3156.9m","delta":"125.8m","delta_percent":"4","exception_owner_name":"10V CE Group","client_fund":"10V","is_security":false,"clientTier":"1-PLATINUM","is_primary":false,
						"is_clientgroup":true,"nam":" Aaronson, Jay (ja48224)","emea":null,"apac":null,"nam_aqua":" Kishore, Mayank (mk31857)","emea_aqua":null,"apac_aqua":null};

	beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: AppStateService,
                    useClass: MockAppStateService,
                },
                {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                {
                	provide: UtilService,
                    useClass: MockUtilService,
                },
                APP_TEST_HTTP_PROVIDERS,
                AlertSummaryService,
            ],
        });
    });

    beforeEach(inject([AlertSummaryService, AppStateService, UtilService, MockBackend], (..._) => {
        [alertSummaryService, appStateService, utilService, backend] = _;
        appStateService.setModuleGlobalState('summary', 'search', "");
    }));

    describe('.getDataNotification', () => {
    	describe('when alert data contains alert assigned to me or my coverage group', () => {
    		it('my alerts should be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([myAlert, openAlert, resolvedAlert])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(serviceURI);
                });
                
                alertSummaryService.getDataNotification().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                	let alertData = alertSummaryService.getAlertsMy();
                	expect(alertData).toBeDefined();
                });
            });
    	});
    	describe('when alert data contains resolved alert', () => {
    		it('resolved alerts should be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([myAlert, openAlert, resolvedAlert])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(serviceURI);
                });
                
                alertSummaryService.getDataNotification().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                	let alertData = alertSummaryService.getAlertsClosed();
                	expect(alertData).toBeDefined();
                });
            });
    	});
    	describe('when alert data does not contain alert assigned to me or my coverage group', () => {
    		it('my alerts should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([openAlert, resolvedAlert])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(serviceURI);
                });
                
                alertSummaryService.getDataNotification().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                	let alertData = alertSummaryService.getAlertsMy();
                	expect(alertData.length).toEqual(0);
                });
            });
    	});
    	describe('when alert data does not contain resolved alert', () => {
    		it('resolved alerts should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([myAlert, openAlert])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(serviceURI);
                });
                
                alertSummaryService.getDataNotification().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                	let alertData = alertSummaryService.getAlertsClosed();
                	expect(alertData.length).toEqual(0);
                });
            });
    	});
    	describe('when alert data is empty', () => {
    		it('alerts should not be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([])
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(serviceURI);
                });
                
                alertSummaryService.getDataNotification().subscribe(isReady => {
                	expect(isReady).toBeTruthy();
                	let myAlertData = alertSummaryService.getAlertsMy();
                	expect(myAlertData).toBeUndefined();
                	let allAlertData = alertSummaryService.getAlertsOpen();
                	expect(allAlertData).toBeUndefined();
                	let resolvedAlertData = alertSummaryService.getAlertsClosed();
                	expect(resolvedAlertData).toBeUndefined();
                });
            });
    	});   	
    });
    
    describe('.loadAll', () => {
    	describe('when alert data is cached', () => {
    		it('cached data should be available', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify([myAlert, openAlert, resolvedAlert]),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(serviceURI);
                });
                
                // call load data to invoke call to service
                alertSummaryService.loadAll({page: 1, size: 5}).subscribe(isReady => {
                    expect(isReady).toBeTruthy();
                });
                
                // try loading cached data from observer
                alertSummaryService.getDataNotification().subscribe(isReady => {
                    expect(isReady).toBeTruthy();
                    let allAlertData = alertSummaryService.getAlertsOpen();
                	expect(allAlertData).toBeDefined();
                });
            });
    	});
    });
    
    describe('.loadAlerts', () => {
    	describe('when alert data is loaded', () => {
    		it('alerts should be available', () => {
                // call load alerts to save data
                alertSummaryService.loadAlerts([myAlert, openAlert, resolvedAlert]);
                
                // check alert data
                expect(alertSummaryService.getAlertsMy()).toBeDefined();
                expect(alertSummaryService.getAlertsOpen()).toBeDefined();
                expect(alertSummaryService.getAlertsClosed()).toBeDefined();
            });
    	});
    	
    	describe('when alert data is not loaded', () => {
    		it('alerts should not be available', () => {
                // check alert data
                expect(alertSummaryService.getAlertsMy()).toBeUndefined();
                expect(alertSummaryService.getAlertsOpen()).toBeUndefined();
                expect(alertSummaryService.getAlertsClosed()).toBeUndefined();
            });
    	});
    });
    
    describe('.setSearchTerm', () => {
    	// Create dummy alert using declared my alert and reset it's is_primary flag
		let openAlertDummy = _.clone(myAlert);
		openAlertDummy.is_primary = false;
		
		beforeEach(() => {
			// call load alerts to save data
	        alertSummaryService.loadAlerts([openAlert, openAlertDummy]);
		});		
		
    	describe('when search term is present in alert data', () => {
    		it('search result should be non-empty ', () => {
    			// Set search term
        		alertSummaryService.setSearchTerm("10V");
        		
    			// search should return one matching open alert, my and resolved alerts should be empty
                expect(alertSummaryService.getAlertsMy().length).toEqual(0);
                expect(alertSummaryService.getAlertsOpen().length).toBeGreaterThan(0);
                expect(alertSummaryService.getAlertsClosed().length).toEqual(0);
            });
    	});
    	
    	describe('when search term is not present in alert data', () => {
    		it('search result should be empty ', () => {
    			// Set search term
    			alertSummaryService.setSearchTerm("abcxyz");
        		
    			// search should return one no matching my, open and resolved alert
        		expect(alertSummaryService.getAlertsMy().length).toEqual(0);
                expect(alertSummaryService.getAlertsOpen().length).toEqual(0);
                expect(alertSummaryService.getAlertsClosed().length).toEqual(0);
            });
    	});
    });
    
    describe('.loadSelectedAlerts', () => {
    	describe('when alert is selected', () => {
    		it('load event should return list', () => {
            	// Set selected alert
    			alertSummaryService.setSelectedAlerts({selectedAlerts: [openAlert], enabled: true});
    			// Load selected alert
    			alertSummaryService.loadSelectedAlerts().subscribe( event => {
    	            expect(event).toBeDefined();
    	            expect(event.selectedAlerts.length).toBeGreaterThan(0);
    	            expect(event.enabled).toBeTruthy();
    	        });
            });
    	});
    	
    	describe('when alert is not selected', () => {
    		it('load event should return empty list', () => {
            	// Set selected alert
    			alertSummaryService.setSelectedAlerts({selectedAlerts: [], enabled: false});
    			// Load selected alert
    			alertSummaryService.loadSelectedAlerts().subscribe( event => {
    	            expect(event).toBeDefined();
    	            expect(event.selectedAlerts.length).toBeLessThan(1);
    	            expect(event.enabled).toBeFalsy();
    	        });
            });
    	});
    });
    
    describe('.getCellColor', () => {
    	describe('when alert priority is high', () => {
    		it('age column cell color should be red', () => {
            	expect(alertSummaryService.getCellColor(myAlert, 'age')).toEqual('RED');
            });
    	});
    	
    	describe('when alert priority is low and age is <= 2', () => {
    		it('age column cell color should be green', () => {
            	expect(alertSummaryService.getCellColor(openAlert, 'age')).toEqual('GREEN');
            });
    	});
    	
    	describe('when alert priority is undefined', () => {
    		it('age column cell color should be black', () => {
            	expect(alertSummaryService.getCellColor(resolvedAlert, 'age')).toEqual('BLACK');
            });
    	});
    	
    	describe('when alert delta is positive', () => {
    		it('change column cell color should be green', () => {
            	expect(alertSummaryService.getCellColor(myAlert, 'delta')).toEqual('GREEN');
            });
    	});
    	
    	describe('when alert delta is negative', () => {
    		it('change column cell color should be red', () => {
            	expect(alertSummaryService.getCellColor(openAlert, 'delta')).toEqual('RED');
            });
    	});
    });
    
    describe('.clearCache', () => {
    	describe('when alert data is cached', () => {
    		it('clearCache execution clears cached data', () => {
            	alertSummaryService.clearCache();
                expect(alertSummaryService.getAlertsMy()).toBeNull();
                expect(alertSummaryService.getAlertsOpen()).toBeNull();
                expect(alertSummaryService.getAlertsClosed()).toBeNull();
            });
    	});
    });

});

