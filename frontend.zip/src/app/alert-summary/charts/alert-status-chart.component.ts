// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import {ChartModule} from 'angular2-highcharts';
import * as _ from 'underscore';

//Application Component
import {Alert} from '../../models/alert';

@Component({
    selector: 'alert-status-chart',
    styleUrls: ['./alert-chart.component.scss'],
    templateUrl: './alert-status-chart.component.html'
})

export class AlertStatusChartComponent {
    @Input() alerts:Array<Alert>;
    statusByDateChart:Object;

    chartCatagories:any[] = [];
    chartOpenStatus:any[] = [];
    chartUnderReviewStatus:any[] = [];

    chart:any;

    saveInstance(chartInstance) {
        this.chart = chartInstance;
    }


    constructor() {
        console.debug('AlertStatusChartComponent::constructor');
    }

    ngOnChanges(changes:{[ length:string]:SimpleChange}) {
        console.debug('AlertStatusChartComponent::ngOnChanges', changes);
        if (this.alerts && this.alerts.length > 0)
            this.calculateStatusByDateChartData();
    }

    calculateStatusByDateChartData() {
        console.time('AlertStatusChartComponent::calculateStatusByDateChartData');
        var catagory = [];
        var openStatus = [];
        var underReviewStatus = [];

        var data = _.filter(this.alerts, function (val) {
            return val.status_name == 'Open'
                || val.status_name == 'Under Review'
        });

        var sortedResult = _.sortBy(data, function (val) {
            return val.exception_id
        });

        var result = _.chain(sortedResult).groupBy('cob_date').map(
            function (value, key) {
                return {
                    cob_date: key,
                    status: _.countBy(value, function (obj) {
                        switch (obj.status_name) {
                            case 'Open':
                                return "open";
                            case 'Under Review':
                                return "review";
                            case 'Re-Assigned':
                                return "assigned";
                        }
                    })
                }
            }).last(5).value();

        _.each(result, function (value, key, obj) {
            catagory.push((value.cob_date && isNaN(value.cob_date)) ? value.cob_date.toString().slice(0, 10) : value.cob_date);
            if (value.status) {
                //openStatus.push('open' in value.status ? value.status.open : 0);
                openStatus.push('open' in value.status ? value.status['open'] : 0);
                //underReviewStatus.push('review' in value.status ? value.status.review : 0);
                underReviewStatus.push('review' in value.status ? value.status['review'] : 0);
            }
        });

        this.chartCatagories = catagory;
        this.chartOpenStatus = openStatus;
        this.chartUnderReviewStatus = underReviewStatus;

        this.plotStatusByDateChart();
        console.timeEnd('AlertStatusChartComponent::calculateStatusByDateChartData');
    }

    plotStatusByDateChart() {
        console.time('AlertStatusChartComponent::plotStatusByDateChart');
        this.statusByDateChart = {
            chart: {
                type: 'column',
                 height: 315,
                // width: 557
                //renderTo: 'status-chart-container'
            },

            title: {
                text: 'Alert Status by Date'
            },

            subtitle: {
                text: '',
                x: -20
            },
            credits: {
                enabled: false
            },
            xAxis: {
                categories: this.chartCatagories,
                labels: {
                    rotation: -15
                }

            },
            yAxis: {
                title: {
                    text: 'Alert Count'
                },
                min: 0,
                enabled: true,
                style: {
                    fontWeight: 'bold',
                    color: 'gray'
                }

            },
            tooltip: {
                headerFormat: '<span style="font-size:10px"><b>{point.key}</b></span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>'
                + '<td style="padding:0"><b>{point.y}</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            legend: {
                align: 'center',
                x: -30,
                verticalAlign: 'bottom',
                y: 10,
                floating: true,

                shadow: false
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    dataLabels: {
                        enabled: true,
                        color: 'white',
                        style: {
                            textShadow: '0 0 3px black'
                        },
                        formatter: function () {
                            if (this.y > 0)
                                return this.y;
                        }

                    }
                }
            },
            series: [{
                name: 'Under Review',
                data: this.chartUnderReviewStatus,
                color: '#90CCEF'
            }, {
                name: 'Open',
                data: this.chartOpenStatus,
                color: '#4E728F'
            }]
        }
        console.timeEnd('AlertStatusChartComponent::plotStatusByDateChart');
    }

}

