// Framework
import {Component, Input, SimpleChange} from "@angular/core";
import { ChartModule } from 'angular2-highcharts'; 
import * as _ from 'underscore';

//Application Component
import {Alert} from '../../models/alert';

@Component({
	selector: 'alert-status-by-volumn-chart',
	styleUrls: ['./alert-chart.component.scss'],
	templateUrl: './alert-status-by-volumn-chart.component.html'
})

export class AlertStatusByVolumnChartComponent  {
	@Input() alerts:Array<Alert>;
	statusByDateChart: Object;

	chartCatagories: any[] = [];
	chartOpenStatus: number = 0;
	chartUnderReviewStatus:number = 0;

	chart : any;
	saveInstance(chartInstance) {
		this.chart = chartInstance;
	}

	constructor() {
		console.debug('AlertStatusByVolumnChartComponent::constructor');
	}

	ngOnChanges(changes: {[ length: string]: SimpleChange}) {
		console.debug('AlertStatusByVolumnChartComponent::ngOnChanges', changes);
		if(this.alerts && this.alerts.length > 0)
		    this.calculateStatusByDateChartData();
	}

	calculateStatusByDateChartData() {
		console.time('AlertStatusByVolumnChartComponent::calculateStatusByDateChartData');
		let alertStatusCounts =  _.countBy(this.alerts, function (obj) {
	          switch (obj.status_name) {
	          case 'Open':
	              return "open";
	          case 'Under Review':
	              return "review";
	          }
	      })
	      
		if(alertStatusCounts['open']){
		    this.chartOpenStatus = alertStatusCounts['open']; 
		}
		
		if(alertStatusCounts['review']){
		    this.chartUnderReviewStatus = alertStatusCounts['review']; ;//underReviewStatus.length;
        }

		this.plotStatusByDateChart();
		console.timeEnd('AlertStatusByVolumnChartComponent::calculateStatusByDateChartData');
	}

	plotStatusByDateChart() {
		console.time('AlertStatusByVolumnChartComponent::plotStatusByDateChart');
	 // Create the chart
	    this.statusByDateChart = {
	        chart: {
	            type: 'pie',
	          //renderTo: 'volume-chart-container',
                   height: 315,
               //  width: 557
	        },
	        title: {
	            text: 'Alert Status by Volume'
	        },
	        plotOptions: {
	            series: {
	                dataLabels: {
	                    enabled: true,
	                    format: '{point.name}: {point.percentage:.1f}%'
	                }
	            }
	        },

	        tooltip: {
	            headerFormat: '<span style="font-size:10px"><b>{point.key}</b></span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>'
                    + '<td style="padding:0"><b>{point.y}</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
	        },
	        
	        series: [{
	            name: 'Counts',
	            colorByPoint: true,
	            data: [{
	                name: 'Under Review',
                    y: this.chartUnderReviewStatus,
	                drilldown: 'null'
	            }, {
	                name: 'Open',
                    y: this.chartOpenStatus,
	                drilldown: 'null'
	            }, ]
	        }]
	    };
		console.timeEnd('AlertStatusByVolumnChartComponent::plotStatusByDateChart');
	}

}

