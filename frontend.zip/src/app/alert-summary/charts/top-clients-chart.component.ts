// Framework
import {Component, EventEmitter, Input, SimpleChange} from "@angular/core";
import {ChartModule} from 'angular2-highcharts';
import * as _ from 'underscore';

// Application Component
import {Alert} from '../../models/alert';
import {EventBusService} from '../../services';
import {AppStateService} from  "../../services/app-state.service";

//Application Services
import {AlertSummaryService} from "../alert-summary.service";

@Component({
    selector: 'top-clients-chart',
    styleUrls: ['./alert-chart.component.scss'],
    templateUrl: './top-clients-chart.component.html'
})

export class TopClientsChartComponent {

    @Input() alerts:Array<Alert>;
    topClientsChart:Object;
    chartCatagories:any[] = [];
    chartOpenStatus:any[] = [];
    chartUnderReviewStatus:any[] = [];

    chart:any;
    
    saveInstance(chartInstance) {
        this.chart = chartInstance;
    }

    constructor(private alertSummaryService: AlertSummaryService,
                private eventBusService:EventBusService,
                private appStateService:AppStateService) {
        console.debug('TopClientsChartComponent::constructor');
        
       
    }

    ngOnChanges(changes:{[ length:string]:SimpleChange}) {
        console.debug('TopClientsChartComponent::ngOnChanges ', changes);
        if (this.alerts && this.alerts.length > 0) {
            this.calculateTopClientChartData();
        }
    }

    ngAfterViewInit() {
        console.debug('TopClientsChartComponent::ngAfterViewInit ');
    }

    calculateTopClientChartData() {
        console.time("TopClientsChartComponent::CalculateTopClientChartData");

        var catagory = [];
        var openStatus = [];
        var underReviewStatus = [];

        var data = _.filter(this.alerts, function (val) {
            return val.status_name == 'Open'
                || val.status_name == 'Under Review'
        });

        var sortedResult = _.sortBy(data, function (val) {
            return val.exception_id
        });

        var result = _.chain(sortedResult).groupBy('client').map(
            function (value, key) {
                return {
                    client: key,
                    status: _.countBy(value, function (obj) {
                        switch (obj.status_name) {
                            case 'Open':
                                return "open";
                            case 'Under Review':
                                return "review";
                        }
                    }),
                    total_alerts: value.length
                }
            }).value();

        var top5clients = _.sortBy(result, function (val) {
            return val.total_alerts
        }).reverse().slice(0, 5);

        _.each(top5clients, function (value, key, obj) {
            catagory.push(value.client);
            if (value.status) {
                openStatus.push('open' in value.status ? value.status['open'] : 0);
                underReviewStatus.push('review' in value.status ? value.status['review'] : 0);
            }
        });

        this.chartCatagories = catagory;
        this.chartOpenStatus = openStatus;
        this.chartUnderReviewStatus = underReviewStatus;
        this.plotTop5ClientChart();
        console.timeEnd("TopClientsChartComponent::CalculateTopClientChartData");
    };

    plotTop5ClientChart() {
        console.time("TopClientsChartComponent::plotTop5ClientChart");
        this.topClientsChart = {
            chart: {
                type: 'bar',
                //renderTo: 'clients-chart-container'
                 height: 315,
                // width: 557
            },
            title: {
                text: 'Top 5 Clients by Alert'
            },
            yAxis: {
                allowDecimals: false,
                title: {
                    text: 'Alert Count'
                }
            },
            credits: {
                enabled: false
            },
            xAxis: {
                categories: this.chartCatagories
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px"><b>{point.key}</b></span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>'
                + '<td style="padding:0"><b>{point.y}</b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            legend: {
                reversed: true,
                y: 10,
                shadow: false
            },
            plotOptions: {
                series: {
                    stacking: 'normal',
                    cursor: 'pointer',
                    point: {
                        events: {
			                click: function() {
										console.debug('clicked category: ' + this.category);
										this.events.onChartClick(this.category);
									}, 
			                onChartClick: (term) => {
			                        let searchTerm = this.appStateService.getModuleGlobalState('summary', 'search')
	                        	 	if(searchTerm == term ) {
	                        	 	    this.eventBusService.dispatch(new CustomEvent("searchTerm", {detail : {term: ""}}));
	                        	 	} else {
	                        	 	   this.eventBusService.dispatch(new CustomEvent("searchTerm", {detail : {term: term}}));
	                        	 	}
								}
                        }
                    }
                }
            },
            series: [{
                data: this.chartOpenStatus,
                name: "Open",
                color: '#4E728F'
            }, {
                data: this.chartUnderReviewStatus,
                name: "Under Review",
                color: '#90CCEF'
            }]
        }
        console.timeEnd("TopClientsChartComponent::plotTop5ClientChart");
    }

}