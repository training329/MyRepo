// Framework
import {
    Component,
    ElementRef,
    OnInit,
    SimpleChange,
    Input,
    Output,
    EventEmitter,
    ViewChild,
    ChangeDetectionStrategy,
    OnDestroy
} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";

import * as toastr from 'toastr';

import {DataTable} from 'primeng/primeng';
import {Subject} from "rxjs/Rx";
import {Subscription} from 'rxjs/Subscription'

import {LazyLoadEvent, MenuItem} from '../common/api';

// Application Component
import {Alert} from '../models/alert';
import {HttpErrorHandler} from "../services/http-error-handler";
import {AlertSummaryService} from "./alert-summary.service";
import {UtilService} from "../services/util.service";
import {AppStateService} from "../services/app-state.service";

// Application Shared
import {SelectItem} from '../common/api';

// Size management
export interface IParentProps {
    width:number;
    height:number;
}

@Component({
    selector: 'cba-all-alerts',
    styleUrls: ['./all-alerts.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './all-alerts.component.html'
})
export class AllAlertsComponent implements OnInit, OnDestroy {
    //TODO: Remove column sending back and forth - what is the purpose to send component same set of fields that are present there already?!
    cols:any[];

    datasource:Array<Alert>;
    globalFilter:any;
    onDataTableResetNotify:Subject<any>;


    /**
     * Debounce time
     * @type {any}
     */
    sizeCheckInterval = null;
    sizeResetInterval = null;
    /**
     * Current Component Size
     * @type {{width: number; height: number}}
     */
    parentProps:IParentProps = {
        width: 0,
        height: 0
    }

    /**
     * Keep current content pointer
     */
    @ViewChild('AllAlertComponentContent') AllAlertComponentContent:ElementRef;


    /*
     *  Build update alerts selector
     *  @access public
     *  @property $columnOptions
     *  @type SelectItem[]
     */
    private columnOptions:SelectItem[];

    //TODO: Please make a habit of commenting the code
    //TODO: Include Description, Access (private, public), @property $varName, @type Class
    /**
     *
     *
     * @type {EventEmitter}
     */

    private alerts:Array<Alert>;
    private menuItems:MenuItem[];
    private page:number;
    private selectedAlerts:Array<Alert>;
    private showCharts:boolean;
    private totalPages:number;
    private totalRecords:number = 0;
    private toggleColumn:string = "Toggle Columns";
    private alertsSubscription:Subscription;
    private emptyMessage : string = "";

    @ViewChild('dt') dt:DataTable;

    constructor(private router:Router,
                private errorHandler:HttpErrorHandler,
                private appStateService:AppStateService,
                private alertSummaryService:AlertSummaryService,
                private el:ElementRef) {

        console.debug('AllAlertsComponent::constructor');
        this.cols = [
            {header: 'ALERT#', field: 'exception_id', style: {'width': '4%', 'text-align': 'left'}, sortable: true},
            {header: 'COB DATE', field: 'cob_date', style: {'width': '6%', 'text-align': 'left'}, sortable: true},
            {header: 'PRIORITY', field: 'priority', style: {'width': '5%', 'text-align': 'left'}, sortable: true},
            {header: 'AGE', field: 'age', style: {'width': '3%', 'text-align': 'center'}, sortable: true},
            {header: 'STATUS', field: 'status_name', style: {'width': '4%', 'text-align': 'left'}, sortable: true},
            {header: 'CLIENT/FUND', field: 'client', style: {'width': '12%', 'text-align': 'left'}, sortable: true},
            {header: 'REGION', field: 'region', style: {'width': '4%', 'text-align': 'left'}, sortable: true},
            {header: 'DATA TYPE', field: 'measure', style: {'width': '8%', 'text-align': 'left'}, sortable: true},
            {header: 'PERIOD', field: 'rule_period', style: {'width': '7%', 'text-align': 'left'}, sortable: true},
            {header: 'TIER', field: 'clientTier', style: {'width': '4.5%', 'text-align': 'left'}, sortable: true},
            {header: 'THRESHOLD', field: 'limit', style: {'width': '5%', 'text-align': 'right'}, sortable: false},
            {header: 'COB VALUE', field: 'first_value', style: {'width': '5%', 'text-align': 'right'}, sortable: false},
            {
                header: 'PREV VALUE',
                field: 'second_value',
                style: {'width': '5%', 'text-align': 'right'},
                sortable: false
            },
            {header: 'CHANGE', field: 'delta', style: {'width': '4%', 'text-align': 'right'}, sortable: false},
            {
                header: '% CHANGE',
                field: 'delta_percent',
                style: {'width': '5%', 'text-align': 'right'},
                sortable: false
            },
            {
                header: 'ALERT OWNER',
                field: 'exception_owner_name',
                style: {'width': '19%', 'text-align': 'left'},
                sortable: true
            }
        ];

        this.columnOptions = [];
        for (let i = 0; i < this.cols.length; i++) {
            this.columnOptions.push({label: this.cols[i].header, value: this.cols[i]});
        }

        /**
         *
         *         this.cols = [
         {header: 'ALERT#', field: 'exception_id', style: {'width': '4%', 'text-align': 'left'}, sortable:true},
         {header: 'COB DATE', field: 'cob_date', style: {'width': '5%', 'text-align': 'left'}, sortable:true},
         {header: 'PRIORITY', field: 'priority', style: {'width': '5%', 'text-align': 'left'}, sortable:true},
         {header: 'AGE', field: 'age', style: {'width': '3%', 'text-align': 'right'}, sortable:true},
         {header: 'STATUS', field: 'status_name', style: {'width': '5%', 'text-align': 'left'}, sortable:true},
         {header: 'CLIENT/FUND', field: 'client', style: {'width': '12%', 'text-align': 'left'}, sortable:true},
         {header: 'REGION', field: 'region', style: {'width': '4%', 'text-align': 'left'}, sortable:true},
         {header: 'DATA TYPE', field: 'measure', style: {'width': '8%', 'text-align': 'left'}, sortable:true},
         {header: 'PERIOD', field: 'rule_period', style: {'width': '8%', 'text-align': 'left'}, sortable:true},
         {header: 'TIER', field: 'clientTier', style: {'width': '5%', 'text-align': 'left'}, sortable:true},
         {header: 'THRESHOLD', field: 'limit', style: {'width': '5%', 'text-align': 'right'}, sortable:false},
         {header: 'COB VALUE', field: 'first_value', style: {'width': '5%', 'text-align': 'right'}, sortable:false},
         {header: 'PREV VALUE', field: 'second_value', style: {'width': '5%', 'text-align': 'right'}, sortable:false},
         {header: 'CHANGE', field: 'delta', style: {'width': '5%', 'text-align': 'right'}, sortable:false},
         {header: '% CHANGE', field: 'delta_percent', style: {'width': '5%', 'text-align': 'right'}, sortable:false},
         {header: 'ALERT OWNER', field: 'exception_owner_name', style: {'width': '16%', 'text-align': 'left'}, sortable:true}
         ];

         this.columnOptions = [];
         for (let i = 0; i < this.cols.length; i++) {
            this.columnOptions.push({label: this.cols[i].header, value: this.cols[i]});
        }
         */

        //this.columnDataNotify.emit(this.cols);
    }

    onMenuSelection(event) {
        console.debug("AllAlertsComponent::onMenuSelection ", event);
        let target = event.target || event.srcElement || event.currentTarget;
        let idAttr = target.attributes.id;
        let id = idAttr.nodeValue;
        console.debug('AllAlertsComponent::onMenuSelection ', id);
        //TODO: Check if menu edit - move to Edit of that Alert
        //this.router.navigate(['alert-item', event.data.exception_id]);
    }

    updateLabel() {
        console.debug("AllAlertsComponent::updateLabel");
    }

    onTabOpen(event):void {
        console.debug('AllAlertsComponent::onTabOpen ', event.index);
        //TODO: Calculate actual screen size, if allows - display, if not, adjust grid
        let _rows = this.dt.rows;
        this.dt.rows = (_rows > 19) ? _rows - 10 : _rows;
        this.dt.reset();
        this.showCharts = true;
    }

    onTabClose(event):void {
        console.debug('AllAlertsComponent::onTabClose ', event.index);
        let _rows = this.dt.rows;
        this.dt.rows = (_rows < 11) ? _rows + 10 : _rows;
        this.dt.reset();
        this.showCharts = false;
    }

    ngOnInit() {
        console.debug("AllAlertsComponent::ngOnInit" + this.router.routerState.snapshot.url);
        this.totalRecords = 0;
        this.menuItems = [
            {label: 'Edit', icon: 'fa-edit', command: (event) => this.onMenuSelection(event)},
            {label: 'Resolve', icon: 'fa-close', command: (event) => this.onMenuSelection(event)}
        ];
        this.listCached(1);
    }

    ngAfterContentInit() {
        console.debug("AllAlertsComponent::ngAfterContentInit",this.dt, this.parentProps);
        // this.sizeResetInterval = setInterval(() => {
        //     // Calculate how many rows to set to datatable
        //     if (this.parentProps && this.dt) {
        //
        //     }
        // }, 300);

        // Get reference to P-datatable HTMLElement
        let container = this.dt.el.nativeElement.children[0];
        // get current table content height
        let currentHeight = (container)?container.offsetHeight:0;
        console.debug("AllAlertsComponent::ngAfterContentInit first child",currentHeight, container);// container.offsetHeight);

    }

    ngAfterViewInit() {
        console.debug("AllAlertsComponent::ngAfterViewInit",this.parentProps, this.dt);
        this.sizeCheckInterval = setInterval(() => {
            let h = this.el.nativeElement.offsetHeight;
            let w = this.el.nativeElement.offsetWidth;
            if ((h !== this.parentProps.height) || (w !== this.parentProps.width)) {
                this.parentProps = {
                    width: w,
                    height: h
                }
            }
        }, 300);
    }

    private listCached(page:number) {
        console.debug('AllAlertsComponent::listCached: ', 'subscribing to alertSummaryService.isReady');
        this.alertsSubscription = this.alertSummaryService.getDataNotification()
            .subscribe(isReady => {
                console.debug('AllAlertsComponent::listCached: ', 'subscriptions completed', isReady);
                if (isReady) {
                    if (this.router.routerState.snapshot.url.indexOf('all') > 0) {
                        this.postAlertsData(this.alertSummaryService.getAlertsOpen());
                    } else {
                        this.postAlertsData(this.alertSummaryService.getAlertsMy());
                    }
                    setTimeout(() => {
                        let currentpage = this.appStateService.getModuleComponentState('datatable', 'currentpage')
                        if(currentpage)
                            this.setCurrentPage(Number(currentpage));
                        this.appStateService.activateModuleState();
                    }, 300);
                }
            }, e => {
    			toastr.error('Error while getting alerts data. Please try again or contact AQUA RACE support', 'Error');
    			this.errorHandler.handle(e);
    		});
    }

    private postAlertsData(alerts:Array<Alert>) {
    	console.debug("AllAlertsComponent::postAlertsData ", alerts);
    	this.datasource = alerts;
        if (this.datasource) {
            this.totalRecords = this.datasource.length;
            this.selectedAlerts = [];
            this.emptyMessage = (this.datasource.length == 0) ? UtilService.noRecordsFoundMessage : "";
        }
        this.dt.reset();
    }

    onRowDblclick(event) {
        console.debug("on row selected data " + event.data.exception_id);
        this.router.navigate(['alerts/summary/alert-item', event.data.exception_id]);
    }

    onHeaderCheckboxSelect(event) {
        console.debug("AllAlertsComponent::onHeaderCheckboxSelect event ", event);
        this.alertSummaryService.setSelectedAlerts({selectedAlerts: this.selectedAlerts, enabled: event.checked});
    }

    onSelectionChange(event) {
        console.debug("AllAlertsComponent::onSelectionChange event ", event);
    }

    onSingleRowSelect(event) {
        console.debug("AllAlertsComponent::onSingleRowSelect event ", event);
        if (event.type === "checkbox") {
            this.alertSummaryService.setSelectedAlerts({
                //this.bulkUpdateButtonEnableNotify.emit({
                selectedAlerts: this.selectedAlerts,
                enabled: event.originalEvent.checked
            });
        } else if (event.type === "row") {
            this.alertSummaryService.setSelectedAlerts({
                selectedAlerts: this.selectedAlerts,
                enabled: true
            });
        }
    }

    onSingleRowUnselect(event) {
        console.debug("AllAlertsComponent::onSingleRowUnselect event ", event);
        if (this.selectedAlerts && this.selectedAlerts.length == 0) {
            this.alertSummaryService.setSelectedAlerts({
                selectedAlerts: this.selectedAlerts,
                enabled: event.originalEvent.checked
            });
        }
    }

    resetDataTable(dt:DataTable) {
        console.debug("AllAlertsComponent::resetDataTable");
        dt.reset();
        dt.selection = [];
        this.selectedAlerts = [];
    }

    onPageChange(event) {
        if (this.dt.rows) {
            console.debug("AllAlertsComponent::onPageChange on page ", event.first / event.rows + " event ", event);
            this.appStateService.setModuleComponentState('datatable', 'currentpage', event.first / event.rows);
        }
    }

    setCurrentPage(n:number) {
        console.debug("AllAlertsComponent::setCurrentPage page ", n + "dt rows" + this.dt.rows);
        if (this.dt.rows) {
            let paging = {
                first: (n * this.dt.rows),
                rows: this.dt.rows
            };

            console.debug("AllAlertsComponent::setCurrentPage  paging", paging + " page ", n);
            this.dt.paginate(paging);
        }
        //this.dt.sortField = "cob_date";
        //this.dt.sortOrder = -1;  
    }


    loadAlertsLazy(event:LazyLoadEvent, table:DataTable) {
        //in a real application, make a remote request to load data using state metadata from event
        //event.first = First row offset
        //event.rows = Number of rows per page
        //event.sortField = Field name to sort with
        //event.sortOrder = Sort order as number, 1 for asc and -1 for dec
        //filters: FilterMetadata object having field as key and filter value, filter matchMode as value

        //imitate db connection over a network
        this.alerts = this.datasource.slice(event.first, (event.first + event.rows));
        //setTimeout(() => {
        //   this.alerts = this.datasource.slice(event.first, (event.first + event.rows));
        //}, 1);
        console.debug("AllAlertsComponent::loadAlertsLazy", event);
    }

    // TODO: To implement pagination
    // onPageChanged(page: number) {
    //     this.router.navigate(['/alerts', {page: page}]);
    // }


    onChartClick(event) {
        console.debug('AllAlertsComponent::onChartClick SearchTerm: ' + event.term);
    }


    // TODO: Critical
    getAgeColumnCellColor(alert:Alert) {
        // console.debug('AllAlertsComponent::getAgeColumnCellColor ', alert);
        if (alert.priority === 'High' || alert.age >= 5) {
            return "RED";
        }
        else if ((alert.priority === 'Medium' && alert.age <= 1) || (alert.priority === 'Low' && alert.age <= 2)) {
            return "GREEN";
        }
        else if ((alert.priority === 'Medium' && (alert.age >= 2 && alert.age <= 4)) || (alert.priority === 'Low' && (alert.age >= 3 && alert.age <= 5))) {
            return "#FF7E00";
        }
        return "BLACK";
    }

    ngOnDestroy() {
        console.debug('AllAlertsComponent::ngOnDestory: ');
        this.alertsSubscription.unsubscribe();
       // this.appStateService.deactivateModuleState();
        // Size management
        if (this.sizeCheckInterval !== null) {
            clearInterval(this.sizeCheckInterval);
        }
    }
}

