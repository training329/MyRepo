// Framework
import {Component, Input, Output, AfterViewChecked, ViewChild, EventEmitter, OnDestroy } from "@angular/core";
import {NgForm} from '@angular/forms';
import {Subject} from "rxjs/Rx";
import {Subscription} from 'rxjs/Subscription';

//Application Models
import {Alert} from '../../models/alert';
import {DropDownModel} from '../../models/dropdown-model';
import {ExceptionMaster} from '../../models/exception-master';
import {BulkExceptionModel} from '../../models/bulk-exception-model';
import {ExceptionUser} from '../../models/exception-user';

// Application Services
import {HttpErrorHandler} from "../../services/http-error-handler";
import {BulkUpdateService} from "./bulk-update.service";
import {AlertEditService} from "../manage/alert-edit.service";

import * as toastr from 'toastr';
import * as _ from 'underscore';

@Component({
    selector: 'bulk-update',
    styleUrls: ['./bulk-update.component.scss'],
    templateUrl: './bulk-update.component.html'
})

export class BulkUpdateComponent implements OnDestroy {

	@Input() showBulkUpdateDialogNotify: Subject<any>;
	@Output() onSaveRefreshDSNotify: EventEmitter<{refresh: boolean}>;
	
	bulkUpdateForm: NgForm;
	@ViewChild('bulkUpdateForm') currentForm: NgForm;
	@ViewChild('fileInput') fileInput:any;

	bulkExceptionModel: BulkExceptionModel;
    selectedUser: DropDownModel;
    selectedStatus: ExceptionMaster;

    filteredUsers: Array<DropDownModel>;
	selectedExceptions: Array<Alert>;
    statusTypes: Array<ExceptionMaster>;
    //users: Array<DropDownModel>;    
    users:Array<ExceptionUser>;

    formActive: boolean = true;
	display: boolean;
	active: boolean = false;
	validate: boolean = false;
	
    errorMsg: string;
    successMsg: string;
    partialSuccessMsg: string;
	
    files: any[] = [];
	operationStatusList: any[] = [];
	operationSuccessList: any[] = [];
	removeSelectedExceptions: Array<Alert> = [];
	selectedExceptionAndActivityIds: any[] = [];
	selectedExceptionIdList: any[] = [];
	
	private formChangeSubScription : Subscription;
	
	// initialization
	constructor(private errorHandler: HttpErrorHandler,
			private bulkUpdateService: BulkUpdateService,
			private alertEditService: AlertEditService) {
		console.debug("BulkUpdateComponent::constructor");
		this.bulkExceptionModel = new BulkExceptionModel();
		this.bulkExceptionModel.comment = "";
		this.bulkExceptionModel.status = "";
		this.bulkExceptionModel.exception_owner = "";
		this.bulkExceptionModel.exception_owner_name = "";
		this.onSaveRefreshDSNotify = new EventEmitter<{refresh: boolean}>();
	}

	ngOnInit() {
		console.debug("BulkUpdateComponent::ngOnInit");
	    this.getStatus();
        this.showBulkUpdateDialogNotify.subscribe(event => {
			this.reset();
			this.selectedExceptions = event.selectedAlerts;
			this.display = event.enabled;
			this.initExceptionIdList();
			this.getUsersForExcpetionIds();
		});
	}
	
	ngOnDestroy() {
    	console.debug('BulkUpdateComponent::ngOnDestroy');
    	if (this.formChangeSubScription) {
    		this.formChangeSubScription.unsubscribe();
    	}        
    }

	save(): void {
		console.debug("BulkUpdateComponent::save ", this.bulkExceptionModel);
		this.active = true;
		if(this.selectedExceptions && this.selectedExceptions.length > 0) {
			this.initRequestParams();
			this.bulkUpdateService.save(this.bulkExceptionModel, this.files)
		        .subscribe( bulkExceptionRes => {
		        	this.files = [];
		        	if (bulkExceptionRes[0].error) {
	                    this.active = true;
	                    this.successMsg = '';
	                    this.partialSuccessMsg = '';
	                    this.errorMsg = bulkExceptionRes[0].errorMessage;
	                    console.log(bulkExceptionRes[0].errorMessage, 'Error');
		            } else {
		            	this.setResponse(bulkExceptionRes);
		            }
		        }, e => {
		        	this.files = [];
					toastr.error('Error while updating alerts in bulk. Please try again or contact AQUA RACE support', 'Error');
					this.errorHandler.handle(e);
				});
		} else {
            this.active = true;
            this.successMsg = '';
            this.partialSuccessMsg = '';
            this.errorMsg = 'No records found for bulk update. Please try again or contact AQUA RACE support';
            console.log('No records found for bulk update. Please try again or contact AQUA RACE support');
		}
	}
	
	initRequestParams(): void {
		console.debug("BulkUpdateComponent::initRequestParams");
		this.initExceptionIdList();
        this.bulkExceptionModel.exception_id_list = this.selectedExceptionAndActivityIds.join();
        this.bulkExceptionModel.selectedExceptionIdList = this.selectedExceptionIdList;		
    }
	
	initExceptionIdList(): void {
		console.debug("BulkUpdateComponent::initExceptionIdList");
		if(this.selectedExceptions && this.selectedExceptions.length > 0) {
			this.selectedExceptionAndActivityIds = [];
			this.selectedExceptionIdList = [];
			for(let i = 0; i < this.selectedExceptions.length; i++) { 
				this.selectedExceptionAndActivityIds.push(this.selectedExceptions[i].exception_id  + ":" +  this.selectedExceptions[i].exception_activity_id);
				this.selectedExceptionIdList.push(this.selectedExceptions[i].exception_id);
			}
		}		
    }
    
    setResponse(bulkExceptionRes): void {
    	console.debug("BulkUpdateComponent::setResponse ", bulkExceptionRes);
        let totalCount = 0;
        let errorCount = 0;
        let successCount = 0;
        
    	for(let i = 0; i < bulkExceptionRes.length; i++) {
            totalCount++;
            
           let tempResult = _.filter(this.selectedExceptions, function (val) { 
            	return val.exception_id == bulkExceptionRes[i].exception_id
            });
           
        	let index = this.selectedExceptions.indexOf(tempResult[0]);
        	if(bulkExceptionRes[i].status != '0') {
	        	let status = _.filter(this.statusTypes, function (val) {
	                  return val.value == bulkExceptionRes[i].status;
	            });
        		this.selectedExceptions[index].status_name = status[0].text;
        	}
        	
        	this.operationStatusList[bulkExceptionRes[i].exception_id] = bulkExceptionRes[i].operation_status;
        	this.selectedExceptions[index].updatedby = bulkExceptionRes[i].updatedby;
            let statusValue = bulkExceptionRes[i].operation_status_value;
            
            if (statusValue == 1) {
                successCount++;
                this.operationSuccessList[bulkExceptionRes[i].exception_id] = true;
            } else {
                errorCount++;
                this.operationSuccessList[bulkExceptionRes[i].exception_id] = false;
            }
    	}
        if (successCount == totalCount) {
            this.successMsg = 'Bulk update successfully completed.';
            console.debug(this.successMsg);
        } else if (errorCount == totalCount) {
            this.errorMsg = 'Bulk update not successful due to client coverage. Please see Operation Status message for each alert';
            console.debug(this.errorMsg);
        } else {
            this.partialSuccessMsg = 'Bulk update partially successful due to client coverage. Please see Operation Status message for each alert and in Operation Status if alert already updated by other user';
            console.debug(this.partialSuccessMsg);
        }
    	this.active = true;
    }
	
    removeAllExceptions(): void {
    	console.debug("BulkUpdateComponent::removeAllExceptions");
    	this.selectedExceptions = [];
    }
    
    removeException(exception): void {
    	console.debug("BulkUpdateComponent::removeException ", exception);
        let index = this.selectedExceptions.indexOf(exception);
        this.selectedExceptions.splice(index, 1);
        
    	if(this.selectedExceptions && this.selectedExceptions.length == 0) {
    		this.active = true;
    	}
    }
    
    getStatus(): void {
    	console.debug("BulkUpdateComponent::getStatus");
        this.alertEditService.getStatus().subscribe( exceptionMaster => {
            this.statusTypes = exceptionMaster;
        }, e => {
			toastr.error('Error while getting alerts status types. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }
    
    getUsersForExcpetionIds(): void {
    	console.debug('BulkUpdateComponent::getUsersForExcpetionIds', this.selectedExceptionIdList);
    	if(this.selectedExceptionIdList && this.selectedExceptionIdList.length > 0) {    		
            this.bulkUpdateService.getUsersForExcpetionIds(this.selectedExceptionIdList).subscribe(users => {
            this.users = users;
                
             // add form change listener, when form is completely loaded 
            setTimeout(() => {
                   this.formChanged();
            }, 1000);
                
            }, e => {
    			toastr.error('Error while getting users. Please try again or contact AQUA RACE support', 'Error');
    			this.errorHandler.handle(e);
    		});
    	}
    }
    
    onAlertOwnerSelect(event) {
    	console.debug('BulkUpdateComponent::onAlertOwnerSelect', event);
    	for ( let user of this.users ) {
    		if (user.groupId == event.userGrpId) {
    			this.bulkExceptionModel.exception_owner_name =  user.gpName;
    	        this.bulkExceptionModel.exception_owner = user.groupId + '';
    			break;
    		}
    	}
    	this.checkDataModification();
        
    }

    uploadFile( $event ): void {
    	console.debug("BulkUpdateComponent::uploadFile ", $event);
    	for (let file of $event.target.files) {
        	// Add file only if it is not present already
        	var isPresent = _.find(this.files, function(existingFile){ return existingFile.name == file.name; });
        	if (isPresent) {
        		this.removeFile(file.name);
        	}
        	this.files.push(file);
        }
    	this.fileInput.nativeElement.value = null;
        this.checkDataModification();
    }
    
    removeFile(fileName) {
    	console.debug('BulkUpdateComponent::removeFile ', fileName);
    	this.files = _.filter(this.files, function(file) { 
    		return file.name != fileName; 
    	});
        this.checkDataModification();
    }
    
    formChanged() {
    	console.debug("BulkUpdateComponent::formChanged");
    	if (this.currentForm === this.bulkUpdateForm) { return; }
    	this.bulkUpdateForm = this.currentForm;
    	if (this.bulkUpdateForm) {
    		this.formChangeSubScription = this.bulkUpdateForm.valueChanges
    		.subscribe(data => this.onValueChanged(data));
    	}
    }
    	  
	onValueChanged(data?: any) {
		console.debug("BulkUpdateComponent::onValueChanged");
	    if (!this.bulkUpdateForm) { return; }
	    if(!this.active) {
	    	this.checkDataModification();
	    }
	}
    	  
    checkDataModification(): void {
    	console.debug("BulkUpdateComponent::checkDataModification");
        if ((this.selectedExceptions && this.selectedExceptions.length == 0)|| this.bulkExceptionModel.status != '' || this.bulkExceptionModel.exception_owner != '' || this.bulkExceptionModel.comment != ''  || (this.files && this.files.length > 0)) {
        	if (this.bulkExceptionModel.status != '' && this.bulkExceptionModel.status == "3" && this.bulkExceptionModel.comment == '') {
        		this.validate = false;
        		this.errorMsg = 'Please enter Alert Comment';
        	} else {
        		this.validate = true;
        		this.errorMsg = '';
        	}	
        } else {
        	this.validate = false;
        }
    }
    
    reset(): void {
    	console.debug("BulkUpdateComponent::reset");
    	this.selectedExceptions = [];
    	this.operationSuccessList = [];
    	this.operationStatusList = [];
		this.active = false;
		this.validate = false;
		this.bulkExceptionModel.comment = "";
		this.bulkExceptionModel.status = "";
		this.bulkExceptionModel.exception_owner = "";
		this.bulkExceptionModel.exception_owner_name = "";
        this.successMsg = '';
        this.partialSuccessMsg = '';
        this.errorMsg = '';
        this.files = [];
        let exceptionFile = (<HTMLInputElement>document.getElementById('exceptionFile'));
        exceptionFile.value = "";
    }
    
    close(): void {
    	console.debug("BulkUpdateComponent::close");
    	this.files = [];
    	if(this.active) {
    		this.onSaveRefreshDSNotify.next({refresh: true});
    	}
    	this.reset();
    }
    
}