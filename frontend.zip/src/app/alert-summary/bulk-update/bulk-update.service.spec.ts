import {inject, TestBed} from "@angular/core/testing";
import {ResponseOptions, Response, RequestMethod, HttpModule} from "@angular/http";
import {MockBackend} from "@angular/http/testing";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../../testing";

import {HttpErrorHandler} from "../../services/http-error-handler";
import {BulkUpdateService} from "./bulk-update.service";
import {MockError, MockHttpErrorHandler} from '../../testing/mock.services';

//Service END Point URL should be declared as SERVICE END POINT
const bulkUpdateServiceEndPoint = '/api/exceptionsummary/bulkUpdate';
const expUserListURI: string = '/api/exceptionsummary/bulk/getExceptionUsers/252838,253815';

//Service Mock response copied from current real service
const usersMockResponse = [
								{"groupId":461,"soeid":"ig55749","gpName":"Gritsayuk, Igor (ig55749)","region":null,"gpType":null,"primary":false},
								{"groupId":467,"soeid":"mk35063","gpName":"Kherde, Milind (mk35063)","region":null,"gpType":null,"primary":false}
							];
const bulkExceptionMockModel = {"comment":"Test", "exception_id_list":"252838:261642,253815:261643", "exception_owner":"", "exception_owner_name":"", "selectedExceptionIdList":[252838, 253815], "status":""};
const bulkUpdateSuccessMockResponse = [
											{"exception_id":252838,"operation_status":"Success","operation_status_value":1,"status":"1","exception_owner":"","comment":"Test","file_name":null,"updatedby":"Ligade, Shivaprasad Audumbar","errorMessage":null,"error":false},
											{"exception_id":253815,"operation_status":"Success","operation_status_value":1,"status":"1","exception_owner":"","comment":"Test","file_name":null,"updatedby":"Ligade, Shivaprasad Audumbar","errorMessage":null,"error":false}
										];
const bulkUpdateFailMockResponse = [{"error":true, "errorMessage":"Bulk update failed. Please try again or contact AQUA RACE support"}];
const bulkUpdateEmptyMockResponse = [];

describe('BulkUpdateService', () => {

    let bulkUpdateService: BulkUpdateService;
    let backend: MockBackend;
	
	let exceptionIds = "252838,253815";

	beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                APP_TEST_HTTP_PROVIDERS,
                BulkUpdateService,
            ],
        });
    });

    beforeEach(inject([BulkUpdateService, MockBackend], (..._) => {
        [bulkUpdateService, backend] = _;
    }));
    
    describe('.getUsersForExcpetionIds', () => {
    	describe('when users are returned', () => {
    		it('users list should be non-empty', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(usersMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(expUserListURI);
                });
                
                bulkUpdateService.getUsersForExcpetionIds(exceptionIds).subscribe(users => {
                	expect(users).not.toBeUndefined();
                	expect(users).not.toBeNull();
                	expect(users.length).toBeGreaterThan(0);
                });                
            });
    	});
    });
    
    describe('.save', () => {
    	describe('when bulk update is successful', () => {
    		it('operation status should be returned for selected alerts', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(bulkUpdateSuccessMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(bulkUpdateServiceEndPoint);
                });
                
                bulkUpdateService.save(bulkExceptionMockModel, []).subscribe(bulkExceptionRes => {
            		expect(bulkExceptionRes).toBeDefined();
            		expect(bulkExceptionRes.length).toBeGreaterThan(0);
            		expect(bulkExceptionRes[0].operation_status).not.toBeNull();
                });               
            });
    	});
    	
    	describe('when bulk update fails', () => {
    		it('error should be true', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(bulkUpdateFailMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(bulkUpdateServiceEndPoint);
                });
                
                bulkUpdateService.save(bulkExceptionMockModel, []).subscribe(bulkExceptionRes => {
                	expect(bulkExceptionRes).toBeDefined();
            		expect(bulkExceptionRes[0].error).toBeTruthy();
                });               
            });
    	});
    	
    	describe('when bulk update returns empty response', () => {
    		it('response should be of length 0', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(bulkUpdateEmptyMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(bulkUpdateServiceEndPoint);
                });
                
                bulkUpdateService.save(bulkExceptionMockModel, []).subscribe(bulkExceptionRes => {
            		expect(bulkExceptionRes).toBeDefined();
            		expect(bulkExceptionRes.length).toEqual(0);
                });               
            });
    	});
    });

});

