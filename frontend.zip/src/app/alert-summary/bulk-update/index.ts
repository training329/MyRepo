export * from './bulk-update.component';
export * from './bulk-update.service';
 