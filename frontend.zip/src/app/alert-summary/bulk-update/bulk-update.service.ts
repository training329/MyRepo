// Framework
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Response} from '@angular/http';
import "../../common/rxjs-operators";

//Application
import {JsonHttp} from "../../services/json-http";
import {HttpErrorHandler} from "../../services/http-error-handler";

//Application Models
// import {Alert} from '../../models/alert';
import {BulkExceptionModel} from '../../models/bulk-exception-model';
import {ExceptionUser} from '../../models/exception-user';

//Service End Point URI
const bulkUpdateServiceEndPoint = '/api/exceptionsummary/bulkUpdate';
const expUserListURI: string = '/api/exceptionsummary/bulk/getExceptionUsers/';

@Injectable()
export class BulkUpdateService {

    constructor( private http: JsonHttp,
    			private errorHandler: HttpErrorHandler ) {
    	console.debug('BulkUpdateService::constructor');
    }
    
    save(bulkExceptionModel: BulkExceptionModel, files: File[]): Observable<BulkExceptionModel[]> {
    	console.debug('BulkUpdateService::save',  bulkExceptionModel);
    	var formData = new FormData();
        formData.append('bulkExceptionmodel', new Blob( [JSON.stringify( bulkExceptionModel )], {
            type: "application/json"
        }) );

        for ( let i = 0; i < files.length; i++ ) {
            formData.append( "file", files[i] );
        }

        return this.http.post( bulkUpdateServiceEndPoint, formData )
            .map( res => res.json() );
    }
    
    getUsersForExcpetionIds(exceptionIds): Observable<ExceptionUser[]> {
        console.debug('BulkUpdateService::getUsersForExcpetionIds',  exceptionIds);
        return this.http.get( expUserListURI + exceptionIds )
            .map( res => res.json() )   
    };

}
