import {inject, TestBed} from "@angular/core/testing";
import {ResponseOptions, Response, RequestMethod, HttpModule} from "@angular/http";
import {MockBackend} from "@angular/http/testing";

// Application services
import {APP_TEST_HTTP_PROVIDERS} from "../../testing";

import {HttpErrorHandler} from "../../services/http-error-handler";
import {AlertEditService} from "./alert-edit.service";
import {MockError, MockHttpErrorHandler} from '../../testing/mock.services';

//Service END Point URL should be declared as SERVICE END POINT
const statusMetaURI = '/api/exceptionrule/getmaster/exception_status';
const expUserListURI = '/api/exceptionsummary/getExceptionUsers/252838';
const getAlertURI = '/api/exceptionsummary/get/252838';
const getSecExcpRuleURI = '/api/exceptionsummary/getFlagedSecurityExceptionRule/252838';
const updateAlertURI = '/api/exceptionsummary/update';

//Service Mock response copied from current real service
const exceptionStatusMockResponse = [{"value":"1","text":"Open"},{"value":"2","text":"Under Review"},{"value":"3","text":"Resolved"}];
const exceptionUsersMockResponse = [
										{"groupId":1,"soeid":"10V","gpName":"10V CE Group","region":"Global","gpType":"Primary","primary":false},
										{"groupId":441,"soeid":"ja48224","gpName":"Aaronson, Jay (ja48224)","region":"NAM","gpType":"Primary","primary":true}
									];
const exceptionDataMockResponse = [
										{"rule_id":"482","rule_group_id":"2272","exception_activity_id":"254623","exception_id":252838,"version_id":"1","type":"Global (All Client)","priority":"High",
											"priority_id":null,"legal_entity":"ALL","client":"10V","region":"GLOBAL","fund":"ALL","country":"country","product":"product",
											"rule_period":"Current COB Date Vs Prior 30 Day Running Average","aggregation_level":"1","aggregation_level_name":"Client",
											"description":"Country Of Risk security level 30 day average rule","measure":"Change in GMV By Security Country of Risk Grouping","limit_type":null,
											"limit":"> 100,000,000","is_active":null,"threshold_type":null,"create_user":"Ligade, Shivaprasad Audumbar","create_time":"2017-01-30 05:18:14",
											"cob_date":"01-26-2017","open_date":"01-27-2017","status":"1","status_name":"Open","age":12,"comment":"test","file_name":null,"attachements":null,
											"exception_owner":"475","updatedby":null,"first_date":"01-26-2017","first_value":"3,364,808,736","second_date":"01-25-2017","second_value":"3,187,772,711",
											"delta":"177,036,025","delta_percent":"6","exception_owner_name":"Ligade, Shivaprasad Audumbar (sl98093)","client_fund":null,"is_security":true,
											"clientTier":"1-PLATINUM","is_primary":false,"is_clientgroup":false,"nam":null,"emea":null,"apac":null,"nam_aqua":null,"emea_aqua":null,"apac_aqua":null
										}
									];
const securityExceptionMockResponse = [
										{"security_attribute":"APAC Emerging Markets Lev2","first_date":"01-26-2017","first_value":"42,294,931","second_date":"01-25-2017","second_value":"54,427,667","change":"-12,132,736","change_percent":"22.29","composition_percent":"1.30","security_type":"country_of_risk_grouping","change_row":false},
										{"security_attribute":"Developed Markets","first_date":"01-26-2017","first_value":"2,701,898,274","second_date":"01-25-2017","second_value":"2,532,016,251","change":"169,882,023","change_percent":"6.71","composition_percent":"80.30","security_type":"country_of_risk_grouping","change_row":true},
										{"security_attribute":"Other","first_date":"01-26-2017","first_value":"620,615,530","second_date":"01-25-2017","second_value":"601,328,793","change":"19,286,737","change_percent":"3.21","composition_percent":"18.40","security_type":"country_of_risk_grouping","change_row":false},
										{"security_attribute":"Total","first_date":"01-26-2017","first_value":"3,364,808,736","second_date":"01-25-2017","second_value":"3,187,772,711","change":"177,036,025","change_percent":"5.55","composition_percent":"100","security_type":"country_of_risk_grouping","change_row":false}
									];
const exceptionMockModel = {"rule_id":"482","rule_group_id":"2272","exception_activity_id":"254623","exception_id":252838,"version_id":"1","type":"Global (All Client)","priority":"High",
								"priority_id":null,"legal_entity":"ALL","client":"10V","region":"GLOBAL","fund":"ALL","country":"country","product":"product",
								"rule_period":"Current COB Date Vs Prior 30 Day Running Average","aggregation_level":"1","aggregation_level_name":"Client",
								"description":"Country Of Risk security level 30 day average rule","measure":"Change in GMV By Security Country of Risk Grouping","limit_type":null,
								"limit":"> 100,000,000","is_active":null,"threshold_type":null,"create_user":"Ligade, Shivaprasad Audumbar","create_time":"2017-01-30 05:18:14",
								"cob_date":"01-26-2017","open_date":"01-27-2017","status":"1","status_name":"Open","age":12,"comment":"test","file_name":null,"attachements":null,
								"exception_owner":"475","updatedby":null,"first_date":"01-26-2017","first_value":"3,364,808,736","second_date":"01-25-2017","second_value":"3,187,772,711",
								"delta":"177,036,025","delta_percent":"6","exception_owner_name":"Ligade, Shivaprasad Audumbar (sl98093)","client_fund":null,"is_security":true,
								"clientTier":"1-PLATINUM","is_primary":false,"is_clientgroup":false,"nam":null,"emea":null,"apac":null,"nam_aqua":null,"emea_aqua":null,"apac_aqua":null
							};
const updateExceptionSuccessMockResponse = {"status": true, "message": "Alert Updated Successfully"};
const updateExceptionFailMockResponse = {"status": false, "message": ""};

describe('AlertEditService', () => {

    let alertEditService: AlertEditService;
    let backend: MockBackend;
	
	let exceptionId = 252838;

	beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpModule,
            ],
            providers: [
                {
                    provide: HttpErrorHandler,
                    useClass: MockHttpErrorHandler,
                },
                APP_TEST_HTTP_PROVIDERS,
                AlertEditService,
            ],
        });
    });

    beforeEach(inject([AlertEditService, MockBackend], (..._) => {
        [alertEditService, backend] = _;
    }));
    
    describe('.getStatus', () => {
    	describe('when alert status types are returned', () => {
    		it('status type list should be non-empty', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(exceptionStatusMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(statusMetaURI);
                });
                
                alertEditService.getStatus().subscribe(statusTypes => {
                	expect(statusTypes).not.toBeUndefined();
                	expect(statusTypes).not.toBeNull();
                	expect(statusTypes.length).toEqual(3);
                });                
            });
    	});
    	
    	describe('when alert status types are not returned', () => {
    		it('status type list should be empty', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(""),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(statusMetaURI);
                });
                
                alertEditService.getStatus().subscribe(statusTypes => {
                	expect(statusTypes).toBe("");
                });                
            });
    	});
    });
    
    describe('.getUsersByExcpetionId', () => {
    	describe('when users are returned', () => {
    		it('users list should be non-empty', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(exceptionUsersMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(expUserListURI);
                });
                
                alertEditService.getUsersByExcpetionId(exceptionId).subscribe(users => {
                	expect(users).not.toBeUndefined();
                	expect(users).not.toBeNull();
                	expect(users.length).toBeGreaterThan(0);
                });                
            });
    	});
    	
    	describe('when users load is failed and error is returned', () => {
            let subscription=undefined;
            
            beforeEach(function() {
                    subscription=backend.connections.subscribe(conn => {
                    conn.mockError(new MockError(new ResponseOptions(MockError.error_500)));
                });
            });
            
            afterEach(function() { subscription.unsubscribe(); });

            it("error data should be available", function() {
            	alertEditService.getUsersByExcpetionId(exceptionId).subscribe(users => {
                    expect(users).toBeUndefined();
                }, err => {
                	expect(err).toBeDefined();
        		});
            });
    	});
    });
    
    describe('.getData', () => {
    	describe('when alert data is returned', () => {
    		it('alert must have owner', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(exceptionDataMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getAlertURI);
                });
                
                alertEditService.getData(exceptionId).subscribe(data => {
                	expect(data).toBeDefined();
                	expect(data.length).toBeGreaterThan(0);
                	expect(data[0].exception_owner).toMatch(/^\d*$/);
                });                
            });
    	});
    });
    
    describe('.getFlagedSecurityExceptionRule', () => {
    	describe('when returned alert data is of security type', () => {
    		it('alert should have flagged security exception rule', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(securityExceptionMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Get);
                    expect(conn.request.url).toEqual(getSecExcpRuleURI);
                });
                
                alertEditService.getFlagedSecurityExceptionRule(exceptionId).subscribe(data => {
            		expect(data).toBeDefined();
                	expect(data.length).toBeGreaterThan(0);
                });               
            });
    	});
    });
    
    describe('.update', () => {
    	describe('when alert update is successful', () => {
    		it('status should be true', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(updateExceptionSuccessMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(updateAlertURI);
                });
                
                alertEditService.update(exceptionMockModel, []).subscribe(apiResponse => {
            		expect(apiResponse.status).toBeTruthy();
                });               
            });
    	});
    	
    	describe('when alert update fails', () => {
    		it('status should be false', () => {
                backend.connections.subscribe(conn => {
                    conn.mockRespond(new Response(new ResponseOptions({
                        body: JSON.stringify(updateExceptionFailMockResponse),
                    })));
                    expect(conn.request.method).toEqual(RequestMethod.Post);
                    expect(conn.request.url).toEqual(updateAlertURI);
                });
                
                alertEditService.update(exceptionMockModel, []).subscribe(apiResponse => {
            		expect(apiResponse.status).toBeFalsy();
                });               
            });
    	});
    });

});

