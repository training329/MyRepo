// Framework
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Response} from '@angular/http';
import "../../common/rxjs-operators";

// Application
import {JsonHttp} from "../../services/json-http";
import {HttpErrorHandler} from "../../services/http-error-handler";

import {Alert} from '../../models/alert';
import {ExceptionMaster} from '../../models/exception-master';
import {DropDownModel} from '../../models/dropdown-model';
import {APIResponse} from '../../models/api-response';
import {FlagedSecurityExceptionRule} from '../../models/flaged-security-exception-rule';
import {ExceptionUser} from '../../models/exception-user';

// Service END Point URL should be declared as SERVICE END POINT
const expUserListURI: string = '/api/exceptionsummary/getExceptionUsers/';
const updateAlertURI = '/api/exceptionsummary/update';
const statusMetaURI: string = '/api/exceptionrule/getmaster/exception_status';
const getAlertURI: string = '/api/exceptionsummary/get/';
const getSecExcpRuleURI: string = '/api/exceptionsummary/getFlagedSecurityExceptionRule/';

@Injectable()
export class AlertEditService {

    private statusDataObservable:Observable<ExceptionMaster[]>;
    
    constructor( private http: JsonHttp,
        private errorHandler: HttpErrorHandler ) {
        console.debug('AlertEditService::constructor');
    }

    getStatus(): Observable<ExceptionMaster[]> {
        console.debug('AlertEditService::getStatus', statusMetaURI);
        if(this.statusDataObservable == null){
            this.statusDataObservable = this.http.get( statusMetaURI )
            .map( res => res.json() )   
            .publishReplay(1)
            .refCount();
            
        }
        return this.statusDataObservable;
    }

    getData( id ): Observable<Alert[]> {
        console.debug('AlertEditService::console', getAlertURI + id);
        return this.http.get( getAlertURI + id )
            .map( res => res.json() )   

    };

    getUsersByExcpetionId( id ): Observable<ExceptionUser[]> {
        console.debug('AlertEditService::getUsersByExcpetionId',  id);
        return this.http.get( expUserListURI + id )
            .map( res => res.json() )   
    };

    getFlagedSecurityExceptionRule( id ): Observable<FlagedSecurityExceptionRule[]> {
        console.debug('AlertEditService::getFlagedSecurityExceptionRule',  id);
        return this.http.get( getSecExcpRuleURI + id )
            .map( res => res.json() )   
    }

    update( flaggedExceptionModel: Alert, files: File[] ): Observable<APIResponse> {
        console.debug('AlertEditService::update', flaggedExceptionModel, files.length);
        var formData = new FormData();
        formData.append( 'flaggedExceptionModel', new Blob( [JSON.stringify( flaggedExceptionModel )], {
            type: "application/json"
        }) );

        for ( let i = 0; i < files.length; i++ ) {
            formData.append( "file", files[i] );
        }

        return this.http.post( updateAlertURI, formData )
            .map( res => res.json() )   
    }
  
    
    filterUser( query, users: DropDownModel[] ): any[] {
            console.debug('AlertEditService::filterUser', query, users);
            //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
            let filtered: any[] = [];
            for ( let i = 0; i < users.length; i++ ) {
                let user = users[i];
                if ( user.text.toLowerCase().indexOf( query.toLowerCase() ) > -1 || user.value.toLowerCase().indexOf( query.toLowerCase() ) > -1 ) {
                    filtered.push( user );
                }
            }
            return filtered;
     }
   
    getSecurityAtrributs( key ) {
        console.debug('AlertEditService::getSecurityAtrributs', key);

        //TODO: Write a generic transfer, preferably with RegExp to replace("_"," "), and uppercase each char after " "
        var label = "";
        switch ( key ) {
            case "country_of_risk_grouping":
                label = "Country Of Risk Grouping";
                break;
            case "product_grouping":
                label = "Product Grouping";
                break;
            case "sector":
                label = "Sector";
                break;
            case "marketcap":
                label = "Market Cap";
                break;
        }
        return label;
    };

    getColor( data ) {
        console.debug('AlertEditService::getColor');
        if ( data )
            return {
                backgroundColor: '#FFFF99'
            }
    };
}
