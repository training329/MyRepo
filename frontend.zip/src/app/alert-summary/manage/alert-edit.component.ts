// Framework
import {Component, ElementRef, SimpleChange, Input, OnDestroy, AfterViewChecked, ViewChild} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {Location}  from '@angular/common';
import {Observable} from 'rxjs/Observable';
import {Subscription} from 'rxjs/Subscription';
import {NgForm} from '@angular/forms';

// KEEP THE FOLLOWING LINE TO PREVEN TS ERRORS:
/// <reference path="./toaster.d.ts" />
import * as toastr from 'toastr';
import * as _ from 'underscore';

// Application Component
import {Alert} from '../../models/alert';
import {DropDownModel} from '../../models/dropdown-model';
import {HttpErrorHandler} from "../../services/http-error-handler";
import {AlertEditService} from "./alert-edit.service";
import {AlertSummaryService} from "../alert-summary.service";
import {ExceptionMaster} from '../../models/exception-master';
import {FlagedSecurityExceptionRule} from '../../models/flaged-security-exception-rule';
import {ExceptionUser} from '../../models/exception-user';

// Application Shared
import {SelectItem} from '../../common/api';


@Component({
    selector: 'cba-alert-edit',
    styleUrls: ['./alert-edit.component.scss'],
    templateUrl: './alert-edit.component.html',
    providers: [HttpErrorHandler]
})

export class AlertEditComponent implements OnDestroy {
    private sub:any;
	private formChangeSubScription : Subscription;

    id:number;
    cobdate:number;
    exceptionmodel:Alert;
    oldModel:Alert;
    selectedUser:DropDownModel;
    selectedStatus:ExceptionMaster;

    alerts:Array<Alert>;

    // TODO: Filter on server side - use an array of ExceptionAlerts, not a single one - so it works also on BulkEdit
    users:Array<ExceptionUser>;

    filteredUsers:Array<DropDownModel>;
    statusTypes:Array<ExceptionMaster>;
    flagedSecurityExceptionRule:FlagedSecurityExceptionRule[];
    historyList:Array<Alert>;
    files:any[] = [];

    isChange:boolean = false;

    // Form 
    // Reset the form with a new hero AND restore 'pristine' class state
    // by toggling 'active' flag which causes the form
    // to be removed/re-added in a tick via NgIf
    // TODO: Workaround until NgForm has a reset method (#6822)
    active = true;
    alertForm:NgForm;
    submitted = false;

    @ViewChild('alertForm') currentForm:NgForm;
    @ViewChild('fileInput') fileInput:any;

    // initialization
    constructor(private router:Router,
                private errorHandler:HttpErrorHandler,
                private route:ActivatedRoute,
                private location:Location,
                private alertEditService:AlertEditService,
                private alertSummaryService:AlertSummaryService) {

        console.debug('AlertEditComponent::constructor');
        // read router parameter
        this.sub = this.route.params.subscribe(params => {
            this.id = +params['id'];  // (+) converts string 'id' to a number
        });

        // get dropdown metadata
        this.getMetaData();
        this.getAlertData();
    }

    getMetaData() {
        console.debug('AlertEditComponent::getMetaData');
        this.alertEditService.getStatus().subscribe(exceptionMaster => {
            this.statusTypes = exceptionMaster;
        }, e => {
			toastr.error('Error while getting alert status types. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
        
        this.alertEditService.getUsersByExcpetionId(this.id).subscribe(users => {
            this.users = users;
        }, e => {
			toastr.error('Error while getting users. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }

    getAlertData(refresh:boolean = false) {
        console.debug('AlertEditComponent::getAlertData ', refresh);
        this.alertEditService.getData(this.id).subscribe(data => {
            if (data) {
                var filterdata = _.sortBy(data, function (val) {
                    return -val.exception_activity_id;
                });
                this.exceptionmodel = _.clone(filterdata[0]);
                if (refresh == false)
                    this.exceptionmodel.comment = ''; // avoid refreshing after editing.
                // this.customSelected = this.exceptionmodel.exception_owner;
                this.isChange = false;
                var splitted = this.exceptionmodel.cob_date.split("-");
                this.cobdate = parseInt(splitted[2]
                    + splitted[0] + splitted[1]);


                if (this.exceptionmodel.is_security) {
                    this.alertEditService.getFlagedSecurityExceptionRule(this.id)
                        .subscribe(flagedSecurityExceptionRule => {
                            this.flagedSecurityExceptionRule = flagedSecurityExceptionRule;
                        }, e => {
                			toastr.error('Error while getting excpetion rule. Please try again or contact AQUA RACE support', 'Error');
                			this.errorHandler.handle(e);
                		});
                }

                for (let status of this.statusTypes) {
                    console.log(status.text + ' inside get alert data' + this.exceptionmodel.status_name);
                    if (status.text == this.exceptionmodel.status_name) {
                        this.selectedStatus = status as ExceptionMaster;
                        break;
                    }
                }

                this.oldModel = _.clone(this.exceptionmodel);
                this.historyList = _.clone(filterdata);
                
                // add form change listener, when form is completely loaded 
                setTimeout(() => {
                       this.formChanged();
                }, 1000);
                
//                if(this.alertForm)
//                    this.alertForm.reset();
            }

        }, e => {
			toastr.error('Error while getting alert data. Please try again or contact AQUA RACE support', 'Error');
			this.errorHandler.handle(e);
		});
    }

    save(exceptionmodel:Alert, isValid:boolean):void {
        console.debug('AlertEditComponent::save', exceptionmodel, isValid);
        this.alertEditService.update(this.exceptionmodel, this.files)
            .subscribe(apiResponse => {
                console.log(apiResponse)
                this.files = [];
                if (apiResponse.status) {
                    toastr.success(apiResponse.message);
                    this.active = false;
                    this.active = true;
                    this.getAlertData(true);
                    this.alertSummaryService.clearCache();
                } else {
                    toastr.error(apiResponse.message, 'Error');
                }
            }, e => {
            	this.files = [];
    			toastr.error('Error while updating alert. Please try again or contact AQUA RACE support', 'Error');
    			this.errorHandler.handle(e);
    		});
    }

    goBack():void {
        console.debug('AlertEditComponent::goBack');
        this.files = [];
        this.location.back();
    }

    ngOnDestroy() {
    	console.debug('AlertEditComponent::ngOnDestroy');
        this.sub.unsubscribe();
        if (this.formChangeSubScription) {
        	this.formChangeSubScription.unsubscribe();
        }        
    }

    formChanged() {
        console.debug('AlertEditComponent::formChanged');
        if (this.currentForm === this.alertForm) {
            return;
        }
        this.alertForm = this.currentForm;
        if (this.alertForm) {
        	this.formChangeSubScription = this.alertForm.valueChanges
                .subscribe(data => this.onValueChanged(data));
        }
    }
    
	onValueChanged(data?: any) {
		console.debug("AlertEditComponent::onValueChanged");
	    if (!this.alertForm) { return; }
	   	this.checkDataModification();
	}
    	  
    checkDataModification(): void {
    	console.debug("AlertEditComponent::checkDataModification");
        if ( this.exceptionmodel.status != '' || this.exceptionmodel.exception_owner != '' || this.exceptionmodel.comment != ''  || (this.files && this.files.length > 0)) {
        	if (this.exceptionmodel.status != '' && this.exceptionmodel.status == "3" && this.exceptionmodel.comment == '') {
        		this.isChange = false;
                const messages = this.validationMessages['comment'];
                console.log("Error : " + messages);
                this.formErrors['comment'] = '';
                this.formErrors['comment'] += messages + ' ';
        	} else {
        		this.isChange = true;
        		this.formErrors['comment'] = '';
        	}	
        } else {
        	this.isChange = false;
        }
    }

    formErrors = {
        'comment': ''
    };

    validationMessages = {
        'comment': 'Comment is required.'
    };

    uploadFile($event):void {
        console.debug('AlertEditComponent::uploadFile ', $event);
        for (let file of $event.target.files) {
        	// Add file only if it is not present already
        	var isPresent = _.find(this.files, function(existingFile){ return existingFile.name == file.name; });
        	if (isPresent) {
        		this.removeFile(file.name);
        	}
        	this.files.push(file);
        }
        this.fileInput.nativeElement.value = null;
        this.checkDataModification();
    }
    
    removeFile(fileName) {
    	console.debug('AlertEditComponent::removeFile ', fileName);
    	this.files = _.filter(this.files, function(file) { 
    		return file.name != fileName; 
    	});
        this.checkDataModification();
    }
    
    getSecurityAtrributs(key) {
        console.debug('AlertEditComponent::getSecurityAtrributs', key);
        return this.alertEditService.getSecurityAtrributs(key);
    };

    //TODO: Refactor to use plain CSS
    getColor(data) {
    	console.debug('AlertEditComponent::getColor ', data);
        if (data)
            return {backgroundColor: '#FFFF99'}
    };

    onExceptionOwnerChange(event) {
    	console.debug('AlertEditComponent::onExceptionOwnerChange', event);

        this.isChange = true;
        for (let user of this.users) {
        	if (this.exceptionmodel && user.groupId == event.userGrpId) {
                this.exceptionmodel.exception_owner = user.groupId + '';
                this.exceptionmodel.exception_owner_name = user.gpName;
                if (user.gpType == "Primary" && user.region == "Global") {
                    this.exceptionmodel.is_clientgroup = true;
                } else {
                    this.exceptionmodel.is_clientgroup = false;
                }
                break;
            }
        }
    }

    isUndefinedOrNull(val) {
        console.debug('AlertEditComponent::isUndefinedOrNull, ', val);
        return val === undefined || val === null || val == '';
    }

    onStatusChange(statusType) {
        console.debug('AlertEditComponent::onStatusChange, ', statusType);
        if (!this.isUndefinedOrNull(statusType) && "3" === statusType && this.isUndefinedOrNull(this.exceptionmodel.comment)) {
            const messages = this.validationMessages["comment"];
            console.log("Error : " + messages);
            this.formErrors["comment"] = '';
            this.formErrors["comment"] += messages + ' ';
            this.isChange = false;
        } else {
            this.formErrors["comment"] = '';
            this.isChange = true;
        }
    }
}

