// Framework
import {Component, ElementRef, Input } from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {Observable} from 'rxjs/Observable';

// Application Component
import {Alert} from '../../models/alert';
import {HttpErrorHandler} from "../../services/http-error-handler";
import {AlertEditService} from "./alert-edit.service";

//Application Shared
import {SelectItem} from '../../common/api';

@Component( {
    selector: 'cba-alert-edit-history',
    styleUrls: ['./alert-edit.component.scss'],
    templateUrl: './alert-edit-history.component.html',
    providers: [HttpErrorHandler]
})
export class AlertEditHistoryComponent  {
    
    cols: any[] = [];
    columnOptions: SelectItem[] = [];
    totalPages: number;
    totalRecords: number = 0;
    page: number;

    alerts: Array<Alert>;
    @Input()  historyList: Array<Alert>;

    constructor( private router: Router,
        private errorHandler: HttpErrorHandler,
        private route: ActivatedRoute,
        private alertEditService: AlertEditService ) {

        this.cols = [
            { header: 'Status', field: 'status_name', style:{'text-align':'left'}  },
            { header: 'Comments', field: 'comment', style:{'text-align':'left'}  },
            { header: 'Alert Owner', field: 'exception_owner_name', style:{'text-align':'left'}  },
            { header: 'Updated By', field: 'create_user', style:{'text-align':'left'}  },
            { header: 'Update Time', field: 'create_time', style:{'text-align':'left'}  },
        ];

        this.columnOptions = [];
        for ( let i = 0; i < this.cols.length; i++ ) {
            this.columnOptions.push( { label: this.cols[i].header, value: this.cols[i] });
        }
        console.debug('AlertEditHistoryComponent::constructor');
    }


}

