// Framework
import {Component, ElementRef, Input, OnInit, SimpleChange} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import { ChartModule } from 'angular2-highcharts'; 
import {MenuItem} from 'primeng/primeng';
import {LazyLoadEvent} from '../common/api';
import {FilterMetadata} from '../common/api';

// Application Component
import {Alert} from '../models/alert';
import {HttpErrorHandler} from "../services/http-error-handler";
import {AlertSummaryService} from "./alert-summary.service";

// Application Shared
import {SelectItem} from '../common/api';

@Component({
  selector: 'cba-my-alerts',
  styleUrls: ['./alert-summary.component.scss'],
  templateUrl: './all-alerts.component.html',
  providers: [HttpErrorHandler]
})
export class MyAlertsComponent implements OnInit {
  	cols: any[] = [];
  	columnOptions: SelectItem[] = [];
  	totalPages: number;
    totalRecords: number = 0;
  	page: number;
	toggleColumn: string = "Toggle Columns";
    
    alerts:Array<Alert>;
	private items: MenuItem[];
	@Input() datasource: Array<Alert>;
	@Input() globalFilter:any;
	
  	constructor(private router:Router,
              private errorHandler: HttpErrorHandler,
              private route: ActivatedRoute,
              private alertSummaryService:AlertSummaryService) {

  	  this.items = [
  	              {label: 'My Alert', icon: 'fa-bar-chart'},
  	              {label: 'Alerts', icon: 'fa-calendar'},
  	              {label: 'Resolved Alerts', icon: 'fa-book'}
  	          ];
  	    
      this.cols = [
          {header:'ALERT#', field:'exception_id'},
          {header:'COB DATE', field:'cob_date'},
          {header:'PRIORITY', field:'priority' },
          {header:'AGE', field:'age' },
          {header:'STATUS', field:'status_name'},
          {header:'CLIENT/FUND', field:'client'},
          {header:'REGION', field:'region' },
          {header:'DATA TYPE', field:'measure' },
          {header:'PERIOD', field:'limit'},
          {header:'COB VALUE', field:'first_value'},
          {header:'PREV VALUE', field:'second_value'},
          {header:'CHANGE', field:'delta' },
          {header:'% CHANGE', field:'delta_percent' },
          {header:'ALERT OWNER', field:'exception_owner_name'}
      ];
      
      this.columnOptions = [];
      for(let i = 0; i < this.cols.length; i++) {
          this.columnOptions.push({label: this.cols[i].header, value: this.cols[i]});
      }
  }
  	
  	updateLabel() {
  	console.log("inside update label");

  }
  	
  ngOnInit() {
//      this.route.params.subscribe(params => {
//          this.page = +(params['page'] || 1);
//          this.list(this.page);
//      });

      // this.alertSummaryService.get().subscribe(res => {
      //     this.alerts = res;
      //     //console.log(this.alerts);
      // })
  }

  // private list(page: number) {
  //       this.alertSummaryService.list({page: page, size: 5})
  //           .subscribe(alertsPage => {
  //               // this.alerts = alertsPage.content;
  //               // this.totalPages = alertsPage.totalPages;
  //               this.alerts = alertsPage;
  //           }, e => this.errorHandler.handle(e))
  //       ;
  // }
  
  ngOnChanges(changes: SimpleChange) { 
      console.log("alerts summary data data load ",changes);
      console.log("alerts",this.datasource);
      if(this.datasource){
          this.totalRecords = this.datasource.length;
         // this.datasource = this.alerts
          this.alerts = this.datasource; 
      }
     
  }

  loadAlertsLazy(event: LazyLoadEvent) {
      //in a real application, make a remote request to load data using state metadata from event
      //event.first = First row offset
      //event.rows = Number of rows per page
      //event.sortField = Field name to sort with
      //event.sortOrder = Sort order as number, 1 for asc and -1 for dec
      //filters: FilterMetadata object having field as key and filter value, filter matchMode as value
      
      //imitate db connection over a network
      setTimeout(() => {
          this.alerts = this.datasource.slice(event.first, (event.first + event.rows));
      }, 250);
  }

  // TODO: To implement pagination

    // onPageChanged(page: number) {
    //     this.router.navigate(['/alerts', {page: page}]);
    // }

}

