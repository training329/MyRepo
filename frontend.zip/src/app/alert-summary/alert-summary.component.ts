// Framework
import {Component, ElementRef, OnInit, OnDestroy} from "@angular/core";
import {FormControl} from "@angular/forms";
import {ActivatedRoute, Router, NavigationEnd} from "@angular/router";
import {Subscription} from 'rxjs/Subscription';
import {Subject, Observable} from "rxjs/Rx";

import {ChartModule} from  'angular2-highcharts';
import * as _ from 'underscore';
import * as toastr from 'toastr';

// Application Component
import {Alert} from '../models/alert';
import {HttpErrorHandler} from "../services/http-error-handler";
import {AlertSummaryService} from "./alert-summary.service";
import {LoginService} from "../services/login.service";
import {AppStateService} from "../services/app-state.service";
import {UtilService} from "../services/util.service";
import {EventBusService} from '../services';

// Application Shared
import {SelectItem} from '../common/api';

@Component({
    selector: 'cba-summary',
    styleUrls: ['./alert-summary.component.scss'],
    templateUrl: './alert-summary.component.html',
    // TODO: Check if we can use a global instance for the HttpErrorHandler provider instead of localy instantiated
    host: {
        '(window:resize)': 'onResize($event)'
    }
})

export class AlertSummaryComponent implements OnInit, OnDestroy {
    
	//register controls in TS
    private filterRangeFrom:Date;
    private filterRangeTo:Date;

    private isClassVisible:Boolean = false;

    private alerts:Array<Alert> = [];

    private myAlerts:Array<Alert> = [];
    private allAlerts:Array<Alert> = [];
    private resolvedAlerts:Array<Alert> = [];

    private myAlertsDataSource:Array<Alert> = [];
    private allAlertsDataSource:Array<Alert> = [];
    private resolvedDataSource:Array<Alert> = [];

    private cols:any[] = [];
    private columnOptions:SelectItem[] = [];
    private totalPages:number;
    private page:number;
    private toggleColumn:string = "Toggle Columns";

    private searchTerm:string = "";
    private termControl:FormControl = new FormControl();

    private soeid:string = "";
    private showFilterMenu:boolean;
    private showBulkDialog:boolean;
    private selectedTab: number = 2;
    private showToolBar:boolean = true;
    // private serachSubscription:Subscription;
    private routeEventSubscription:Subscription;
    
    //bulk update
    private selectedAlerts:Array<Alert>;
    private bulkUpdateButtonEnable:boolean = false;
    private showBulkUpdateDialogNotify:Subject<any> = new Subject();
    private onDataTableResetNotify:Subject<any> = new Subject();

    constructor(private router:Router,
                private errorHandler:HttpErrorHandler,
                private route:ActivatedRoute,
                private alertSummaryService:AlertSummaryService,
                private loginService:LoginService,
                private appStateService:AppStateService,
                private utilService:UtilService,
                private eventBusService:EventBusService) {
        console.debug('AlertSummaryComponent::constructor');

        let searchTerm = this.appStateService.getModuleGlobalState('summary', 'search');
        if(searchTerm)
            this.searchTerm = searchTerm;
        
        // Bind search call to formControl
        this.termControl.valueChanges
            .debounceTime(400)
            .distinctUntilChanged()
            .subscribe(term => {
                let searchTerm = this.appStateService.getModuleGlobalState('summary', 'search')
                if(term != null && term != searchTerm){
                    this.alertSummaryService.setSearchTerm(term);
                    this.appStateService.setModuleGlobalState('summary', 'search', term);
                    console.debug(this.router.routerState.snapshot.url);

                    // reset child route state
                    this.appStateService.clearModuleStateByMatch('summary/');
                }
            })

        
        this.alertSummaryService.loadSelectedAlerts()
        .subscribe( event => {
            console.debug('AlertSummaryComponent::onBulkUpdateButtonEnable ', event);
            if(event){
                this.selectedAlerts = event.selectedAlerts;
                this.bulkUpdateButtonEnable = event.enabled;
               
            }
        });
        
    }

    ngOnInit() {
        this.soeid = this.loginService.getUserSoeId();
        console.debug('AlertSummaryComponent::onInit: ', 'subscribing to route.params');
        
         this.routeEventSubscription = this.router.events
         .map( event => event instanceof NavigationEnd )
         .distinctUntilChanged()
         .subscribe( () => {
             console.log(' AlertSummaryComponent:: ngOnInit NavigationEnd:', this.router.routerState.snapshot.url);
                 if(this.router.routerState.snapshot.url.indexOf('alert-item') > 0){
                     this.showToolBar = false;
                   }else{
                     this.tabClick(this.router.routerState.snapshot.url);
                     this.showToolBar = true;
                 }
         });
        this.listCached(1);
        this.eventBusService.listen('searchTerm').subscribe((customEvent)=>{
            console.log('AlertSummaryComponent::eventBusService.listen: searchTerm event', customEvent.detail.term);
            if(customEvent.detail) {
                this.searchTerm = customEvent.detail.term;
            }    
        });
    }
    
    onResize(event) {
        console.debug("new width: " + event.target.innerWidth + "   new height: " + event.target.innerHeight);
    }

    tabClick(index) {
        console.debug('AlertSummaryComponent::tabClick ', index);
        if (this.router.routerState.snapshot.url.indexOf('myalerts') > 0) {
        	this.selectedTab = 2;
        } else if (this.router.routerState.snapshot.url.indexOf('all') > 0) {
        	this.selectedTab = 1;
        } else {
        	this.selectedTab = 3;
        }
        this.selectedAlerts = [];
        this.bulkUpdateButtonEnable = false;
        this.onDataTableResetNotify.next({reset: true});
        this.isClassVisible = false;
        setTimeout(() => {
            this.isClassVisible = true;
        }, 500)
    }

    onMenuBeforeShow(event, msg) {
        console.debug('AlertSummaryComponent::onMenuBeforeShow: ' + msg, event);
        this.showFilterMenu = true;
    }

    /**
     * Load all the alerts
     * @param page
     */
    private listCached(page:number) {
        console.debug('AlertSummaryComponent::listCached: ', 'subscribing to alertSummaryService.isReady');
        this.alertSummaryService.getDataNotification()
            .subscribe(isReady => {
                console.debug('AlertSummaryComponent::listCached: ', 'subscriptions completed', isReady);
                
                if(isReady)
                    this.updateAlertCount();

            }, e => {
    			toastr.error('Error while getting alerts summary. Please try again or contact AQUA RACE support', 'Error');
    			this.errorHandler.handle(e);
    		});
    }
    
    private updateAlertCount(){
        
        console.time("AlertSummaryComponent::updateAlertCount ");
        this.selectedAlerts = [];
        this.bulkUpdateButtonEnable = false;
        
        this.allAlertsDataSource = this.alertSummaryService.getAlertsOpen();
        this.myAlertsDataSource = this.alertSummaryService.getAlertsMy();
        this.resolvedDataSource = this.alertSummaryService.getAlertsClosed();
        
        this.appStateService.activateModuleState('summary');
        console.timeEnd("AlertSummaryComponent::updateAlertCount ");
    }

    showBulkUpdateDialog():void {
        console.debug('AlertSummaryComponent::showBulkUpdateDialog ');
        this.showBulkDialog = true;
        // added delay for event so that component onInit should be invoked by the time.
        setTimeout(() => {
            this.showBulkUpdateDialogNotify.next({selectedAlerts: this.selectedAlerts, enabled: true});
        },1000);
    }

    onSaveRefreshDSNotify(event):void {
        console.debug('AlertSummaryComponent::onSaveRefreshDSNotify ', event);
        if (event.refresh) {
            this.alertSummaryService.clearCache();
            // this.list(this.page);
            this.listCached(this.page);
        }
    }
    
    ngOnDestroy(){
        console.debug('AlertSummaryComponent::ngOnDestory: ');
        this.routeEventSubscription.unsubscribe();
        this.appStateService.deactivateModuleState('summary');
    }
    
    clearSearch() {
		console.debug('AlertSummaryComponent::clearSearch');
		this.searchTerm = "";
	}

}

