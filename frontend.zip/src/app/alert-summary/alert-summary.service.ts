// Framework
import {Injectable} from '@angular/core';
import {ReactiveFormsModule} from '@angular/forms';
import {Observable} from 'rxjs/Observable';
import {BehaviorSubject} from "rxjs/Rx";
import {Subscription} from 'rxjs/Subscription';
import {Response} from '@angular/http';
import * as _ from 'underscore';
import * as toastr from 'toastr';
import "../common/rxjs-operators";

// Application
import {PageRequest, Page, UserParams} from "../shared/dto";
import {JsonHttp} from "../services/json-http";
import {objToSearchParams} from "../services/helpers";
import {AppStateService} from  "../services/app-state.service";
import {EventBusService} from  "../services/event-bus.service";
import {Alert, AlertTableData} from '../models/alert';
import {UtilService} from "../services/util.service";

// Service END Point URL should be declared as SERVICE END POINT
const uri_flaggedExceptionList = '/api/exceptionsummary/flaggedexceptionlist.json';
const exportToExcelURI = '/api/exceptionsummary/export/';

//Todo: Implement Client/Server Pagination to AllException request
const defaultPageRequest:PageRequest = {page: 1, size: 5};

@Injectable()
export class AlertSummaryService {


    /**
     * Indicates when service is in process of loading data from backend
     * @type {boolean}
     */
    private isLoadingData:boolean = false;

    /**
     *  Observable to subscribe to receive data loaded notification
     *  Check implementation details here: https://github.com/ReactiveX/rxjs/blob/master/doc/subject.md
     *  Idea is to use the Subject to communicate completion of data retrieval process in service
     * @type {BehaviorSubject}
     */
    private dataIsReady:BehaviorSubject<boolean> = new BehaviorSubject(false);
    //     BehaviorSubject.create(
    //     v => {console.debug("AlertSummaryService::dataIsReady::OnNext",v);},
    //     e => {console.error("AlertSummaryService::dataIsReady::OnErr", e);},
    //     ()=> {console.debug("AlertSummaryService::dataIsReady::Completed");}
    // );

    public selectedAlertsData:BehaviorSubject<{}> = new BehaviorSubject({});


    // Caching all data in service
    private alerts_my:Alert[];
    private alerts_open:Alert[];
    private alerts_closed:Alert[];
    
    private alertsData:Alert[];
    private myAlertsData:Alert[];
    private allAlertsData:Alert[];
    private resolvedAlertsData:Alert[];

    public myAlertTableCurrentPage:number = 0;
    public allAlertTableCurrentPage:number = 0;
    public resolvedAlertTableCurrentPage:number = 0;

    private alertsDataObservable:Observable<Alert[]>;
    private alertsSubscription:Subscription;
    
    constructor(private http:JsonHttp,
                private eventBusService:EventBusService,
                private appStateService:AppStateService,
                private utilService: UtilService) {
        console.debug("AlertSummaryService::constructor");       
        
        this.eventBusService.listen('ClearCacheOnUserUpdate').subscribe((customEvent)=>{
            console.log('AlertSummaryService::eventBusService.listen: ClearCacheOnUserUpdate event');
            this.clearCache(); 
        });
    }

    /**
     * Performs request of all Alerts data from backend
     * Logic:
     * 1. Make a server call to backend and get all the alerts
     * 2. Process them into three groups doing following only once:
     *  a). Split the alerts into my, all and closed, and
     *  b). Sort by default
     *  c). Enrich with CELL STYLE rendering data
     * @param pageRequest
     * @returns {Observable<boolean>}  - true when data is finished loading.
     */

    loadAll(pageRequest:PageRequest = defaultPageRequest):Observable<boolean> {
        console.time("AlertSummaryService::loadAll GET:" + uri_flaggedExceptionList);

        // fire up the request to backend service
        // mark loading by service. Note: it will become false once all the three tables are produced from response
        this.isLoadingData = true;
        this.dataIsReady.next(false);
        
        this.alertsDataObservable = this.http.get(uri_flaggedExceptionList, {search: objToSearchParams(pageRequest)})
            .map(res => res.json())   // both result and error responsens are handled by Observable
            .publishLast() // required to prevent multiple requests
            .refCount()
            .catch((error:any) => Observable.throw(error.json().error || 'Server error'))
            .finally(()=> {
                console.timeEnd("AlertSummaryService::loadAll GET:" + uri_flaggedExceptionList)
            });
   
        // subscribe to HTTP Get Observable
        this.alertsSubscription = this.alertsDataObservable.subscribe(
            data => {
                this.isLoadingData = false;
                this.loadAlerts(data);
                // notify calling service subscribers
                this.dataIsReady.next(true);
            },
            err => {  // Log errors if any
            	toastr.error('Error while getting alerts data. Please try again or contact AQUA RACE support', 'Error');
                console.error(err);
                this.isLoadingData = false;
                // notify calling service subscribers
                this.dataIsReady.next(true);
            },
            () => console.debug("AlertSummaryService::loadAll GET unsubscribe")
        );
        
        // return Observable to calling component to notify when data is ready to be requested directly
        return this.dataIsReady.asObservable();
    }
    
    
    getDataNotification():Observable<boolean> {
        if(this.alertsDataObservable == null){
            this.loadAll({page: 1, size: 5})
        }
        return this.dataIsReady.asObservable();
    }

    /**
     * Perform filtering loaded data into my, open and closed
     * @param data
     */
    loadAlerts(data:Alert[]):void {
        console.debug("AlertSummaryService::loadAlerts ", data.length);
        if (data && data.length > 0) {
            console.time("AlertSummaryService::loadAlerts - sorting");
            // store alerts
            this.alertsData = data;
            
            // filter the data once instead of doing it on each page
            // init my alerts
            this.myAlertsData = this.filterMyAlerts(this.alertsData);
            // init all alerts
            this.allAlertsData = this.filterOpenAlerts(this.alertsData);
            // init closed alerts
            this.resolvedAlertsData = this.filterResolvedAlerts(this.alertsData);
            
            this.setSearchTerm(this.appStateService.getModuleGlobalState('summary', 'search'));
            console.timeEnd("AlertSummaryService::loadAlerts - sorting");
        }
    }

    setSearchTerm(term:string){
        term = term ? term : "";
        if(!this.isLoadingData){
            console.time("AlertSummaryService::setSearchTerm " + term);
            if (term === "") {
                // init my alerts
                this.alerts_my = this.myAlertsData;
                // init all alerts
                this.alerts_open = this.allAlertsData;
                // init closed alerts
                this.alerts_closed = this.resolvedAlertsData;
            } else {
                // init my alerts
                this.alerts_my = this.filterDataByTerm(term, this.myAlertsData);
                // init all alerts
                this.alerts_open = this.filterDataByTerm(term, this.allAlertsData);
                // init closed alerts
                this.alerts_closed = this.filterDataByTerm(term, this.resolvedAlertsData);
            }
            
            // trriger change for listener
            this.dataIsReady.next(true);
            console.timeEnd("AlertSummaryService::setSearchTerm " + term);
        }
    }
    
    
    /**
     * Get user assigned alerts
     * @returns {Alert[]}
     */
    getAlertsMy():Alert[] {
        return this.alerts_my;
    }

    /**
     * Get all open alerts
     * @returns {Alert[]}
     */
    getAlertsOpen():Alert[] {
        return this.alerts_open;
    }

    /**
     * Get all resolved alerts
     * @returns {Alert[]}
     */
    getAlertsClosed():Alert[] {
        return this.alerts_closed;
    }
    
    getAllAlerts():Alert[] {
        return this.alertsData;
    }
    
    setSelectedAlerts(selectedAlerts):void{
        this.selectedAlertsData.next(selectedAlerts);
    }
    
    loadSelectedAlerts():Observable<any>{
        return this.selectedAlertsData.asObservable();
    }

    // set status flag
    getAlertsLoadStatus():Observable<boolean> {
        return Observable.of(this.isLoadingData); // check when first value emmited;
    }
    //
    // // Request with page and check for server response by leaving error response to be called in
    // // calling this service component
    // list(pageRequest:PageRequest = defaultPageRequest):Observable<Alert[]> {
    //     console.time("AlertSummaryService::list" + uri_flaggedExceptionList);
    //     if (!this.alertsData) {
    //         this.alertsData = this.http.get(uri_flaggedExceptionList, {search: objToSearchParams(pageRequest)})
    //             .map(res => res.json())   // both result and error responsens are handled by Observable
    //             .publishReplay(1)
    //             .refCount()
    //             .do(d => console.debug("AlertSummaryService::list observers subscribed: page:", pageRequest));
    //     }
    //     console.timeEnd("AlertSummaryService::list" + uri_flaggedExceptionList);
    //     return this.alertsData;
    // }

    get():Observable<Alert[]> {
        console.debug("AlertSummaryService::get");

        return this.http.get(uri_flaggedExceptionList, {search: objToSearchParams('p=dummy')})
            .map
            //<Alert[]>
            ((res:Response) => res.json());
    }

    clearCache():void {
        console.debug("AlertSummaryService::clearCache");
        if(this.alertsSubscription)
        	this.alertsSubscription.unsubscribe();
        this.alertsDataObservable = null;
        this.alerts_my = null;
        this.alerts_open = null;
        this.alerts_closed = null;
    }

    // TODO: Introduce RESULT variable and time function to tune performance
    filterOpenAlerts(alerts:Array<Alert>):Array<Alert> {
        console.debug("AlertSummaryService::filterOpenAlerts {TODO here}");
        return _.filter(alerts,
            function (val) {
                return val.status_name == 'Open' || val.status_name == 'Under Review'
            }
        );
    }

    filterMyAlerts(alerts:Array<Alert>):Array<Alert> {
        console.debug("AlertSummaryService::filterMyAlerts");
        return _.filter(alerts,
            function (val) {
                return (val.is_primary && ((val.status_name === 'Open') || (val.status_name === 'Under Review')))
            }
        );

    }

    filterResolvedAlerts(alerts:Array<Alert>):Array<Alert> {
        console.debug("AlertSummaryService::filterResolvedAlerts");
        return _.filter(alerts,
            function (val) {
                return val.status_name == 'Resolved'
            }
        );
    }


    // TODO: To refactor to work on Service Local data instead of passing it from outside
    // TODO:  All data read method should include filter terms - if null - pass all data
    // TODO:  if the filter term not null - apply this function
    filterDataByTerm(searchTerm, data) {
        console.time('AlertSummaryService::filterDataByTerm ' + searchTerm);
        var result = data;
        if (searchTerm != null && data) {
            var criterias = ["client", "exception_owner_name", "exception_id", "clientTier"];
            var term = searchTerm.toLowerCase();
            result = data.filter(function (item) {
                var found = false;
                criterias.forEach((criteria:string) => {
                    if (item[criteria] && ((item[criteria]).toString().toLowerCase()).indexOf(term) != -1) {
                        return found = true;
                    }
                })
                return found;
            });
        }
        console.timeEnd('AlertSummaryService::filterDataByTerm ' + searchTerm);
        return result;
    };

    // TODO: Move the logic into AlertsData table additional columns
    // TODO: Extend Alet model and add CELL STYLE columns - follow naming convention - filed_name for field value, field_name_style for CELL STYLE value
    getCellColor(alert:Alert, field:String) {
        // console.debug("AlertSummaryService::getCellColor ", field);
        if (field == 'age') {
            return this.getAgeColumnCellColor(alert);
        }
        else if (field == 'delta') {
            return this.getChangeColumnCellColor(alert);
        }
    };

    //Since all communication is in one thread,
    //It makes no use to create a COPY of the passed
    //parameter(it will get to create that local variaable 10K times going through recordset,
    //So referring variables directly will save a lot of browser's work with JS
    getAgeColumnCellColor(alert:Alert) {
        // console.debug("AlertSummaryService::getAgeColumnCellColor");
        //let priority = alert.priority;
        //let age = alert.age;
        //TODO: To clean up above comments and code and simplify code below (HIGH - Performance issue)
        // Question: What is the first line check? Basicaly Priority = high OR Age >=5 - that is all (this code is running thousands of times
        // for each row in the table
        // if (alert.priority === 'High' || (alert.priority === 'Medium' && alert.age >= 5) || (alert.priority === 'Low' && alert.age >= 5)) {
        if (alert.priority === 'High' || alert.age >= 5) {
            return "RED";
        }
        else if ((alert.priority === 'Medium' && alert.age <= 1) || (alert.priority === 'Low' && alert.age <= 2)) {
            return "GREEN";
        }
        else if ((alert.priority === 'Medium' && (alert.age >= 2 && alert.age <= 4)) || (alert.priority === 'Low' && (alert.age >= 3 && alert.age <= 5))) {
            return "#FF7E00";
        }

        return "BLACK";
    }

    getChangeColumnCellColor(alert:Alert) {
        // console.debug("AlertSummaryService::getChangeColumnCellColor");
        if (alert.delta.indexOf('-') == 0) {
            return "RED";
        } else {
            return "GREEN";
        }
    }
    
    getToolTip(alertData):string {
        console.debug("AlertSummaryService::getToolTip", alertData);
        let usersToolTip = "";

        usersToolTip += this.appendUsers(usersToolTip, alertData.nam, " - NAM");
        usersToolTip += this.appendUsers(usersToolTip, alertData.nam_aqua, " - NAM - AQUA");
        usersToolTip += this.appendUsers(usersToolTip, alertData.emea, " - EMEA");
        usersToolTip += this.appendUsers(usersToolTip, alertData.emea_aqua, " - EMEA - AQUA");
        usersToolTip += this.appendUsers(usersToolTip, alertData.apac, " - APAC");
        usersToolTip += this.appendUsers(usersToolTip, alertData.apac_aqua, " - APAC - AQUA");

        return usersToolTip;
    }

    private appendUsers(usersToolTip, coverageUserNames, coverageRegion):string {
        let userNames = "";
        if (coverageUserNames && coverageUserNames.trim() != "") {
            if (usersToolTip != "") {
                userNames += "\n";
            }
            let userArray = coverageUserNames.split('|');
            userNames += userArray.map(user => {
                return (user ? user.trim() : "") + coverageRegion
            }).join("\n");
        }
        return userNames;
    }
    
    exportToExcel(selectedTab, searchTerm) {
		console.debug('AlertSummaryService::exportToExcel ', selectedTab, searchTerm);
		var url = exportToExcelURI + selectedTab + "/";
	    if (searchTerm && searchTerm != "") {
	    	url = url + searchTerm;
	    }
		this.utilService.exportToExcel(url);
	}
    
}
