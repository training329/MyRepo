export class BulkExceptionModel {
	
	//request
	public exception_id_list: string;
	public exception_ids: string;
	public status: string;
	public alert_status: string;
	public comment: string;
	public exception_owner: string;
	public exception_owner_name: string;
	public selectedExceptionIdList: string[];

	//response
	public exception_id: number;
	public operation_status: string;
	public operation_status_value: number;
	public file_name: string;
	public updatedby: string;
		
	public error: boolean;
	public errorMessage: string;


}