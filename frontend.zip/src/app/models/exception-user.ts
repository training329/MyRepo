export class ExceptionUser {

	constructor(
		public groupId: number,
		public soeid: string,
		public gpName: string,	
		public region: string,
		public gpType: string,
		public primary: boolean,
		public source: string,
		public gpNum: string,		
		public relationId: number,
		public relation: string,
		public topAccount: string,
		public active: boolean	
       ){}

}
