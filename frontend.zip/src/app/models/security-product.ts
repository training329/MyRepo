export class SecurityProduct {

	constructor(
	        public cob_date: string,
	    	public convertibles: number,
	    	public corporates: number,
	    	public equities: number,
	    	public other: number,
	    	public preferreds: number,
	    	public sovereigns: number,
	    	public warrants: number
    ) {}
}