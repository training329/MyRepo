export class SecurityCountryRisk {

	constructor(
	        public cob_date: string,
	    	public APAC_Emerging_Markets_Lev1: number,
	    	public APAC_Emerging_Markets_Lev2: number,
	    	public APAC_Emerging_Markets_Lev3: number,
	    	public Developed_Markets: number,
	    	public EMEA_Emerging_Markets_Lev1B: number,
	    	public EMEA_Emerging_Markets_Lev2: number,
	    	public LATAM_Emerging_Markets_Lev2: number,
	    	public Other: number
    ) {}
}