export class Revenue {

	constructor(
	        public cob_date: string,
	    	public pnl: number,
	    	public cash: number,
	    	public shorts: number,
	    	public fee: number
    ) {}
}