export class FinancingBalance {

	constructor(
	        public cob_date: string,
	        public GFCID_fund: string,
	        public client: string,
	        public fund: string,
	        public region: string,
	        public credit: string,
	        public debit: number,
	        public shorts: number,
	        public others: number,
	        public index_level: number
    ) {}
}