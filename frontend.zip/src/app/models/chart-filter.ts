
export class ChartFilter {
	
	public type: string;
	public cob_date: number;
	public client: string;
	public fund: string;
	public region: string;
 
}
