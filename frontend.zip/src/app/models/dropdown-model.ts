export class DropDownModel {
   public value: string;
   public text: string;
}
