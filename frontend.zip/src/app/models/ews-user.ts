export class EWSUser {

constructor(
		public id: string,
		public soeid: string,
		public friendly_name: string,	
		public domain_name: string,
		public email: string,
		public status: string, 
		public user_role: string,
		public race_role: string,
		public all_client: boolean,
		public manage_alert: boolean,
		public manage_alert_rule: boolean,
		public add_admin: boolean,
		public manage_coverage: boolean,
		public created_by: string,
		public created_time: string,
		public created_time_db: string,	
		public manager_soeid: string,
		public operation: string
       ){}
}
