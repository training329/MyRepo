
export class APIResponse {
   public status: boolean;
   public message: string;
   public description: string;
}
