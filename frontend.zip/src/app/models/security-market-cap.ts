export class SecurityMarketCap {

	constructor(
	        public cob_date: string,
	    	public Mega: number,
	    	public BigLarge: number,
	    	public Mid: number,
	    	public Small: number,
	    	public Micro: number,
	    	public Nano: number,
	    	public Other: number
    ) {}
	
}