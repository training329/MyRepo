export class Alert {
    public rule_id:string;
    public rule_group_id:string;
    public exception_activity_id:string;
    public exception_id:number;
    public version_id:string;
    public type:string;
    public priority:string;
    public priority_id:string;
    public legal_entity:string;
    public client:string;
    public region:string;
    public fund:string;
    public country:string;
    public product:string;
    public rule_period:string;
    public aggregation_level:string;
    public aggregation_level_name:string;
    public description:string;
    public measure:string;
    public limit_type:string;
    public limit:string;
    public is_active:string;
    public threshold_type:string;
    public create_user:string;
    public create_time:string;
    public cob_date:string;
    public open_date:string;
    public status:string;
    public status_name:string;
    public age:number;
    public comment:string;
    public file_name:string;
    public attachements:string[];
    public exception_owner:string;
    public updatedby:string;
    public first_date:string;
    public first_value:string;
    public second_date:string;
    public second_value:string;
    public delta:string;
    public delta_percent:string;
    public exception_owner_name:string;
    public client_fund:string;
    public is_security:boolean;
    public clientTier:string;
    public is_primary:boolean;
    public is_clientgroup:boolean;
    public nam:string;
    public emea:string;
    public apac:string;
}


//TODO: Use enhanced Alert model object to calculate and store CELL STYLES (color, font etc)
//TODO: Name it same name as field, plus '_style' - then you can check style dynamically -(array[filed_name_style])?array.filed_name_style:'';

export class AlertTableData extends Alert {
    public age_style:string;
    public delta_style:string;
}