export class BalanceSheetROA {

	constructor(
	        public cob_date: string,
	    	public balance_sheet: number,
	    	public without_seclending_balsheet: number,
	    	public pnl: number,
	    	public roa: number
    ) {}
}