export class MasterData {

	constructor(
			public client: string,
			public client_id: string,
			public fund: string,
			public fund_id: string,
			public entity: string,
			public entity_id: string,
			public region: string,
			public region_id: string
    ) {} 
}