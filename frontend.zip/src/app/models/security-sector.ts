export class SecuritySector {

	constructor(
	        public cob_date: string,
	    	public consumer_discretionary: number,
	    	public consumer_staples: number,
	    	public energy: number,
	    	public financials: number,
	    	public health_care: number,
	    	public industrials: number,
	    	public information_technology: number,
	    	public materials: number,
	    	public other: number,
	    	public telecommunications: number,
	    	public utilities: number
    ) {} 
	
}