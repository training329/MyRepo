
export class Client {
   public clientId: number;
   public name: string;
   public created: Date;
}
