export class EquityBalance {

	constructor(
	        public cob_date: string,
	        public GFCID_fund: string,
	        public client: string,
	        public fund: string,
	        public region: string,
	    	public cash: number,
	    	public lmv: number,
	    	public smv: number,
	    	public netequity: number,
	    	public totalequity: number,
	    	public index_level: number
    ) {}
}