export class FlagedSecurityExceptionRule {

constructor(
        public  security_attribute: string,
        public  first_date: string,
        public  first_value: string,
        public  second_date: string,
        public  second_value: string,
        public  change: string,
        public  change_percent: string,
        public  composition_percent: string,
        public  security_type: string,
        public  change_row: boolean
       ){}
}
