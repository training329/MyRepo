export class AlertRule {
    
    public exceptionRuleId: number;
    public rule_group_id: string;
    public exceptionRuleType: string;
    public exceptionRuleTypeName: string;
    public exceptionPriority: string;
    public exceptionPriorityName: string;
    public legalEntity: string;
    public legalEntityName: string;
    public client: string;
    public region: string;
    public regionName: string;
    public fund: string;
    public clientName: string;
    public fundName: string;
    public exceptionRuleDataType: string;
    public exceptionRuleDataTypeName: string;
    public exceptionRuleTimePeriod: string;
    public exceptionRuleTimePeriodName: string;
    public exceptionRuleLimitType: string;
    public exceptionRuleLimitTypeName: string;
    public exceptionRuleThresholdType: string;
    public exceptionRuleThresholdTypeName: string;
    public exceptionRuleLimits: string;
    public exceptionStatus: string;
    public exceptionStatusName: string;
    public exceptionComments: string;
    public total_open_alerts: number;
    public today_open_alerts: number;
    public updatedBy: string;
    public create_time: string;
    public ruleOwner: string;
	public ruleOwnerName: string;
    public version_id: string;
    public threshold_dollar: number;
    public threshold_dollar_mask: string;
    public threshold_percent: number;
    public aggregation_level: string;
    public aggregation_level_name: string;
    
    constructor(){}
}
