export class Coverage {

constructor(
        public  soeid: string,
        public  gpnum: string,
        public  product: string,
        public  coverer: string,
        public  coverage_region: string,
        public  coverage_subregion: string,
        public  roletype: string,
        public  Coverage_team: string,
        public  Client: string,
        public  coverage_client: string,
        public  global_priority: string,
        public  markets_platinum: string,
        public  source: string,
        
        //user coverage History
        public id: number,
        public gp: string,
        public gpname: string,
        public operation: string,
        
       ){}

}
