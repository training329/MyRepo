export class ExceptionMaster {
   public value: string;
   public text: string;
   public type: string;
}
