const webpack = require('webpack');
const HtmlWebpack = require('html-webpack-plugin');

const webpackMerge = require('webpack-merge');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const DefinePlugin = require('webpack/lib/DefinePlugin');
const commonConfig = require('./webpack.common.js');
const helpers = require('./helpers');
const ENV = process.env.ENV = process.env.NODE_ENV = 'development';
const HMR = helpers.hasProcessFlag('hot');

const METADATA =  {
    host: 'localhost',
    port: 3000,
    ENV: ENV,
    HMR: HMR
};

const bootstraploader = 'bootstrap-loader/lib/bootstrap.loader?' +
          `configFilePath=${__dirname}/.bootstraprc` +
          '!bootstrap-loader/no-op.js';

module.exports = function (options) {
    return webpackMerge(commonConfig({env: ENV}), {
        // metadata: METADATA,

        /**
         * Developer tool to enhance debugging
         *
         * See: http://webpack.github.io/docs/configuration.html#devtool
         * See: https://github.com/webpack/docs/wiki/build-performance#sourcemaps
         */
        devtool: 'cheap-module-source-map',

        entry: {
            bootstraploader
        },

        output: {
            path: helpers.root('dist'),
            filename: '[name].js',
            chunkFilename: '[id].chunk.js',
            sourceMapFilename: '[name].js.map',
            library: 'ac_[name]',
            libraryTarget: 'var'
        },

        plugins: [
            new webpack.LoaderOptionsPlugin({
                debug: false,
                minimize: true,
                options: {
                    context: helpers.root(),
                    output: {
                        path: helpers.root('dist')
                    },
                    htmlLoader: {
                        caseSensitive: true,
                        customAttributeAssign: [/\)?\]?=/],
                        customAttributeSurround: [
                            [/#/, /(?:)/],
                            [/\*/, /(?:)/],
                            [/\[?\(?/, /(?:)/]
                        ],
                        minimize: true,
                        removeAttributeQuotes: false
                    },
                    /**
                     * Static analysis linter for TypeScript advanced options configuration
                     * Description: An extensible linter for the TypeScript language.
                     *
                     * See: https://github.com/wbuchwalter/tslint-loader
                     */
                    tslint: {
                        emitErrors: false,
                        failOnHint: false,
                        resourcePath: 'src'
                    }
                }
            }),
            new webpack.optimize.OccurrenceOrderPlugin(true),
            new webpack.NoErrorsPlugin(),
            new HtmlWebpack({
                filename: 'index.html',
                inject: 'body',
                template: './src/index.html'
            }),
            new webpack.optimize.UglifyJsPlugin({
                compress: {
                    warnings: true,
                    screw_ie8: true,
                },
                beautify: false,
                comments: false,
                sourceMap: true
            }),
            new ExtractTextPlugin('[name].css'),
            new DefinePlugin({
                'ENV': JSON.stringify(METADATA.ENV),
                'HMR': METADATA.HMR,
                'process.env': {
                    'ENV': JSON.stringify(METADATA.ENV),
                    'NODE_ENV': JSON.stringify(METADATA.ENV),
                    'HMR': METADATA.HMR
                }
            }),

            /*    new webpack.optimize.CommonsChunkPlugin({
             name: 'vendor',
             filename: './src/vendor.ts',
             minChunks: Infinity
             }), */
        ],

        devServer: {
            port: METADATA.port,
            host: METADATA.host,
            historyApiFallback: true,
            watchOptions: {
                aggregateTimeout: 300,
                poll: 1000
            },
            outputPath: helpers.root('dist'),
            proxy: {
                '/api': {
                    target: 'http://localhost:9070',
                },
                // '/coverage': {
                //     target: 'http://localhost:9070/coverage',
                // },
                // '/clientoverview': {
                //     target: 'http://localhost:9070/clientoverview',
                // },
            },
        },

        node: {
            global: true,
            crypto: false,
            process: true,
            module: false,
            clearImmediate: false,
            setImmediate: false
        }
    });

}