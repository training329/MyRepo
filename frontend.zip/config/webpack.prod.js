const webpack = require('webpack');
const HtmlWebpack = require('html-webpack-plugin');
const DefinePlugin = require('webpack/lib/DefinePlugin');
const webpackMerge = require('webpack-merge');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const commonConfig = require('./webpack.common.js');
const helpers = require('./helpers');

const ENV = process.env.NODE_ENV = process.env.ENV = 'production';

 const bootstraploader = 'bootstrap-loader/lib/bootstrap.loader?' +
     `configFilePath=${__dirname}/.bootstraprc` +
     '!bootstrap-loader/no-op.js';

module.exports =
    function (options) {
        return webpackMerge(commonConfig({env: ENV}), {

            // devtool: 'cheap-module-eval-source-map',

            devtool: 'source-map',

            entry: {
                bootstraploader
            },

            output: {
                path: helpers.root('dist'),
                publicPath: '/',
                filename: '[name].js',
                chunkFilename: '[id].chunk.js',
                // sourceMapFilename: '[name].js.map',

                library: 'ac_[name]',
                libraryTarget: 'var'
            },


            plugins: [
                new webpack.LoaderOptionsPlugin({
                    debug: false,
                    minimize: true,
                    options: {
                        context: helpers.root(),
                        output: {
                            path: helpers.root('dist')
                        },
                        htmlLoader: {
                            caseSensitive: true,
                            customAttributeAssign: [/\)?\]?=/],
                            customAttributeSurround: [
                                [/#/, /(?:)/],
                                [/\*/, /(?:)/],
                                [/\[?\(?/, /(?:)/]
                            ],
                            minimize: true,
                            removeAttributeQuotes: false
                        },
                        /**
                         * Static analysis linter for TypeScript advanced options configuration
                         * Description: An extensible linter for the TypeScript language.
                         *
                         * See: https://github.com/wbuchwalter/tslint-loader
                         */
                        tslint: {
                            emitErrors: false,
                            failOnHint: false,
                            resourcePath: 'src'
                        }
                    }
                }),
                new webpack.NoErrorsPlugin(),
                new HtmlWebpack({
                    filename: 'index.html',
                    inject: 'body',
                    template: './src/index.html'
                }),
                new webpack.optimize.UglifyJsPlugin({
                    compress: {
                        warnings: true,
                        screw_ie8: true,
                    },
                    beautify: false,
                    comments: false,
                    sourceMap: true
                }),
                new ExtractTextPlugin('[name].css'),
                new webpack.DefinePlugin({
                    'ENV': JSON.stringify(ENV),
                    'process.env': {
                        'ENV': JSON.stringify(ENV)
                    }
                })
            ]
        });
    }