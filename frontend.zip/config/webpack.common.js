const webpack = require('webpack');
const helpers = require('./helpers');

//const CommonsChunkPlugin = webpack.optimize.CommonsChunkPlugin;
const CopyWebpackPlugin = require('copy-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

const ngcWebpack = require('ngc-webpack');

const autoprefixer = require('autoprefixer');

const HMR = helpers.hasProcessFlag('hot');
const AOT = helpers.hasNpmFlag('aot');

module.exports = function (options) {

    isProd = options.env === 'production';
    return {

        entry: {
            'polyfills': './src/polyfills.ts',
            'vendor': './src/vendor.ts',
            'app': './src/main.ts'
        },

        resolve: {
            alias: {
                highcharts$: "highcharts/highstock.src.js"
            },
            modules: [helpers.root('src'), helpers.root('node_modules')],
            descriptionFiles: ['package.json'],
            extensions: ['.js', '.ts', '.css', '.scss', '.json', '.html'],
        },

        module: {
            // preLoaders: [
            //     {
            //         test: /\.js$/,
            //         loader: 'source-map-loader',
            //         exclude: [helpers.root('node_modules')]
            //     }
            // ],

            rules: [
                {
                    enforce: "pre",
                    test: /\.js$/,
                    loader: 'source-map-loader',
                    exclude: [helpers.root('node_modules')]
                },


                // test: /\.ts$/,
                //     loaders: ['awesome-typescript-loader', 'angular2-template-loader'],
                //     exclude: [/\.(spec|e2e)\.ts$/]
                // },
                /*
                 * Typescript loader support for .ts
                 *
                 * Component Template/Style integration using `angular2-template-loader`
                 * Angular 2 lazy loading (async routes) via `ng-router-loader`
                 *
                 * `ng-router-loader` expects vanilla JavaScript code, not TypeScript code. This is why the
                 * order of the loader matter.
                 *
                 * See: https://github.com/s-panferov/awesome-typescript-loader
                 * See: https://github.com/TheLarkInn/angular2-template-loader
                 * See: https://github.com/shlomiassaf/ng-router-loader
                 */
                {
                    test: /\.ts$/,
                    use: [
                        { // MAKE SURE TO CHAIN VANILLA JS CODE, I.E. TS COMPILATION OUTPUT.
                            loader: 'ng-router-loader',
                            options: {
                                loader: 'async-import',
                                genDir: 'compiled',
                                aot: AOT
                            }
                        },
                        {
                            loader: 'awesome-typescript-loader',
                            options: {
                                configFileName: 'tsconfig.webpack.json'
                            }
                        },
                        {
                            loader: 'angular2-template-loader'
                        }
                    ],
                    exclude: [/\.(spec|e2e)\.ts$/]
                },

                {
                    test: /\.html$/,
                    loader: 'raw-loader',
                    exclude: [helpers.root('src/index.html')]
                },

                // {
                // test: /\.css$/,
                // //    loader: ExtractTextPlugin.extract("style-loader", "css-loader")
                // loader: 'raw-loader'
                // },

                {
                    test: /\.css$/,
                    loader: "css-loader!autoprefixer-loader"
                },

                {
                    test: /initial\.scss$/,
                    loader: ExtractTextPlugin.extract({
                        fallbackLoader: 'style-loader',
                        loader: 'css-loader!sass-loader'
                    })
                },

                {
                    test: /\.scss$/,
                    loaders: ['raw-loader', 'sass-loader'],
                    exclude: [helpers.root('node_modules')]
                },

                {
                    test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
                    loader: "url-loader?limit=10000&mimetype=application/font-woff"
                },

                {
                    test: /\.(ttf|eot|svg)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
                    loader: "file-loader"
                },

                {
                    test: /\.json$/,
                    loader: 'json-loader'
                },

                {
                    test: /bootstrap\/dist\/js\/umd\//,
                    loader: 'imports?jQuery=jquery'
                }
            ]
        },

        // postcss: [autoprefixer],

        plugins: [

            new ExtractTextPlugin({
                filename: '[name].css',
                disable: false, allChunks: true
            }),

            new webpack.optimize.CommonsChunkPlugin({
                name: ['app', 'vendor', 'polyfills']
            }),

            new CopyWebpackPlugin([{
                from: 'src/assets',
                to: 'assets'
            }]),

            new HtmlWebpackPlugin({
                template: 'src/index.html',
                chunksSortMode: 'dependency'
            }),

            new webpack.ProvidePlugin({
                jQuery: 'jquery',
                $: 'jquery',
                jquery: 'jquery',
                "window.moment": "moment",
                'Tether': 'tether',
                'window.Tether': 'tether',
                Util: "exports?Util!bootstrap/js/dist/util",
                Tooltip: "exports?Tooltip!bootstrap/js/dist/tooltip",
                Alert: "exports?Alert!bootstrap/js/dist/alert",
                Button: "exports?Button!bootstrap/js/dist/button",
                Carousel: "exports?Carousel!bootstrap/js/dist/carousel",
                Collapse: "exports?Collapse!bootstrap/js/dist/collapse",
                Dropdown: "exports?Dropdown!bootstrap/js/dist/dropdown",
                Modal: "exports?Modal!bootstrap/js/dist/modal",
                Popover: "exports?Popover!bootstrap/js/dist/popover",
                Scrollspy: "exports?Scrollspy!bootstrap/js/dist/scrollspy",
                Tab: "exports?Tab!bootstrap/js/dist/tab"
            }),

            // TODO: - Make it work ref: https://github.com/angular/angular/issues/11580
            new webpack.ContextReplacementPlugin(
                // The (\\|\/) piece accounts for path separators in *nix and Windows
                /angular(\\|\/)core(\\|\/)(esm(\\|\/)src|src)(\\|\/)linker/,
                helpers.root('src') // location of your src
            )
        ],

        node: {
            global: true,
            crypto: false,
            module: false,
            clearImmediate: false,
            setImmediate: false
        }
    };
}